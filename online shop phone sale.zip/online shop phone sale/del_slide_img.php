<?php
require "connection.php";

// Check if slide_id is set and valid
if(isset($_POST['slide_id'])) {
    $slide_id = $_POST['slide_id'];

    // Prepare SQL statement to delete slide
    $delete_query = "DELETE FROM slides WHERE slide_id = ?";
    $stmt = $conn->prepare($delete_query);

    // Bind parameters
    $stmt->bind_param("i", $slide_id);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Slide deleted successfully.";
    } else {
        echo "Error deleting slide: " . $conn->error;
    }

    // Close statement
    $stmt->close();
} else {
    echo "Slide ID is not set.";
}

// Close connection
$conn->close();
?>
