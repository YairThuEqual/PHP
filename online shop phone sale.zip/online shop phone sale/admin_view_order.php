<?php require "connection.php"; ?>
<?php session_start(); ?>
<?php 
     
?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Order View</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <!-- <link rel="stylesheet" href="./home.css">
     <link rel="stylesheet" href="./card.css"> -->

     <link rel="icon" href="./img/MicrosoftTeams-image (1).png">

     <style>
          <?php require "admin_home.css"; ?>
          <?php require "admin_view_order.css"; ?>
     </style>
     
</head>
<body>

     <?php include "admin_header.php"; ?>


     <section>
          <div class="view">
               <table>
                    <?php
                    if(isset($_GET['order_id'])){
                    $order_id = $_GET['order_id'];
                    
                    $query = "SELECT * FROM orders WHERE order_id = $order_id;";
                    $res = mysqli_query($conn, $query);
                    $row = mysqli_fetch_assoc($res);
                    $user_id = $row['user_id'];
                    $name = $row['name'];
                    $email = $row['email'];
                    $ph_no = $row['ph_number'];
                    $township = $row['township'];
                    $strt_address = $row['strt_address'];
                    $add_info = $row['add_info'];
                    $payment = $row['payment'];
                    $order_date = $row['order_date'];
                    $status = $row['status'];

                    $main = "SELECT email FROM register WHERE user_id = $user_id";
                    $main_res = mysqli_query($conn, $main);
                    $main_row = mysqli_fetch_assoc($main_res);
                    $main_email = $main_row['email'];

                    ?>
                    <tr>
                         <td colspan="3" class="main"><h1><?php echo $main_email; ?></h1></td>
                    </tr>
                    <tr>
                         <td class="limit">Name</td>
                         <td class="slit">-</td>
                         <td><?php echo $name; ?></td>
                    </tr>
                    <tr>
                         <td class="limit">email</td>
                         <td class="slit">-</td>
                         <td><?php echo $email; ?></td>
                    </tr>
                    <tr>
                         <td class="limit">phone_number</td>
                         <td class="slit">-</td>
                         <td><?php echo $ph_no; ?></td>
                    </tr>
                    <tr>
                         <td class="limit">Township</td>
                         <td class="slit">-</td>
                         <td><?php echo $township; ?></td>
                    </tr>
                    <tr>
                         <td class="limit">Street Address</td>
                         <td class="slit">-</td>
                         <td><?php echo $strt_address; ?></td>
                    </tr>
                    <tr>
                         <td class="limit">Delivery Instructions</td>
                         <td class="slit">-</td>
                         <td><?php echo $add_info; ?></td>
                    </tr>
                    <tr>
                         <td class="limit">Payment</td>
                         <td class="slit">-</td>
                         <td><?php echo $payment; ?></td>
                    </tr>
                    <tr>
                         <td class="limit">Order-Date</td>
                         <td class="slit">-</td>
                         <td><?php echo $order_date; ?></td>
                    </tr>
                    <tr>
                         <td colspan="3" class="img">
                              <tr>
                                   <td>Model</td>
                                   <td>R/Storage, Color</td>
                                   <td>Subtotal</td>
                              </tr>
                              <?php 
                              $coll_qry = "select * from collect where order_id = $order_id";
                              $coll_res = mysqli_query($conn, $coll_qry);
                              $total = 0;
                              while($coll_row = mysqli_fetch_assoc($coll_res)){
                                   $price_id = $coll_row['price_id'];
                                   $qty = $coll_row['quantity'];
                                   $price = $coll_row['price'];
     
                                   $total += $qty * $price;
     
                                   $select_qry = "SELECT p.model, b.ram_storage, s.color FROM phones p JOIN bibi b ON p.phone_id = b.phone_id JOIN select_phones s ON s.select_id = b.select_id WHERE b.price_id = $price_id;";
                                   $select_res = mysqli_query($conn, $select_qry);
                                   $select_row = mysqli_fetch_assoc($select_res);
                                   $model = $select_row['model'];
                                   $r_sta = $select_row['ram_storage'];
                                   $color = $select_row['color'];
                              ?>
                                   <tr>
                                   <td><?php echo $model; ?></td>
                                   <td><?php echo "$r_sta, $color" ?></td>
                                   <td id="priccee">
                                       <span class="quantity"><?php echo $qty; ?> &Cross; </span>
                                       <?php echo addCommas($qty * $price); ?>
                                   </td>

                              </tr>
                                   <?php } ?>
                              <tr>
                                   <td colspan="3"><hr></td>
                              </tr>
                              <tr>
                                   <td></td>
                                   <td></td>
                                   <td><h3>Total</h3></td>
                              </tr>
                              <tr>
                                   <td></td>
                                   <td></td>
                                   <td><h1><?php echo addCommas($total); ?></h1></td>
                              </tr>
                         </td>
                    </tr>
                    <tr>
                         <?php if($status == "delivery"){ ?>
                         <td colspan="3" class="btn"><a href="admin_checked.php?order_id=<?php echo $order_id ?>"><button>Order Finish</button></a></td>
                         <?php } ?>
                    </tr>
                    <?php } ?>
               </table>
          </div>
     </section>


     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     <script>
          let menu =document.getElementById('menu');
          let nav = document.querySelector('.navigation');

          menu.addEventListener('click', () => {
               nav.classList.toggle('active');
          })

          <?php
          function addCommas($number) {
              return number_format($number);
          }
          ?>


     </script>
 
 

</body>
</html>