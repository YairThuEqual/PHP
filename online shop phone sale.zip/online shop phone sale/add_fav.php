<?php 
require "connection.php";
session_start();
$user_id = $_SESSION['user_id'];

if(isset($_GET['phone_id'])){
     $phone_id = $_GET['phone_id'];
     $fav_query = "INSERT INTO favorite (user_id, phone_id) VALUES($user_id, $phone_id)";
     $fav_res = mysqli_query($conn, $fav_query);

     header("location: favorite.php");
}
?>