<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Date Range Search</title>
<style>
    .move {
        display: flex;
        flex-direction: row; /* Change flex direction to row */
        align-items: center;
        justify-content: space-between; /* Space elements evenly */
    }

    .move label {
        margin-right: 10px;
    }

    .move input[type="date"],
    .move input[type="submit"] {
        padding: 5px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .move input[type="date"] {
        width: 45%; /* Adjust width as needed */
    }

    .move input[type="submit"] {
        background-color: #007bff;
        color: #fff;
        cursor: pointer;
        border: none;
    }
</style>
</head>
<body>

<h2>Date Range Search</h2>

<div class="move">
    <label for="start">Start Date:</label>
    <input type="date" name="start" id="start" required onchange="setMinEndDate()">
    <label for="end">End Date:</label>
    <input type="date" name="end" id="end" required>
    <input type="submit" value="Search" onclick="submitForm(event)">
</div>

<script>
function setMinEndDate() {
    var startDateValue = document.getElementById("start").value;
    document.getElementById("end").min = startDateValue;
}

function submitForm(event) {
    event.preventDefault();
    document.getElementById("searchForm").submit();
}
</script>

</body>
</html>
