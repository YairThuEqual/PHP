<?php 
     require "connection.php";
     if($_SERVER['REQUEST_METHOD'] == "POST"){
          $brand = $_POST['brand'];
          $model = $_POST['model'];
          $chip = $_POST['chip'];
          $m_cam = $_POST['m_cam'];
          $s_cam = $_POST['s_cam'];
          $display = $_POST['display'];
          $resolution = $_POST['resolution'];
          $os = $_POST['os'];
          $feature = $_POST['feature'];
          $battery = $_POST['battery'];
          $charg = $_POST['charg'];
          $weight = $_POST['weight'];
          $dimen = $_POST['dimen'];
          $des = $_POST['desc'];

          $query = "INSERT INTO phones (brand, model, description, display, resolution, os, chipset, main_camera, selfie_camera, feature, battery, charging, weight, dimension)
          VALUES 
          ('$brand', '$model', '$des', '$display', '$resolution', '$os', '$chip', '$m_cam', '$s_cam', '$feature', '$battery', '$charg', '$weight', '$dimen')";

          mysqli_query($conn, $query);

          header("location: admin_insert.php");
     }

?>