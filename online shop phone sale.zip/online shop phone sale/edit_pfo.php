<?php 
require "connection.php"; 
session_start();
$user_id = $_SESSION['user_id'];

if($_SERVER['REQUEST_METHOD'] == "POST"){
     $name = $_POST['username'];
     $ph_email = $_POST['ph_email'];
     $ph_no = $_POST['ph_no'];
     $city = $_POST['city'];
     $address = $_POST['address'];

     $query = "UPDATE register SET name = '$name', email = '$ph_email', phone_number = '$ph_no', city = '$city', address = '$address' WHERE user_id=$user_id;";
     mysqli_query($conn, $query);
     echo "<script>
     alert('successful.');
     </script>";    
     header("location: user.php");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Edit Profile</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <!-- <link rel="stylesheet" href="./home.css">
     <link rel="stylesheet" href="./edit_pfo.css"> -->
     <link rel="icon" href="./img/MicrosoftTeams-image (1).png">
     <style>
          <?php require "home.css"; ?>
          <?php require "edit_pfo.css"; ?>
     </style>
     
</head>
<body>

     <?php include "header.php"; ?>

     <?php 
     $query = "select * from register where user_id = $user_id";
     $res = mysqli_query($conn, $query);
     $row = mysqli_fetch_assoc($res);

     $user_id = $row['user_id'];
     $name = $row['name'];
     $ph_no = $row['phone_number'];
     $city = $row['city'];
     $address = $row['address'];
     $email = $row['email'];
     ?>

     <section>
          <div class="form">
               <form action="" method="post"> 
                    <div class="pfo">
                         <div class="pfo_text">
                              <label for="">Username:</label>
                              <input type="text" name="username" placeholder="username" value="<?php echo $name; ?>">
                         </div>
                         <div class="pfo_text">
                              <label for="">Email:</label>
                              <input type="email" name="ph_email" placeholder="email" value="<?php echo $email; ?>">
                         </div>
                    </div>
                    <div class="pfo">
                         <div class="pfo_text">
                              <label for="">Ph No:</label>
                              <input type="number" name="ph_no" placeholder="phone number" value="<?php echo $ph_no; ?>">
                         </div>
                         <div class="pfo_text">
                              <label for="">City:</label>
                              <input type="text" name="city" placeholder="city" value="<?php echo $city; ?>">
                         </div>
                    </div>
                    <div class="pfo_add">
                         <label for="">Address:</label>
                         <input type="text" name="address" placeholder="address" value="<?php echo $address; ?>">
                    </div>

                    <input type="submit" value="s a v e" name="upload">

               </form>
          </div>
     </section>

     <?php include "footer.php"; ?>
          
     
     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
     
     <script>
          let search = document.querySelector('.searchBtn')
          let closeBtn = document.querySelector('.closeBtn')
          let searchBox = document.querySelector('.searchBox')
          let nav = document.querySelector('.navigation')
          let menu = document.querySelector('.menuToggle')
          let header = document.querySelector('header')

          search.addEventListener('click', () => {
               searchBox.classList.add('active')
               closeBtn.classList.add('active')
               search.classList.add('active')
               menu.classList.add('hide')
               header.classList.remove('open')
          })

          closeBtn.addEventListener('click', () => {
               searchBox.classList.remove('active')
               closeBtn.classList.remove('active')
               search.classList.remove('active')
               menu.classList.remove('hide')
          })

          menu.addEventListener('click', () =>{
               header.classList.toggle('open')
               searchBox.classList.remove('active')
               closeBtn.classList.remove('active')
               search.classList.remove('active')
          })
     </script>
</body>
</html>