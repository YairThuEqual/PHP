<?php require "connection.php"; ?>
<?php session_start(); ?>
<?php
if(isset($_SESSION['user_id'])){
     $user_id = $_SESSION['user_id']; 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Profile</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <link rel="icon" href="./img/MicrosoftTeams-image (1).png">
     <style>
          <?php require "home.css"; ?>
          <?php require "user.css"; ?>
          .file-label {
               display: inline-block;
               padding: 10px 20px;
               background-color: black;
               color: #fff;
               border-radius: 5px;
               cursor: pointer;
          }

          .file-input {
               display: none; /* hide the default file input */
          }
     </style>
</head>
<body>
     <?php include "header.php"; ?>

     <section>
          <div class="profile">
               <div class="img">
                    <?php
                    $query = "SELECT * FROM register WHERE user_id = $user_id";
                    $res = mysqli_query($conn, $query);
                    $row = mysqli_fetch_assoc($res);
                    $name = $row['name'];
                    $email = $row['email'];
                    $img = $row['user_img'];
                    $ph_no = $row['phone_number'];
                    $city = $row['city'];
                    $address = $row['address'];
                    ?>
                    <img src="./img/<?php echo $img; ?>">
                    <label for="fileInput" class="file-label">
                         <span>Edit</span>
                         <input type="file" name="file" id="fileInput" class="file-input">
                    </label>
               </div> 
               <div class="info">
                    <div class="info_text">
                         <div class="text">
                              <h3>Username</h3>
                              <p><?php echo $name ?></p>
                         </div>
                         <div class="text">
                              <h3>Email</h3>
                              <p><?php echo $email ?></p>
                         </div>
                    </div>
                    <div class="info_text">
                         <div class="text">
                              <h3>Phone Number</h3>
                              <p><?php echo $ph_no ?></p>
                         </div>
                         <div class="text">
                              <h3>City</h3>
                              <p><?php echo $city ?></p>
                         </div>
                         <div class="text_add">
                              <h3>Address</h3>
                              <p><?php echo $address ?></p>
                         </div>
                    </div>
                    <div class="hii">
                         <div class="edd">
                              <a href="edit_pfo.php"><button>Edit Info</button></a>
                         </div>
                         <div class="logout">
                              <a href="logout.php"><button>Logout</button></a>
                         </div>
                    </div>
               </div>
          </div>
     </section>
     
     <?php require "footer.php"; ?>

     <script>
          let search = document.querySelector('.searchBtn')
          let closeBtn = document.querySelector('.closeBtn')
          let searchBox = document.querySelector('.searchBox')
          let nav = document.querySelector('.navigation')
          let menu = document.querySelector('.menuToggle')
          let header = document.querySelector('header')

          search.addEventListener('click', () => {
               searchBox.classList.add('active')
               closeBtn.classList.add('active')
               search.classList.add('active')
               menu.classList.add('hide')
               header.classList.remove('open')
          })

          closeBtn.addEventListener('click', () => {
               searchBox.classList.remove('active')
               closeBtn.classList.remove('active')
               search.classList.remove('active')
               menu.classList.remove('hide')
          })

          menu.addEventListener('click', () =>{
               header.classList.toggle('open')
               searchBox.classList.remove('active')
               closeBtn.classList.remove('active')
               search.classList.remove('active')
          })
     </script>

     <script>
          document.getElementById('fileInput').addEventListener('change', function() {
               var fileInput = this;
               var file = fileInput.files[0];
               uploadFile(file);
          });

          function uploadFile(file) {
               var formData = new FormData();
               formData.append('file', file);

               var xhr = new XMLHttpRequest();
               xhr.open('POST', 'http://localhost/KBTC-Class/PHP_Testing/yairlinthu/upload.php', true);
               xhr.onload = function () {
                    if (xhr.status === 200) {
                         console.log('File uploaded successfully.');
                         // Reload the page after the file is uploaded
                         window.location.reload();
                    } else {
                         console.error('An error occurred while uploading the file.');
                    }
               };
               xhr.onerror = function() {
                    console.error('An error occurred during the upload process.');
               };
               xhr.send(formData);
          }
    </script>


<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
      <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
     
      <script src="./nav.js"></script>

</body>
</html>
