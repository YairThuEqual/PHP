<?php require "connection.php"; ?>
<?php 
     $select_id = $_GET['id'];

     if($_SERVER['REQUEST_METHOD'] == 'POST'){
          $ram_sta = $_POST['ram_sta'];
          $price = $_POST['price'];
          $item = $_POST['item'];

          $p_st_selector = "SELECT phone_id from select_phones where select_id = $select_id";
          $p_st_res = mysqli_query($conn, $p_st_selector);
          $p_st_row = mysqli_fetch_assoc($p_st_res);
          $p_st_id = $p_st_row['phone_id'];
          echo $p_st_id;

          $p_st_query = "INSERT INTO bibi (price, select_id, items, phone_id, ram_storage)
          VALUES ($price, $select_id, '$item', $p_st_id, '$ram_sta');";

          mysqli_query($conn, $p_st_query);
 
     }

?>
<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Another Add Price</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <link rel="stylesheet" href="home.css">
     <!-- <link rel="stylesheet" href="./admin_p_price.css"> -->
     <link rel="icon" href="./img/MicrosoftTeams-image (1).png">
     <style>
          <?php require "admin_p_price.css"; ?>
          <?php require "admin_home.css"; ?>
     </style>
</head>
<body>

   <?php require "admin_header.php" ?>
     <div class="choice">
          <div class="c_form">
               <form id="priceForm" action="" method="post">
               <?php 

                    $q_selector = "SELECT model FROM phones JOIN select_phones ON phones.phone_id = select_phones.phone_id WHERE select_phones.select_id = $select_id;";
                    $q_res = mysqli_query($conn, $q_selector);
                    $q_row = mysqli_fetch_assoc($q_res);
                    $p_model = $q_row['model'];

                    echo "<p>product Name - <span>$p_model</span></p>";

                    $p_c_query = "select color, img from select_phones where select_id=$select_id";
                    $p_c_res = mysqli_query($conn, $p_c_query);
                    $p_c_row = mysqli_fetch_assoc($p_c_res);
                    $p_c_color = $p_c_row['color'];
                    $p_c_img = $p_c_row['img'];

                    echo "<p>Color - <span>$p_c_color</span></p>";
                    ?>         

                    
                    
                    <p>ram/Storage <span>(eg. 0/000)</span></p>
                    <input type="text" name="ram_sta" require>
                    <p>itmes <span>(only number)</span></p>
                    <input type="number" name="item" require>
                    <p>price <span>(only number)</span></p>
                    <input type="number" name="price" require>
                    <br><br>
                    
                    <input type="submit" value="Add price">
               </form>
          </div>
          <div class="c_img">
               
               <?php 

                    $bi_query = "select * from bibi where select_id = $select_id";
                    $bi_res = mysqli_query($conn, $bi_query);
                    
                    while($bi_row = mysqli_fetch_assoc($bi_res)){
                         $bi_iid = $bi_row['price_id'];
                         $bi_ram = $bi_row['ram_storage'];
                         $bi_price = $bi_row['price'];
                         $bi_item = $bi_row['items'];
                         // $bi_sale = $bi_row['sale_price']; 
                         ?>

                         <div class="c_img_card">
                         <a href=>
                              <img src="./img/<?php echo $p_c_img; ?>" alt="">
                         </a>
                         <div class="content">
                              <p>color - <?php echo $p_c_color; ?></p>
                              <p><?php echo $bi_ram; ?></p>
                              <p>items - <?php echo $bi_item; ?></p>
                              <p>price - <?php echo addCommas($bi_price);?> Ks</p>
                         </div>

                         <div class="con_ii" data-price-id="<?php echo $bi_iid; ?>">
                              <p><ion-icon name="trash-outline" class="delete-btn"></ion-icon></p>
                         </div>
                         <div class="edi_ii">
                              <p><a href="sale_p.php?bi_id=<?php echo $bi_iid; ?>&id=<?php echo $select_id ?>"><ion-icon name="create-outline"></ion-icon></ion-icon></a></p>
                         </div>
                    </div>
               
                   <?php } ?>
          
          </div>
     </div>
     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     <?php
     function addCommas($number) {
         return number_format($number);
     }
     ?>

     <script>
          let menu =document.getElementById('menu');
          let nav = document.querySelector('.navigation');

          menu.addEventListener('click', () => {
               nav.classList.toggle('active');
          })

          document.getElementById('priceForm').addEventListener('submit', function(event) {
                  var ram_sta = document.getElementsByName('ram_sta')[0].value;
                  var item = document.getElementsByName('item')[0].value;
                  var price = document.getElementsByName('price')[0].value;

                  if (ram_sta === '' || item === '' || price === '') {
                      alert('Please fill in.');
                      event.preventDefault(); // Prevent form submission if fields are empty
                  }
              });


          document.addEventListener('DOMContentLoaded', function() {
              // Get all containers with class 'con_ii'
              var containers = document.querySelectorAll('.con_ii');

              // Iterate through each container
              containers.forEach(function(container) {
                  // Attach click event listener to the container
                  container.addEventListener('click', function(e) {
                      if (e.target && e.target.matches('.delete-btn')) {
                          // Send AJAX request to delete
                          var parentDiv = e.target.closest('.con_ii');
                          var priceId = parentDiv.dataset.priceId; // Accessing the price-id attribute
                          if (confirm("Are you sure you want to delete this item?")) {
                              // Perform AJAX request here
                              var xhr = new XMLHttpRequest();
                              xhr.open('POST', 'http://localhost/KBTC-Class/PHP_Testing/yairlinthu/test/dele_point.php', true);
                              xhr.setRequestHeader('Content-Type', 'application/json');
                              xhr.onload = function() {
                                  if (xhr.status === 200) {
                                      // Item deleted successfully, remove from DOM
                                   //    parentDiv.remove();
                                      alert('Success: Item deleted.');
                                      window.location.reload(); // Reload the page
                                  } else {
                                      // Handle error
                                      alert('Item could not be deleted.');
                                  }
                              };
                              xhr.onerror = function() {
                                  console.error('Error deleting item. Network error.');
                              };
                              xhr.send(JSON.stringify({ priceId: priceId })); // Sending price-id with the request
                          }
                      }
                  });
              });
          });
     </script>
     

</body>
</html>