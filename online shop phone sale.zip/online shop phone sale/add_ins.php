<?php 
require "connection.php";

 if($_SERVER['REQUEST_METHOD'] == "POST"){
     $brand = $_POST['brand'];
     $model = $_POST['model'];
     $chip = $_POST['chip'];
     $m_cam = $_POST['m_cam'];
     $s_cam = $_POST['s_cam'];
     $display = $_POST['display'];
     $resolution = $_POST['resolution'];
     $os = $_POST['os'];
     $feature = $_POST['feature'];
     $battery = $_POST['battery'];
     $charg = $_POST['charg'];
     $weight = $_POST['weight'];
     $dimen = $_POST['dimen']; 
     $des = $_POST['desc'];

     if(isset($_POST['upload'])){
          if($_FILES['img']['error'] === 4){
               echo "<script>alert('Image Does Not Exist');</script>";
          }
          else{
               $file_name = $_FILES['img']['name'];
               $file_size = $_FILES['img']['size'];
               $tmpName = $_FILES['img']['tmp_name']; 
               
               $validExten = ['jpg', 'jpeg', 'png'];
               $imgExt = explode('.', $file_name);
               $imgExt = strtolower(end($imgExt));
          
               if(!in_array($imgExt, $validExten)){
                   echo "<script>alert('Invalid image extension.');</script>";
               }
               else if($file_size > 1200000){
                    echo "<script>alert('image is too large.');f</script>";
               }
               else{
                    $newImg = uniqid();
                    $newImg .= '.' . $imgExt;
               
                    move_uploaded_file($tmpName, './img/' . $newImg);
                    $query = "INSERT INTO phones (brand, model, description, display, resolution, os, chipset, main_camera, selfie_camera, feature, battery, charging, weight, dimension, img)
                    VALUES 
                    ('$brand', '$model', '$des', '$display', '$resolution', '$os', '$chip', '$m_cam', '$s_cam', '$feature', '$battery', '$charg', '$weight', '$dimen', '$newImg')";
                         
                    mysqli_query($conn, $query);

                    echo "<script>
                         alert('successful added');
                         </script>";    
                         
                    header("location: insert_img.php");
               }
          
          }
     } 
}

?>