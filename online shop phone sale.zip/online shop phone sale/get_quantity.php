<?php
require "connection.php";

// Check if the parameters are set
if (isset($_GET['ram']) && isset($_GET['color'])) {
    // Get conditions from query parameters
    $ram = $_GET['ram'];
    $color = $_GET['color'];

    // Query to retrieve quantity from the SQL table based on conditions using prepared statement
    $sql = "SELECT b.items FROM bibi AS b INNER JOIN select_phones AS s ON b.select_id = s.select_id WHERE b.ram_storage = ? AND s.color = ?";
    
    // Prepare the statement
    $stmt = $conn->prepare($sql);
    
    // Bind parameters
    $stmt->bind_param("ss", $ram, $color);
    
    // Execute the statement
    $stmt->execute();
    
    // Get the result
    $result = $stmt->get_result(); 
    
    if ($result->num_rows > 0) {
        // Output data of the first row
        $row = $result->fetch_assoc();
        $quantity = $row['items'];
        
        // Return quantity as JSON response
        echo json_encode(array("quantity" => $quantity));
    } else {
        // Return 0 if no results found
        echo json_encode(array("quantity" => 0));
    }
    
    // Close the statement
    $stmt->close();
} else {
    // Return an error message if parameters are not provided
    echo json_encode(array("error" => "Missing parameters"));
}

// Close the connection
$conn->close();
?>
