<?php require "connection.php"; ?> 
<?php 
     session_start();
?>

<?php 
$phone = $_GET['phone_id'];

if($_SERVER['REQUEST_METHOD'] == "POST"){
     $in_brand = $_POST['brand'];
     $in_model = $_POST['model'];
     $in_chip = $_POST['chip'];
     $in_m_cam = $_POST['m_cam'];
     $in_s_cam = $_POST['s_cam'];
     $in_display = $_POST['display'];
     $in_resolution = $_POST['resolution'];
     $in_os = $_POST['os'];
     $in_feature = $_POST['feature'];
     $in_battery = $_POST['battery'];
     $in_charg = $_POST['charg'];
     $in_weight = $_POST['weight'];
     $in_dimen = $_POST['dimen']; 
     $in_des = $_POST['desc'];

     $upp_query = "UPDATE phones
     SET brand = '$in_brand',
         model = '$in_model',
         description = '$in_des',
         display = '$in_display',
         resolution = '$in_resolution',
         os = '$in_os',
         chipset = '$in_chip',
         main_camera = '$in_m_cam',
         selfie_camera = '$in_s_cam',
         feature = '$in_feature',
         battery = '$in_battery',
         charging = '$in_charg',
         weight = '$in_weight',
         dimension = '$in_dimen'
     WHERE phone_id = $phone ";
                         
     if(mysqli_query($conn, $upp_query)){
          echo "<script>alert('successful updated')</script>";                         
          header("location: insert_img.php?id=$phone");
     }
     else{
          echo "something is wrong";
     }


}

?>

<!DOCTYPE html>
<html lang="en"> 
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Edit Information</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

     <link rel="icon" href="./img/MicrosoftTeams-image (1).png">

     <style>
          <?php require "admin_home.css"; ?>
          <?php require "bubu_insert.css"; ?>
     </style>

</head>
<body>

     <?php include "admin_header.php" ?>
     
     <?php 
     $query = "select * from phones where phone_id = $phone";
     $res = mysqli_query($conn, $query);
     $row = mysqli_fetch_assoc($res);

     $brand = $row['brand'];
     $model = $row['model'];
     $chip = $row['chipset'];
     $m_cam = $row['main_camera'];
     $s_cam = $row['selfie_camera'];
     $display = $row['display'];
     $resolution = $row['resolution'];
     $os = $row['os'];
     $feature = $row['feature'];
     $battery = $row['battery'];
     $charg = $row['charging'];
     $weight = $row['weight'];
     $dimen = $row['dimension']; 
     $des = $row['description'];
     ?>

     <div class="insert">
          <div class="form">
               <form action="" method="post">
                    <div class="phone_flex">
                         <div class="phone">
                              <div class="phone1">
                                   <p>brand</p>
                                   <input type="text" name="brand" value="<?php echo $brand; ?>" require>
                                   <p>model</p>
                                   <input type="text" name="model" value="<?php echo $model; ?>" require>
                                   <p>chipset</p>
                                   <input type="text" name="chip" value="<?php echo $chip; ?>" require> 
                                   <p>main_camera</p>
                                   <input type="text" name="m_cam" value="<?php echo $m_cam ?>" require>
                                   <p>selfile_camera</p>
                                   <input type="text" name="s_cam" value="<?php echo $s_cam ?>" require>
                                   <p>display</p>
                                   <input type="text" name="display" value="<?php echo $display; ?>" require>
                              </div>
                              <div class="phone1">
                                   <p>resolution</p>
                                   <input type="text" name="resolution" value="<?php echo $resolution; ?>" require>
                                   <p>os</p>
                                   <input type="text" name="os" value="<?php echo $os; ?>" require>
                                   <p>feature</p>
                                   <input type="text" name="feature" value="<?php echo $feature; ?>" require>
                                   <p>battery</p>
                                   <input type="text" name="battery" value="<?php echo $battery ?>" require>
                                   <p>cahrging</p>
                                   <input type="text" name="charg" value="<?php echo $charg; ?>" require>
                                   <p>weight</p>
                                   <input type="text" name="weight" value="<?php echo $weight; ?>" require>
                              </div>
                         </div>
                         <div class="des">
                              <p>dimension</p>
                              <input type="text" name="dimen" value="<?php echo $dimen; ?>" require>
                              <p>description</p>
                              <textarea name="desc"><?php echo $des; ?></textarea>

                              <input class="add_product" type="submit" value="S A V E" name="upload">
                         </div>
                    </div>
               </form>
          </div>
     </div>

     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     <script>
          let menu =document.getElementById('menu');
          let nav = document.querySelector('.navigation');

          menu.addEventListener('click', () => {
               nav.classList.toggle('active');
          })


          document.addEventListener('DOMContentLoaded', function() {
                 // Get the submit button
                 const submitButton = document.querySelector('.add_product');

                 // Add click event listener to the submit button
                 submitButton.addEventListener('click', function(event) {
                     // Prevent the default form submission behavior
                     event.preventDefault();

                     // Get all input elements within the divs with class 'phone1' and 'des'
                     const inputs = document.querySelectorAll('.phone1 input, .des input, .des textarea');

                     // Check if any input value is empty
                     let isEmpty = false;
                     inputs.forEach(input => {
                         if (input.value.trim() === '') {
                             isEmpty = true;
                             return;
                         }
                     });

                     // If any input value is empty, display an alert
                     if (isEmpty) {
                         alert('Please fill in all required fields.');
                     } else {
                         // Submit the form if all fields are filled
                         document.querySelector('form').submit();
                     }
                 });
             });

     </script>

</body>
</html>