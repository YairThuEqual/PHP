<?php

$error = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // email
    if (!empty($_POST['email'])) {
        $email = $_POST['email'];
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { 
            $error['email'] = " invalid email";
        }
    }

    // password
    if (!empty($_POST['password'])) {
        $password = $_POST['password'];
        if (!preg_match("/^[a-zA-Z]+[0-9]+[!@#$%^&*()A-Z]+$/", $password)) {
            $error['password'] = "need characters";
        }
    }

    if (empty($error)) {
        $user_auth_query = sprintf("select user_id,name,email from register where email='%s' and password='%s'", mysqli_real_escape_string($conn, $email), mysqli_real_escape_string($conn, $password));

        $reault = mysqli_query($conn, $user_auth_query);
        $nums_row = mysqli_num_rows($reault);

        if ($nums_row == 0) {
            $error['auth_error'] = "Incorrect email or password";
        } else {
            $row = mysqli_fetch_assoc($reault);
            $_SESSION['ph_email'] = $email;
            $_SESSION['user_id'] = $row['user_id'];
            $_SESSION['user_name'] = $row['name'];

            header("location: index.php");

        }
    }
}
?>
