<?php 
require "connection.php";
session_start();
$user_id = $_SESSION['user_id'];
if($_SERVER['REQUEST_METHOD'] == "POST"){
     $name = $_POST['username'];
     $ph_email = $_POST['ph_email'];
     $ph_no = $_POST['ph_no'];
     $city = $_POST['city'];
     $address = $_POST['address'];
     
     if(isset($_POST['upload'])){
          if($_FILES['img']['error'] === 4){
               echo "<script>alert('Image Does Not Exist');</script>";
               header("location: edit_pfo.php");
          }
          else{
               $file_name = $_FILES['img']['name'];
               $file_size = $_FILES['img']['size'];
               $tmpName = $_FILES['img']['tmp_name']; 
               
               $validExten = ['jpg', 'jpeg', 'png'];
               $imgExt = explode('.', $file_name);
               $imgExt = strtolower(end($imgExt));
          
               if(!in_array($imgExt, $validExten)){
                   echo "<script>alert('Invalid image extension.');</script>";
                   header("location: edit_pfo.php");
               }
               else if($file_size > 1500000){
                    echo "<script>alert('image is too large.');f</script>";
                    header("location: edit_pfo.php");
               }
               else{
                    $newImg = uniqid();
                    $newImg .= '.' . $imgExt;
               
                    move_uploaded_file($tmpName, './img/' . $newImg);
                    
                    $query = "UPDATE register SET name = '$name', email = '$ph_email', phone_number = $ph_no, city = '$city', address = '$address', user_img = '$newImg' WHERE user_id=$user_id;";
                    mysqli_query($conn, $query);

                    echo "<script>
                         alert('successful saved');
                         </script>";    
                         header("location: user.php");
               }
          
          }
     } 
}
// $query = "UPDATE register SET name = '$name', email = '$ph_email', phone_number = $ph_no, city = '$city', address = '$address', user_img = '$newnew' WHERE user_id=$user_id;";
?>