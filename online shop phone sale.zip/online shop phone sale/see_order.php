<?php 
require "connection.php";
session_start();
?>



<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>See Order</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <!-- <link rel="stylesheet" href="./home.css">
     <link rel="stylesheet" href="./cart.css"> -->
     <link rel="icon" href="./img/MicrosoftTeams-image (1).png">
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
     <style>
          <?php require "home.css"; ?>
          <?php require "cart.css"; ?>
     </style>
</head>
<body>
     
     <?php include "header.php"; ?>
 
     <section>
          <div class="shopping">
               <h1 class="nn_order">your order</h1>
               <table>
                    <tr class="titt">
                         <td></td>
                         <td>Model</td>
                         <td>Storage and Color</td>
                         <td>Price(Ks)</td>
                         <td>Date</td>
                    </tr>
                    
                    <?php 
                    if(isset($_SESSION['user_id'])){
                         $user_id = $_SESSION['user_id']; 
                    
                    $sel_or_qry = "SELECT order_id, order_date FROM orders WHERE user_id = $user_id";
                    $sel_or_res = mysqli_query($conn, $sel_or_qry);
                    while($sel_or_row = mysqli_fetch_assoc($sel_or_res)){
                         
                         $ordd_id = $sel_or_row['order_id'];
                         $date = $sel_or_row['order_date'];
                    
                         $main_query = "select * from collect where order_id = $ordd_id";
                         $main_res = mysqli_query($conn, $main_query);

                    while($main_row = mysqli_fetch_assoc($main_res)){
                         $bi_id = $main_row['price_id'];
                         $quanti = $main_row['quantity'];
                         $price = $main_row['price'];
                         // $date = $main_row['order_date'];

                         $com_price = 0;

                         $query = "select * from bibi where price_id = $bi_id";
                         $res = mysqli_query($conn, $query);

                         while($row = mysqli_fetch_assoc($res)){
                              $bi_qty = $row['items'];
                              $ram_sta = $row['ram_storage'];
                              $sel_id = $row['select_id'];
                              $ph_id = $row['phone_id'];
                              $b_item = $row['items'];
                              
                              $com_price = $quanti * $price;

                              $s_query = "select color, img from select_phones where select_id = $sel_id";
                              $s_res = mysqli_query($conn, $s_query);
                              $s_row = mysqli_fetch_assoc($s_res);

                              $color = $s_row['color'];
                              $img = $s_row['img'];

                              $p_query = "select model from phones where phone_id = $ph_id";
                              $p_res = mysqli_query($conn, $p_query);
                              $p_row = mysqli_fetch_assoc($p_res);

                              $model = $p_row['model'];
                         ?>
                    <tr>
                         <td colspan="6"><hr></td>
                    </tr>
                    <tr>
                         <td><img src="./img/<?php echo $img; ?>" alt=""></td>
                         <td><?php echo $model; ?></td>

                         <td class="r_col">
                              <p><?php echo $ram_sta; ?></p>
                              <p><?php echo $color; ?></p>
                         </td>
                         <td><span><?php echo $quanti; ?> x </span><?php echo addCommas($com_price); ?> Ks</td>
                         <td><p><?php echo $date; ?></p></td>
                    </tr>

                    <?php }}} }?>
               </table>
               <hr>
          </div>
     </section>
     <?php include "footer.php"; ?>

<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<?php
function addCommas($number) {
    return number_format($number);
}
?>

<script>
     let search = document.querySelector('.searchBtn')
     let closeBtn = document.querySelector('.closeBtn')
     let searchBox = document.querySelector('.searchBox')
     let nav = document.querySelector('.navigation')
     let menu = document.querySelector('.menuToggle')
     let header = document.querySelector('header')

     search.addEventListener('click', () => {
          searchBox.classList.add('active')
          closeBtn.classList.add('active')
          search.classList.add('active')
          menu.classList.add('hide')
          header.classList.remove('open')
     })

     closeBtn.addEventListener('click', () => {
          searchBox.classList.remove('active')
          closeBtn.classList.remove('active')
          search.classList.remove('active')
          menu.classList.remove('hide')
     })

     menu.addEventListener('click', () =>{
          header.classList.toggle('open')
          searchBox.classList.remove('active')
          closeBtn.classList.remove('active')
          search.classList.remove('active')
     })
</script>
<!-- Include jQuery library -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
     function updateQuantity(button, action, cart_id) {
         var row = button.parentNode.parentNode; // Get the row of the clicked button
         var quantityCell = row.querySelector('.qty'); // Get the cell containing the quantity
         var currentQuantity = parseInt(quantityCell.innerText); // Get the current quantity

         // Perform the action (increment or decrement)
         if (action === 'increment') {
             currentQuantity += 1;
         } else if (action === 'decrement' && currentQuantity > 1) {
             currentQuantity -= 1;
         } else {
             // If action is decrement and current quantity is already 1, do nothing
             return;
         }

         // Update the quantity in the UI
         quantityCell.innerText = currentQuantity;

         // Send an AJAX request to update the quantity in the database
         var xhr = new XMLHttpRequest();
         xhr.open('POST', 'http://localhost/KBTC-Class/PHP_Testing/yairlinthu/cart_update.php', true);
         xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
         xhr.onreadystatechange = function () {
             if (xhr.readyState === 4 && xhr.status === 200) {
                 // Reload the page after the AJAX request completes
                 window.location.reload();
             }
         };
         xhr.send('action=' + action + '&cart_id=' + cart_id + '&quantity=' + currentQuantity);
     }
</script>