<?php require "connection.php"; ?>
<?php session_start(); ?>
<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Favorite</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <!-- <link rel="stylesheet" href="./home.css">
     <link rel="stylesheet" href="./card.css"> -->

     <link rel="icon" href="./img/MicrosoftTeams-image (1).png">

     <style>
          <?php require "home.css"; ?>
          <?php require "card.css"; ?>
     </style>
     
</head>
<body>

    <?php include "header.php"; ?>

     <section id="cards">
          <h1>favorite products</h1>
          <div class="container">
               <div class="cards">

                    <?php 
                         if(isset($_SESSION['user_id'])){
                         $user_id = $_SESSION['user_id']; 
                         $fav_like = "select fav_id, phone_id from favorite where user_id=$user_id";
                         $fav_like_res = mysqli_query($conn, $fav_like);
                         while($fav_row = mysqli_fetch_assoc($fav_like_res)){
                              $fav_id = $fav_row['fav_id'];
                              $id = $fav_row['phone_id'];

                              $query = "SELECT * FROM phones WHERE phone_id=$id ORDER BY phone_id DESC;";
                              $res = mysqli_query($conn, $query);
                              while($row = mysqli_fetch_assoc($res)){
                                   $model = $row['model'];
                                   $img = $row['img'];
                         ?>
                          <div class="card">
                         <a href="add_to_card_copy.php?ph_id=<?php echo $id; ?>">
                              <img class="phone-image" src="./img/<?php echo $img; ?>" alt="">
                         </a>
                         <div class="content">
                              <p class="full-width-text"><?php echo $model; ?></p>
                              <div class="choice">
                         <?php 
                              $se_query = "select color, img, color_code from select_phones where phone_id=$id";
                              $se_res = mysqli_query($conn, $se_query);
                              while($se_row = mysqli_fetch_assoc($se_res)){
                                   $se_img = $se_row['img'];
                                   $se_color = $se_row['color'];
                                   $se_color_code = $se_row['color_code'];

                                   ?>
                                   <div class="choe">

                                        <div class="cho" style="background-color: <?php echo $se_color_code ?>;" onclick="changePhoneImage('img/<?php echo $se_img ?>')"></div>
                                   </div>

                         <?php } ?>
                         </div>
                              </div>
                              <div class="dell">
                                   <a href="fav_del.php?fav_id=<?php echo $fav_id ?>"><ion-icon name="close-outline"></ion-icon></a>
                              </div>
                         </div>
                         <?php }} }?>                         
                                   
                    
               </div>
          </div>
     </section>


    <?php include "footer.php"; ?>
     

     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     <!-- <script src="./nav.js"></script> -->


     <script>
          let search = document.querySelector('.searchBtn')
          let closeBtn = document.querySelector('.closeBtn')
          let searchBox = document.querySelector('.searchBox')
          let nav = document.querySelector('.navigation')
          let menu = document.querySelector('.menuToggle')
          let header = document.querySelector('header')

          search.addEventListener('click', () => {
               searchBox.classList.add('active')
               closeBtn.classList.add('active')
               search.classList.add('active')
               menu.classList.add('hide')
               header.classList.remove('open')
          })

          closeBtn.addEventListener('click', () => {
               searchBox.classList.remove('active')
               closeBtn.classList.remove('active')
               search.classList.remove('active')
               menu.classList.remove('hide')
          })

          menu.addEventListener('click', () =>{
               header.classList.toggle('open')
               searchBox.classList.remove('active')
               closeBtn.classList.remove('active')
               search.classList.remove('active')
          })


          function changePhoneImage(imagePath) {
              var phoneImage = event.currentTarget.closest('.card').querySelector('.phone-image');
              phoneImage.src = imagePath;
 
              // Remove 'active' class from all elements with class 'choe'
              var allChoeElements = document.querySelectorAll('.choe');
              allChoeElements.forEach(function(element) {
                  element.classList.remove('active');
              });
 
              // Add 'active' class to the clicked parent div with class 'choe'
              event.currentTarget.closest('.choe').classList.add('active');
          }
     </script>
 
 

</body>
</html>