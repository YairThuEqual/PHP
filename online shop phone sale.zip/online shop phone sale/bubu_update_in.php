<?php 

if($_SERVER['REQUEST_METHOD'] == "POST"){
     $in_brand = $_POST['brand'];
     $in_model = $_POST['model'];
     $in_chip = $_POST['chip'];
     $in_m_cam = $_POST['m_cam'];
     $in_s_cam = $_POST['s_cam'];
     $in_display = $_POST['display'];
     $in_resolution = $_POST['resolution'];
     $in_os = $_POST['os'];
     $in_feature = $_POST['feature'];
     $in_battery = $_POST['battery'];
     $in_charg = $_POST['charg'];
     $in_weight = $_POST['weight'];
     $in_dimen = $_POST['dimen']; 
     $in_des = $_POST['desc'];

     $upp_query = "UPDATE phones
     SET brand = '$in_brand',
         model = '$in_model',
         description = '$in_des',
         display = '$in_display',
         resolution = '$in_resolution',
         os = '$in_os',
         chipset = '$in_chip',
         main_camera = '$in_m_cam',
         selfie_camera = '$in_s_cam',
         feature = '$in_feature',
         battery = '$in_battery',
         charging = '$in_charg',
         weight = '$in_weight',
         dimension = '$in_dimen'
     WHERE phone_id = $phone ";
                         
     if(mysqli_query($conn, $upp_query)){
          echo "<script>alert('successful updated')</script>";                         
          header("location: insert_img.php?id=$phone");
     }
     else{
          echo "something is wrong";
     }

     
}


?>