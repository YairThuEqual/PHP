<?php require "connection.php"; ?>
<?php 

     $phone_id = $_GET['id'];
     if($_SERVER['REQUEST_METHOD'] == "POST"){
          $color = $_POST['color'];
          $color_code = $_POST['color_code'];
          if(isset($_POST['upload'])){
               if($_FILES['img']['error'] === 4){
                    echo "<script>alert('Image Does Not Exist');</script>";
               }
               else{
                    $file_name = $_FILES['img']['name'];
                    $file_size = $_FILES['img']['size']; 
                    $tmpName = $_FILES['img']['tmp_name']; 
               
                    $validExten = ['jpg', 'jpeg', 'png'];
                    $imgExt = explode('.', $file_name);
                    $imgExt = strtolower(end($imgExt));
          
                    if(!in_array($imgExt, $validExten)){
                        echo "<script>alert('Invalid image extension.');</script>";
                    }
                    else if($file_size > 1200000){
                         echo "<script>alert('image is too large.');f</script>";
                    }
                    else{
                         $newImg = uniqid();
                         $newImg .= '.' . $imgExt;
               
                         move_uploaded_file($tmpName, './img/' . $newImg);

                         $add_query = "INSERT INTO select_phones (phone_id, color, color_code, img)
                                        VALUES ($phone_id, '$color','$color_code', '$newImg');";
                         mysqli_query($conn, $add_query);

                         echo "<script>
                              alert('successful added');
                              </script>";    
                    }
          
               }
          } 

     }

?>
<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Navigation search</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <!-- <link rel="stylesheet" href="./admin_p_img.css"> -->
     <style>
          <?php require "admin_p_img.css"; ?>
          <?php require "admin_home.css"; ?>
     </style>
</head>
<body>

     <?php require "admin_header.php"; ?>

     <div class="choice">
          <div class="c_form">
               <form action="" method="post" enctype="multipart/form-data">
                    <?php 
                    $p_query = "select * from phones where phone_id=$phone_id";
                    $p_ret = mysqli_query($conn, $p_query);
                    while($p_row = mysqli_fetch_assoc($p_ret)){
                         $p_id = $p_row['phone_id'];
                         $p_name = $p_row['model'];
                         // echo "<p>product ID - <span>$p_id</span></p>";
                         echo "<p>product Name - <span>$p_name</span></p>";
                    }
                    ?>                    
                    <p>product image</p>
                    <input type="file" name="img"  accept=".jpg, .jpeg, .png" require>
                    <p>color</p>
                    <input type="text" name="color" require> <br><br>
                    <p>color code</p>
                    <input type="text" name="color_code" require> <br><br>

                    <div class="div">
                         <label for="toggleInputCheckbox">Promotion</label>
                         <input type="checkbox" id="toggleInputCheckbox">

                         <div id="inputBox">
                             <input type="text" id="textInput">
                             <button id="submitButton">update</button>
                         </div>
                    </div>

                    <input type="submit" value="Add selection" name="upload">
               </form>
          </div>

          <div class="c_img">
          <?php
               $query = "select * from select_phones where phone_id = $phone_id";
               $ret = mysqli_query($conn, $query);
               while($row = mysqli_fetch_assoc($ret)){
                    $select_id = $row['select_id'];
                    $color = $row['color']; 
                    $img = $row['img'];

               ?>
                    <div class="c_img_card">
                    <a href="admin_p_price.php?id=<?php echo $select_id; ?>">
                         <img src="./img/<?php echo $img ?>" alt="">
                    </a>
                    <div class="content">
                         <p><?php echo $color; ?></p>
                    </div>

                    <?php 
                         $qry = "select promotion from bibi where phone_id = $phone_id";
                         $q_res = mysqli_query($conn, $qry);
                         $q_row = mysqli_fetch_assoc($q_res);
                         $q_promo = $q_row['promotion'];

                         if($q_promo > 0) {
                              echo " <div class='pro'>
                              <p>$q_promo%</p>
                         </div>";
                         }
                    ?>
                    <!-- <div class="pro">
                         <p><?php echo $q_promo; ?>%</p>
                    </div> -->
               </div>
               <?php } ?>
     
          </div>
     </div>
          <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     <script>
          let menu =document.getElementById('menu');
          let nav = document.querySelector('.navigation'); 

          menu.addEventListener('click', () => {
               nav.classList.toggle('active');
          })

          document.getElementById('toggleInputCheckbox').addEventListener('change', function() {
                  var inputBox = document.getElementById('inputBox');
                  inputBox.style.display = this.checked ? 'block' : 'none';
              });

              document.getElementById('submitButton').addEventListener('click', function() {
                  var textInput = document.getElementById('textInput').value;
                  console.log("Entered text:", textInput);
              });

     </script>
     
     

</body>
</html>