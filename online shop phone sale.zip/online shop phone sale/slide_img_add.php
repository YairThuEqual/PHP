<?php
require "connection.php";
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if a file is uploaded
    if (isset($_FILES["file"]) && $_FILES["file"]["error"] == UPLOAD_ERR_OK) {
        // Directory where the uploaded files will be saved
        $uploadDirectory = "./slide_img/";

        // Generate a unique filename to prevent overwriting existing files
        $filename = uniqid() . "_" . basename($_FILES["file"]["name"]);

        // Path to save the uploaded file
        $uploadFilePath = $uploadDirectory . $filename;

        // Move the uploaded file to the specified directory
        if (move_uploaded_file($_FILES["file"]["tmp_name"], $uploadFilePath)) {
            // File uploaded successfully
            echo "File uploaded successfully.";

            // Get phone_id from the form
            $phone_id = $_POST['phone_id'];

            // SQL query to update image path in phones table
            $sql = "INSERT INTO slides (phone_id, slide_img) VALUES ($phone_id, '$filename');";

            if ($conn->query($sql) === TRUE) {
                echo "Record updated successfully.";
            } else {
                echo "Error updating record: " . $conn->error;
            }

            // Close database connection
            $conn->close();
        } else {
            // Error uploading file
            echo "Sorry, there was an error uploading your file.";
        }
    } else {
        // No file uploaded or error in uploading
        echo "No file uploaded or error in uploading.";
    }
} else {
    // If the form is not submitted via POST method, redirect or show an error message
    echo "Form submission method not allowed.";
}
?>
