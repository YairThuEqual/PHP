<?php require "connection.php"; ?> 
<?php 
     session_start();
?>

<?php 
     if(isset($_GET['ph_name'])){
          $ph_name = $_GET['ph_name'];
     }
?>

<?php 
if($_SERVER['REQUEST_METHOD'] == "POST"){
     $brand = $_POST['brand'];
     $model = $_POST['model'];
     $chip = $_POST['chip'];
     $m_cam = $_POST['m_cam'];
     $s_cam = $_POST['s_cam'];
     $display = $_POST['display'];
     $resolution = $_POST['resolution'];
     $os = $_POST['os'];
     $feature = $_POST['feature'];
     $battery = $_POST['battery'];
     $charg = $_POST['charg'];
     $weight = $_POST['weight'];
     $dimen = $_POST['dimen']; 
     $des = $_POST['desc'];

     // if(isset($_POST['upload'])){
     //      if($_FILES['img']['error'] === 4){
     //           echo "<script>alert('Image Does Not Exist');</script>";
     //      }
     //      else{ 
               $file_name = $_FILES['img']['name'];
               $file_size = $_FILES['img']['size'];
               $tmpName = $_FILES['img']['tmp_name']; 

               echo $tmpName;
               
               $validExten = ['jpg', 'jpeg', 'png'];
               $imgExt = explode('.', $file_name);
               $imgExt = strtolower(end($imgExt));
          
               if(!in_array($imgExt, $validExten)){
                   echo "<script>alert('Invalid image extension.');</script>";
               }
               else if($file_size > 1200000){
                    echo "<script>alert('image is too large.')</script>";
               }
               else{
                    $newImg = uniqid();
                    $newImg .= '.' . $imgExt;
               
                    move_uploaded_file($tmpName, './img/' . $newImg);
                    $query = "INSERT INTO phones (brand, model, description, display, resolution, os, chipset, main_camera, selfie_camera, feature, battery, charging, weight, dimension, img)
                    VALUES 
                    ('$brand', '$model', '$des', '$display', '$resolution', '$os', '$chip', '$m_cam', '$s_cam', '$feature', '$battery', '$charg', '$weight', '$dimen', '$newImg')";
                         
                    mysqli_query($conn, $query);

                    echo "<script>
                         alert('successful added');
                         </script>";    
                         
                    header("location: insert_img.php");
               }
          
          }
//      } 
// }

?>

<!DOCTYPE html>
<html lang="en"> 
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Admin Add Product</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

     <link rel="icon" href="./img/MicrosoftTeams-image (1).png">

     <style>
          <?php require "admin_home.css"; ?>
          <?php require "bubu_insert.css"; ?>
     </style>
     <style>
         


             
     </style>
</head>
<body>

     <header>
         <div class="header">
             <div class="logo">
                 <a href="home_copy.php" class="logo"><img src="./img/MicrosoftTeams-image (1).png" alt=""></a>
             </div>
             <div class="group">
                    <ul class="navigation">
                         <li><a href="admin_index.php">products</a></li>
                         <li><a href="bubu_insert.php">add product</a></li>
                         <li><a href="admin_order.php">orders</a></li>
                         <li><a href="admin_order_finish.php">delivered</a></li>
                         <li><a href="admin_view.php">admins</a></li>
                         <li class="icc"><a href="admin_logout.php"><ion-icon name="log-out-outline" class="log-out-outline"></ion-icon></a></li>
                         <li class="lcc"><a href="admin_logout.php">logout</a></li>
                    </ul>
             </div>
             <div class="menu">
                 <ion-icon id="menu" name="menu-outline"></ion-icon>
             </div>
         </div>

     </header>
     
     <div class="insert">
          <div class="form">
               <form action="bubu_insert_add.php" method="post" enctype="multipart/form-data">
                    <div class="phone_flex">
                         <div class="phone">
                              <div class="phone1">
                                   <p>brand</p>
                                   <input type="text" name="brand" require>
                                   <p>model</p>
                                   <input type="text" name="model" require>
                                   <p>chipset</p>
                                   <input type="text" name="chip" require> 
                                   <p>main_camera</p>
                                   <input type="text" name="m_cam" require>
                                   <p>selfile_camera</p>
                                   <input type="text" name="s_cam" require>
                                   <p>display</p>
                                   <input type="text" name="display" require>
                              </div>
                              <div class="phone1">
                                   <p>resolution</p>
                                   <input type="text" name="resolution" require>
                                   <p>os</p>
                                   <input type="text" name="os" require>
                                   <p>feature</p>
                                   <input type="text" name="feature" require>
                                   <p>battery</p>
                                   <input type="text" name="battery" require>
                                   <p>cahrging</p>
                                   <input type="text" name="charg" require>
                                   <p>weight</p>
                                   <input type="text" name="weight" require>
                              </div>
                         </div>
                         <div class="des">
                              <p>default image</p>
                              <input type="file" name="img" accept=".jpg, .jpeg, .png">
                              <p>dimension</p>
                              <input type="text" name="dimen" require>
                              <p>description</p>
                              <textarea name="desc"></textarea>

                              <input class="add_product" type="submit" value="Add specification" name="upload">
                         </div>
                    </div>
               </form>
          </div>

          <div class="click_bot">
               <div class="click_stick">
                    <form action="" method="get">
                         <input type="search" name="ph_name" id="" placeholder="find model name......" value="<?php if(isset($_GET['ph_name'])) echo $_GET['ph_name'] ?>">
                         <button type="submit"><ion-icon name="search-outline"></ion-icon></button>
                    </form>

                         <div class="phna-container">
                         <?php 
                         if(isset($_GET['ph_name'])){
                              $ph_name = $_GET['ph_name'];

                              $d_query = "SELECT * FROM phones WHERE model LIKE '%$ph_name%' OR brand LIKE '%$ph_name%' ORDER BY phone_id DESC";
                              $ret = mysqli_query($conn, $d_query);
                              while($row = mysqli_fetch_assoc($ret)){
                                   $id = $row['phone_id'];
                                   $model = $row['model'];
                                   echo "<div class='phna'><button><a href='insert_img.php?id=$id'>$model</a></button></div>";
                              }
                         }else{
                              $d_query = "SELECT * FROM phones ORDER BY phone_id DESC LIMIT 10;";
                              $ret = mysqli_query($conn, $d_query);
                              while($row = mysqli_fetch_assoc($ret)){
                                   $id = $row['phone_id'];
                                   $model = $row['model'];
                                   echo "<div class='phna'><button><a href='insert_img.php?id=$id'>$model</a></button></div>";
                              }
                         }
                         ?>
                    </div>
               </div>
          </div>
     </div>

     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     <script>
          let menu =document.getElementById('menu');
          let nav = document.querySelector('.navigation');

          menu.addEventListener('click', () => {
               nav.classList.toggle('active');
          })


          document.addEventListener('DOMContentLoaded', function() {
                 // Get the submit button
                 const submitButton = document.querySelector('.add_product');

                 // Add click event listener to the submit button
                 submitButton.addEventListener('click', function(event) {
                     // Prevent the default form submission behavior
                     event.preventDefault();

                     // Get all input elements within the divs with class 'phone1' and 'des'
                     const inputs = document.querySelectorAll('.phone1 input, .des input, .des textarea');

                     // Check if any input value is empty
                     let isEmpty = false;
                     inputs.forEach(input => {
                         if (input.value.trim() === '') {
                             isEmpty = true;
                             return;
                         }
                     });

                     // If any input value is empty, display an alert
                     if (isEmpty) {
                         alert('Please fill in all required fields.');
                     } else {
                         // Submit the form if all fields are filled
                         document.querySelector('form').submit();
                     }
                 });
             });

     </script>

</body>
</html>