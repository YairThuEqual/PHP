<?php 
//     require "connection.php";
//     if($_SERVER['REQUEST_METHOD'] == 'GET'){
//     $bibi_id = $_GET['bibi_id'];
//     $qty = $_GET['quantity'];
//     $user_id = 1;

//     $bQuery = "select items, phone_id from bibi where price_id = $bibi_id";
//     $bRes = mysqli_query($conn, $bQuery);
//     $bRow = mysqli_fetch_assoc($bRes);
//     $bQty = $bRow['items'];
//     $ph_id = $bRow['phone_id'];

//     $cart_query = "select * from cart where user_id=$user_id and bibi_id=$bibi_id";
//     $cart_res = mysqli_query($conn, $cart_query);
//     $cart_row = mysqli_num_rows($cart_res);    

//     if($cart_row > 0){
//         $cart_rrr = mysqli_fetch_assoc($cart_res);
//         $cart_id = $cart_rrr['cart_id'];
//         $cart_qty = $cart_rrr['quantity'];

//         if($bQty < $cart_qty){
//             echo "<script>alert('exceed out stocks.');</script>";
//             header("location: add_to_card_copy.php?ph_id=$ph_id");
//         }
//         else{
//             $update_query = sprintf("update cart set quantity=%d where cart_id=%d", $cart_qty + $qty , $cart_id);
//             mysqli_query($conn, $update_query);
//             header("location: cart.php");
//             $cart_qty += $qty;
//         }
//     }
//     else{
//         $query = "insert into cart (user_id,bibi_id,quantity) values(?,?,?)";
//         $stmt = mysqli_prepare($conn, $query);
//             // datatype
//         mysqli_stmt_bind_param($stmt, "iis", $user_id, $bibi_id, $qty);
//         mysqli_stmt_execute($stmt);
//         header("location: cart.php");
//     }
// }


require "connection.php";
session_start();

if(isset($_SESSION['user_id'])){
    if($_SERVER['REQUEST_METHOD'] == 'GET'){
        $bibi_id = $_GET['bibi_id'];
        $qty = $_GET['quantity'];
        $user_id = $_SESSION['user_id'];
        $price = $_GET['price'];

        $bQuery = "select items, phone_id from bibi where price_id = $bibi_id";
        $bRes = mysqli_query($conn, $bQuery);
        $bRow = mysqli_fetch_assoc($bRes);
        $bQty = $bRow['items'];
        $ph_id = $bRow['phone_id'];

        $cart_query = "select * from cart where user_id=$user_id and bibi_id=$bibi_id";
        $cart_res = mysqli_query($conn, $cart_query);
        $cart_row = mysqli_num_rows($cart_res);    

        if($cart_row > 0){
            $cart_rrr = mysqli_fetch_assoc($cart_res); 
            $cart_id = $cart_rrr['cart_id'];
            $cart_qty = $cart_rrr['quantity'];

            if($bQty < ($cart_qty + $qty)){
                // Redirect to out of stock page or handle the out of stock scenario
                header("location: add_to_card_copy.php?ph_id=$ph_id&alert=exceed_stock");
                // exit(); // Stop further execution
            }
            else{
                // Update cart quantity
                $new_qty = $cart_qty + $qty;
                $update_query = "update cart set quantity=$new_qty where cart_id=$cart_id";
                mysqli_query($conn, $update_query);
                header("location: cart.php");
                // exit(); // Stop further execution
            }
        }
        else if($bQty == 0){
            header("location: add_to_card_copy.php?ph_id=$ph_id&alert=out_of_stock");
        }
        // else if($bQty < $_)
        else{
            // Insert into cart
            $query = "insert into cart (user_id, bibi_id, quantity, price) values (?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "iisi", $user_id, $bibi_id, $qty, $price);
            mysqli_stmt_execute($stmt);
            header("location: cart.php");
            // exit(); // Stop further execution
        }
    }
}




?>