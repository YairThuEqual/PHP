<?php
session_start();
$user_id = $_SESSION['user_id'];
if(isset($_FILES['file'])) {
    $file = $_FILES['file'];

    if($file['error'] === UPLOAD_ERR_OK) {
        $filename = $file['name'];
        $destination = './img/' . $filename;
        if(move_uploaded_file($file['tmp_name'], $destination)) {
            // Update the image path in the database table
          //   $imageUrl = 'http://localhost/KBTC-Class/PHP_Testing/yairlinthu/' . $destination;
            
            // Perform database connection and update query here
            $servername = "localhost";
            $username = "root";
            $password = "root";
            $dbname = "yairlinthu";
            
            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            
            $sql = "UPDATE register SET user_img='$filename' WHERE user_id=$user_id"; // Adjust your_table and id as needed
            if ($conn->query($sql) === TRUE) {
                echo "Record updated successfully";
            } else {
                echo "Error updating record: " . $conn->error;
            }
            
            $conn->close();
        } else {
            echo "Failed to move the file.";
        }
    } else {
        echo "Error uploading file. Error code: " . $file['error'];
    }
}
?>
