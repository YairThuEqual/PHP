<?php require "connection.php"; ?>


<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Navigation search</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <link rel="stylesheet" href="./home.css">
     <link rel="stylesheet" href="admin_insert.css">
</head>
<body>

     <header>
          <div class="header">
               <a href="" class="logo">logo</a>
               <div class="group">
                    <ul class="navigation">
                         <li><a href="">Home</a></li>
                         <li><a href="">features</a></li>
                         <li><a href="">Services</a></li> 
                         <li><a href="./admin_insert.php">add product</a></li>
                         <li><a href="./admin_select_phone.php">select product</a></li>
                         <!-- <li>
                              <a href="">
                                   <i class="fa-solid fa-bag-shopping"></i>
                                   <span>0</span>
                              </a>
                         </li> -->
                    </ul>
                    <!-- <div class="search">
                         <span class="icon">
                              <ion-icon name="search-outline" class="searchBtn"></ion-icon>
                              <ion-icon name="close-outline" class="closeBtn"></ion-icon>
                         </span>
                    </div> -->
                    <ion-icon name="menu-outline" class="menuToggle"></ion-icon>
               </div>
               <!-- <div class="searchBox">
                    <form action="">
                         <input type="text" placeholder="Search here....">
                    </form>
               </div> -->

          </div>
     </header>

     <?php  
     if(isset($_POST['upload'])){
          // if(isset($_FILES['img'])){
               // $img = $_POST['img'];
               // $ram = $_POST['ram'];
               $ram_storage = $_POST['ram_storage'];
               $color = $_POST['color'];
               $item = $_POST['item'];
               $price = $_POST['price'];
               $a_model = $_POST['a_model'];
     
               if($_FILES['img']['error'] === 4){
                    echo "<script>alert('Image Does Not Exist');</script>";
               }
               else{
                    $file_name = $_FILES['img']['name'];
                    $file_size = $_FILES['img']['size'];
                    $tmpName = $_FILES['img']['tmp_name']; 
          
                    $validExten = ['jpg', 'jpeg', 'png'];
                    $imgExt = explode('.', $file_name);
                    $imgExt = strtolower(end($imgExt));
          
                    if(!in_array($imgExt, $validExten)){
                         echo "<script>alert('Invalid image extension.');</script>";
                    }
                    else if($file_size > 1200000){
                         echo "<script>alert('image is too large.');f</script>";
                    }
                    else{
                         $newImg = uniqid();
                         $newImg .= '.' . $imgExt;
          
                         move_uploaded_file($tmpName, './img/' . $newImg);
     
                         $add_query = "INSERT INTO select_phones (product_id, color, ram_storage, items, price, img)
                         VALUES ($a_model, '$color', '$ram_storage', $item, $price, '$newImg');";
                         mysqli_query($conn, $add_query);
     
                         echo "<script>
                         alert('successful added');
                         </script>";    
                         // header("location: admin_select_phone.php");
                    }
               }    
          // }
          // else{
          //      echo "<script>alert('need phone image')</script>";
          // }
     }
?>

    <div class="select">
          <h1>Kinds of phone selection</h1>

         <form action="" method="post" enctype="multipart/form-data" autocomplete="off">
              <div class="select_add">
                    <p>Select model</p>       
                    <select name="a_model">
                         <option value=""></option>
                    <?php
                         $p_query = "select phone_id, model from phones";
                         $ret = mysqli_query($conn, $p_query);
                         while($row = mysqli_fetch_assoc($ret)){
                              $pid = $row['phone_id'];
                              $model = $row['model'];

                              echo " <option value='$pid'>$model</option>";
                         } 
                         echo "<p>$a_model</p>";
                    ?>
                    </select>
                    <p>Image</p>
                    <input type="file" name="img" accept=".jpg, .jpeg, .png" require>
                    <!-- <p>ram</p>
                    <input type="text" name="ram" require> -->
                    <p>Ram/Storage</p>
                    <input type="text" name="ram_storage" require>
                    <p>color</p>
                    <input type="text" name="color" require>
                    <p>items</p>
                    <input type="text" name="item" require>
                    <p>price</p>
                    <input type="text" name="price" require>

                    <input class="add_list" type="submit" value="Add" name="upload">
               </div>
         </form>
    </div>

     <footer>
          <div class="footer">
               <div class="link"></div>
               <div class="aboutus"></div>
               <div class="contact"></div>
          </div>
     </footer>
     

     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     <script src="nav.js"></script>

</body>
</html>