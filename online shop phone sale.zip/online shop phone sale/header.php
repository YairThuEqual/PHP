<header>
     <div class="header">
          <a href="index.php" class="logo"><img src="./img/MicrosoftTeams-image (1).png" alt=""></a>
          <div class="group">
               <ul class="navigation">
                    <!-- <li><a href="index.php"><i class="fa-solid fa-house"><span class="lisst">home</span></i></a></li> -->
                    <li><a href="index.php">home</a></li>
                    <li class="cate"><a>CATEGORIES<i class="fa-solid fa-caret-down"></i></a>
                         <ul class="more">
                              <?php 
                              // if(isset($_SESSION['email'])){
                                   $query = "SELECT DISTINCT brand FROM phones;";
                                   $res = mysqli_query($conn, $query);
                                   while($row = mysqli_fetch_assoc($res)){
                                        $brand = $row['brand'];
                              ?>
                             
                              <li><a href="select.php?brand=<?php echo $brand ?>"><?php echo $brand; ?></a></li>
                              <?php } ?>
                         </ul>
                    </li>

                   
                    <li class="focus"><a href="favorite.php"><i class="fa-regular fa-heart"><span class="lisst">favorite</span></i></a></li>
                    
                    
                    <li> 
                         <a class="titi" href="cart.php">
                              <?php  
                              if(isset($_SESSION['ph_email'])){
                                   $user_id = $_SESSION['user_id'];
                                   $c_query = "SELECT COUNT(DISTINCT bibi_id) FROM cart WHERE user_id = $user_id;";
                                   $c_res = mysqli_query($conn, $c_query);
                                   $c_row = mysqli_fetch_assoc($c_res);
                                   $quantity = $c_row['COUNT(DISTINCT bibi_id)'];
     
                                   echo "<ion-icon class='bag-outline' name='cart-outline'></ion-icon><span class='couu'>$quantity</span><span class='lisst'>shopping</span>";
                              }
                              else{
                                   echo "<ion-icon class='bag-outline' name='cart-outline'></ion-icon><span class='couu'></span><span class='lisst'>shopping</span>";
                              }
                              ?>
                         </a>
                    </li>
                    <li class="focus"><a href="see_order.php"><i class="fa-regular fa-clock"><span class="lisst">order</span></i></a></li>
                    <?php if(isset($_SESSION['ph_email'])){ ?>
                         <li><a href="user.php"><i class="fa-regular fa-user"><span class="lisst">profile</span></i></a></li>
                    <?php }else{ ?>
                         <li><a href="login.php"><i class="fa-regular fa-user"><span class="lisst">profile</span></i></a></li>
                    <?php } ?>
               </ul>
               <div class="search">
                    <span class="icon">
                         <ion-icon name="search-outline" class="searchBtn"></ion-icon>
                         <ion-icon name="close-outline" class="closeBtn"></ion-icon>
                    </span>
               </div>
               <ion-icon name="menu-outline" class="menuToggle"></ion-icon>
          </div>
          <div class="searchBox">
               <form action="search.php" method="post">
                    <input type="text" name="search" placeholder="Search here....">
               </form>
          </div>

     </div>
</header>
