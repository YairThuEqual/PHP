<?php 
require "connection.php";
session_start();
if(isset($_SESSION['user_id'])){
     $user_id = $_SESSION['user_id']; 
}

if($_SERVER['REQUEST_METHOD'] == "POST"){
     $name = $_POST['name'];
     $email = $_POST['email'];
     $ph_no = $_POST['ph_no'];
     $state = $_POST['state'];
     $township = $_POST['township'];
     $str_add = $_POST['str_add'];
     $add_info = $_POST['add_info'];
     $money = $_POST['money'];
     $status = "delivery";
     $date = date('Y-m-d h:i:s');

     $ins_query = "INSERT INTO orders (user_id, status, name, email, ph_number, township, strt_address, add_info, payment, order_date) 
     VALUES ($user_id, '$status', '$name', '$email', '$ph_no', '$township', '$str_add', '$add_info', '$money', '$date');"; 
     mysqli_query($conn, $ins_query);

     header("location: order_view.php");
}

?>