<?php include "connection.php"; ?>
<?php session_start() ?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Navigation search</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

     <style>
          <?php 
               require "home.css";
               require "card_copy.css";
          ?>
     
     </style>
</head>
<body>  

    <?php include "header.php" ?>     

     <section id="cards">
          <h1>phones</h1>
          <div class="container"> 
               <div class="cards">
                    <button id="left" class="sol"><</button>
                    <div class="main_cards">
                         <?php 
                         $query = "SELECT * FROM phones ORDER BY phone_id DESC LIMIT 10;";
                         $res = mysqli_query($conn, $query);
                         while($row = mysqli_fetch_assoc($res)){
                              $id = $row['phone_id'];
                              $model = $row['model'];
                              $img = $row['img'];
                         ?>
                         <div class="card">
                              <a href="add_to_card_copy.php?ph_id=<?php echo $id; ?>">
                                   <img class="phone-image" src="./img/<?php echo $img; ?>" alt="">
                              </a>
                              <div class="content">
                                   <p><?php echo $model; ?></p>
                                   <div class="choice">
                                   <?php 
                                             $se_query = "select color, img, color_code from select_phones where phone_id=$id";
                                             $se_res = mysqli_query($conn, $se_query);
                                             while($se_row = mysqli_fetch_assoc($se_res)){
                                                  $se_img = $se_row['img'];
                                                  $se_color = $se_row['color'];
                                                  $se_color_code = $se_row['color_code'];

                                                  ?>
                                                  <div class="choe">

                                                       <div class="cho" style="background-color: <?php echo $se_color_code ?>;" onclick="changePhoneImage('img/<?php echo $se_img ?>')"></div>
                                                  </div>

                                                  <?php     
                                             }
                                        ?>
                                   </div>
                                   <!-- <p>select</p> -->
                              </div>
                              <div class="sold">
                                  <p>sold out</p>
                              </div>
                              <div class="promo">
                                   <p>30%<br>off</p>
                              </div>
                         </div>        
                         <?php } ?>
                    </div>
                    <button id="right" class="sol">></button>
               </div>
          </div>
     </section>

     <section>
          <div class="sets">
               <div class="delivery">
                    <a href="">
                         <div class="del">
                              <div class="img"><i class="fa-solid fa-truck"></i></div>
                              <div class="img_test">
                                   <h3>Free Shipping</h3>
                                   <p>for every state</p>
                              </div>
                         </div>
                    </a>
               </div>
               <div class="delivery">
                    <a href="">
                         <div class="del">
                              <div class="img"><i class="fa-solid fa-truck"></i></div>
                              <div class="img_test">
                                   <h3>Free Shipping</h3>
                                   <p>for every state</p>
                              </div>
                         </div>
                    </a>
               </div>
               <div class="delivery">
                    <a href="">
                         <div class="del">
                              <div class="img"><i class="fa-solid fa-truck"></i></div>
                              <div class="img_test">
                                   <h3>Free Shipping</h3>
                                   <p>for every state</p>
                              </div>
                         </div>
                    </a>
               </div>
               <div class="delivery">
                    <a href="">
                         <div class="del">
                              <div class="img"><i class="fa-solid fa-truck"></i></div>
                              <div class="img_test">
                                   <h3>Free Shipping</h3>
                                   <p>for every state</p>
                              </div>
                         </div>
                    </a>
               </div>
          </div>
     </section>

     <footer>
          <div class="footer">
               <div class="contact">
                    <ul>
                         <li><a href="">home</a></li>
                         <li><a href="">about us</a></li>
                         <li><a href="">contact</a></li>
                    </ul>
               </div>

               <div class="logo_fot">
                    <a href=""><img src="./img/MicrosoftTeams-image (1).png" alt=""></a>
               </div>
               <div class="fot_copy">
                   <p> &copy; Copywrite SHIKI MOBILE.com. All Rights Reserved.</p>
               </div>
               
          </div>
          <!-- <div class="aboutus">
               <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3819.1113884198376!2d96.15280407330182!3d16.82082931888294!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30c193e941f2e067%3A0x5e54c9aa66f073eb!2sKBTC%20University-%20School%20of%20IT!5e0!3m2!1sen!2smm!4v1709045314403!5m2!1sen!2smm" width="400" height="270" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
          </div> -->
     </footer>

     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     <script src="./nav.js"></script>

     <script>
          function changePhoneImage(imagePath) {
              var phoneImage = event.currentTarget.closest('.card').querySelector('.phone-image');
              phoneImage.src = imagePath;
 
              // Remove 'active' class from all elements with class 'choe'
              var allChoeElements = document.querySelectorAll('.choe');
              allChoeElements.forEach(function(element) {
                  element.classList.remove('active');
              });
 
              // Add 'active' class to the clicked parent div with class 'choe'
              event.currentTarget.closest('.choe').classList.add('active');
          }

          const initSlider = () => {
               const slideButtons = document.querySelectorAll(".sol");
               const imglist = document.querySelector(".cards .main_cards");
     
               slideButtons.forEach(button => {
                    button.addEventListener('click', () => {
                         const direction = button.id === "left" ? -1 : 1;
                         const scrollAMount = imglist.clientWidth * direction;
                         imglist.scrollBy({left: scrollAMount, behavior: "smooth"});
                    })
               })
     
               const handleScroll = () => {
                    slideButtons[0].style.display = imglist.scrollLeft <= 0 ? "none" : "block";
                    slideButtons[1].style.display = imglist.scrollLeft >= maxSccrollLeft ? "none" : "block";
               }
     
               imglist.addEventListener('scroll', () => {
                    handleScroll();
                    // updateScroll();
               })
          }
          window.addEventListener("load", initSlider);
     </script>
 
 

</body>
</html>