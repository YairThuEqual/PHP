<?php require "connection.php"; ?> 
<?php 
     session_start();
?>



<!DOCTYPE html>
<html lang="en"> 
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Navigation search</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
     <style>
          <?php require "home.css"; ?>
          <?php require "already_cart.css"; ?>
     </style>
</head>
<body>

     <?php include "header.php" ?>
     
     <div class="insert">
          <form id="myForm" action="order.php" method="post">
               <div class="form">
                    <div class="phone_flex">
                    
                         <div class="des">
                              <p>Name <span class="imp">*</span></p>
                              <input type="text" name="name" require>

                              <p>email <span class="imp">*</span></p>
                              <input type="email" name="email" require>

                              <p>phone number <span class="imp">*</span></p>
                              <input type="text" name="ph_no" required>

                              <p>state <span class="imp">*</span></p>
                              <input type="text" name="state" require>

                              <p>township <span class="imp">*</span></p>
                              <input type="text" name="township" require>

                              <p>strees address <span class="imp">*</span></p>
                              <input type="text" name="str_add" require>

                              <p>additional information <span>(for delivery)</span><span class="imp">*</span></p>
                              <textarea name="add_info"></textarea>

                              <!-- <input class="add_product" type="submit" value="Already Order" name="upload"> -->
                         </div>
                    </div>
               </div>

               <div class="click_bot">
                    <div class="click_stick">
                         <h1>your order</h1>       
                         <div class="ship_cart">
                       
                              <div class="title">
                                   <h3>products</h3>
                                   <h3>subtotal</h3>
                              </div>
                              <hr>
                              <?php 

                              $total = 0;
                              $alltotal = 0;
                              
                              $user_id = $_SESSION['user_id'];
                              $query = "select * from cart where user_id= $user_id";
                              $res = mysqli_query($conn, $query);
                              while($row = mysqli_fetch_assoc($res)){
                              $bibi_id = $row['bibi_id'];
                              $qty = $row['quantity'];
                              $price = $row['price'];

                              $sel_query = "SELECT ph.model, sp.color, bb.ram_storage, bb.price FROM phones ph JOIN select_phones sp ON ph.phone_id = sp.phone_id JOIN bibi bb ON sp.select_id = bb.select_id WHERE bb.price_id = $bibi_id;";

                              $sel_res = mysqli_query($conn, $sel_query);
                              $sel_row = mysqli_fetch_assoc($sel_res);

                              $model = $sel_row['model'];
                              $color = $sel_row['color'];
                              $r_sta = $sel_row['ram_storage'];

                              $total = $qty * $price;
                              $alltotal += $total;
                              ?>
                              <div class="title">
                                   <p class="p_name"><?php echo $model; ?>  <?php echo " - $r_sta, $color"; ?></p>
                                   <p><?php echo $qty;?> <span>&Cross;</span> <?php echo addCommas($total); ?></p>
                              </div>
                              <hr>
                              <?php } ?>
                              <div class="title">
                                   <p>subtotal</p>
                                   <p><?php echo addCommas($alltotal) ?></p>
                              </div>
                              <hr>
                              <div class="title">
                                   <p>Delivery</p>
                                   <p>free</p>
                              </div>
                              <hr>
                              <div class="title">
                                   <h2>Total</h2>
                                   <h2><?php echo addCommas($alltotal); ?></h2>
                              </div>
                              
                         </div>
                         <div class="delivery">
                              <h3>choose payment</h3>
                              <div class="main_radi">
                                   <div class="radi">
                                        <input type="radio" name="money" value="kpay">
                                        <label for="kpay"><img src="./img/unnamed.png" alt=""></label>
                                   </div>
                                   <div class="radi">
                                        <input type="radio" name="money" value="ayapay"> 
                                        <label for="ayapay"><img src="./img/aya_pay.jpg" alt=""></label>
                                   </div>
                                   <div class="radi">
                                        <input type="radio" name="money" value="wave">
                                        <label for="wave"><img src="./img/wave.png" alt=""></label>
                                   </div>
                                   <div class="radi">
                                        <input type="radio" name="money" value="truemoney">
                                        <label for="truemoney"><img src="./img/download.jpg" alt=""></label>
                                   </div>
                              </div>
                              <input type="submit" value="Confirm Order" onclick="validateForm(event)">
                         </div>
                    </div>
               </div>
          </form>
     </div>
<?php require "footer.php"; ?>
     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
     <script>
               let search = document.querySelector('.searchBtn')
               let closeBtn = document.querySelector('.closeBtn')
               let searchBox = document.querySelector('.searchBox')
               let nav = document.querySelector('.navigation')
               let menu = document.querySelector('.menuToggle')
               let header = document.querySelector('header')

               search.addEventListener('click', () => {
                    searchBox.classList.add('active')
                    closeBtn.classList.add('active')
                    search.classList.add('active')
                    menu.classList.add('hide')
                    header.classList.remove('open')
               })

               closeBtn.addEventListener('click', () => {
                    searchBox.classList.remove('active')
                    closeBtn.classList.remove('active')
                    search.classList.remove('active')
                    menu.classList.remove('hide')
               })

               menu.addEventListener('click', () =>{
                    header.classList.toggle('open')
                    searchBox.classList.remove('active')
                    closeBtn.classList.remove('active')
                    search.classList.remove('active')
               })
          </script>
          <!-- Include jQuery library --> 
          <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

          <?php
     function addCommas($number) {
         return number_format($number);
     }
     ?>


     <script>
         function validateForm(event) {
               event.preventDefault(); // Prevent form submission
               var name = document.getElementsByName('name')[0].value.trim();
               var email = document.getElementsByName('email')[0].value.trim();
               var ph_no = document.getElementsByName('ph_no')[0].value.trim();
               var state = document.getElementsByName('state')[0].value.trim();
               var township = document.getElementsByName('township')[0].value.trim();
               var str_add = document.getElementsByName('str_add')[0].value.trim();
               var add_info =document.getElementsByName('add_info')[0].value.trim(); 
               var money = document.querySelector('input[name="money"]:checked');

               if (name === '' || email === '' || ph_no === '' || state === '' || township === '' || str_add === '' || add_info === '') {
                    alert('Please fill in all fields');
                    return false; // prevent form submission
               }

               // Validate phone number
               if (!/^(01|09|959)\d{7,9}$/.test(ph_no)) {
               alert('Phone number should start with "01", "09", or "959" and contain 7 to 9 digits');
               return false; // prevent form submission
               }

               // Validate email
               if (!/\S+@\S+\.\S+/.test(email)) {
                    alert('Please enter a valid email address');
                    return false; // prevent form submission
               }

               if (!money) {
                    alert('Please select a payment method');
                    return false; // prevent form submission
               }

               // If all validations pass, submit the form
               document.getElementById('myForm').submit();
          }

         document.getElementById('myForm').addEventListener('submit', validateForm);
     </script>


</body>
</html>