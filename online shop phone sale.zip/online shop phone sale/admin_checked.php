<?php 
     require "connection.php";
     if(isset($_GET['order_id'])){
          $order_id = $_GET['order_id'];

          $e_query = "SELECT r.email FROM register r JOIN orders o ON r.user_id = o.user_id WHERE o.order_id = $order_id";
          $e_res = mysqli_query($conn, $e_query);
          $e_row = mysqli_fetch_assoc($e_res);
          $email = $e_row['email'];

          $query = "UPDATE orders SET status = 'checked' WHERE order_id = $order_id;";
          mysqli_query($conn, $query);

          header("location: admin_order_finish.php");
     }
?>
