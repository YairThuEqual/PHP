<?php
     require "connection.php";

// Handle AJAX request
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['action'], $_POST['cart_id'], $_POST['quantity'])) {
    $action = $_POST['action'];
    $cart_id = $_POST['cart_id'];
    $quantity = $_POST['quantity'];

    // Update quantity in the database
    if ($action === 'increment') {
        $sql = "UPDATE cart SET quantity = quantity + 1 WHERE cart_id = ?";
    } elseif ($action === 'decrement') {
        $sql = "UPDATE cart SET quantity = quantity - 1 WHERE cart_id = ?";
    }

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $cart_id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        // Quantity updated successfully
        echo json_encode(['success' => true]);
    } else {
        // No rows were updated (product not found)
        echo json_encode(['error' => 'Product not found']);
    }

    $stmt->close();
} else {
    // Invalid request
    http_response_code(400);
    echo json_encode(['error' => 'Invalid request']);
}

$conn->close();
?>
