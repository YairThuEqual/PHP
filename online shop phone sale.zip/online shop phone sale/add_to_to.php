<?php include "connection.php" ?>
<?php 
session_start();
     $ph_id = $_GET['ph_id'];
     if(isset($_GET['alert'])) {
          $alert = $_GET['alert'];
          // Display alert based on the parameter
          if($alert === 'exceed_stock') {
              echo "<script>alert('Quantity exceeds available stock.');</script>";
          }else if($alert === 'out_of_stock'){
               echo "<script>alert('Out of stock.');</script>";
          }
      }
?>
<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Navigation search</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <!-- <link rel="stylesheet" href="./home.css"> -->
     <!-- <link rel="stylesheet" href="./card.css"> -->
     <!-- <link rel="stylesheet" href="./add_to_catd.css"> -->
     <style>
          <?php require "home.css"; ?>
          <?php require "add_to_catd.css"; ?>
     </style>
     
</head>
<body >
      <?php require "header.php"; ?>

     <?php 
          $phone_query = "select * from phones where phone_id = $ph_id";
          $res = mysqli_query($conn, $phone_query);

          $row = mysqli_fetch_assoc($res);
               $model = $row['model'];
               $desc = $row['description'];
               $display = $row['display'];
               $resolution = $row['resolution'];
               $os = $row['os'];
               $chip = $row['chipset'];
               $m_cam = $row['main_camera'];
               $s_cam = $row['selfie_camera'];
               $feature = $row['feature'];
               $battery = $row['battery'];
               $charg = $row['charging'];
               $weight = $row['weight'];
               $dimension = $row['dimension'];
               $default_img = $row['img'];
     ?>

     <section id="ccrt">
          <div class="main_product">
               <div class="product">
                    <div class="pro_slide">
                         <div class="slide">
                              <img class="phone_img" src="./img/<?php echo $default_img ?>" alt="">
                              <button class="prev" onclick="moveSlide('prev')">&#10094;</button>
                              <button class="next" onclick="moveSlide('next')">&#10095;</button>
                         </div>
                         <div class="con_slid">
                              <button id="left" class="move_btn">&#10094;</button>
                              <div class="content">
                                   <img class="phone_image" src="./img/<?php echo $default_img ?>" alt="">
                                   <?php 
                                   $sli_qry = "select * from slides where phone_id=$ph_id";
                                   $sli_res = mysqli_query($conn, $sli_qry);
                                   while($sli_row = mysqli_fetch_assoc($sli_res)){
                                        $sli_img = $sli_row['slide_img'];
                                   ?>
                                   <img src="./slide_img/<?php echo $sli_img;?>" alt="">

                                   <?php } ?>
                              </div>
                              <button id="right" class="move_btn">&#10095;</button>
                         </div>
                    </div>
               </div>
               <div class="desc">
                    <div class="text">
                         <h2><?php echo $model; ?></h2>
                         <p><?php echo $desc; ?></p>
                    </div>
                    <div class="add_p">
                         <form action="">
                              
                              <h2 id="price-output"></h2>
                              <h1 id="price-out"></h1>
                              <div class="ram_select">

                              <p class="b_col">Storage: <span id="r_sta_ph"></span></p>

                              <?php 
                                   $bi_query = "SELECT ram_storage FROM bibi WHERE phone_id = $ph_id GROUP BY ram_storage HAVING COUNT(*) > 0;";
                                   $bi_res = mysqli_query($conn, $bi_query);
                                   $bi = 0;
                                   while($bi_row = mysqli_fetch_assoc($bi_res)){
                                        // $s_id = $bi_row['select_id'];
                                        $bi_ram_sto = $bi_row['ram_storage'];

                              ?>
                    
                                   <div class="ram_bord">
                                        <input id="<?php echo $bi += 1;?>ram" type="radio" name="ram" value="<?php echo $bi_ram_sto; ?>">
                                        <label for="<?php echo $bi; ?>ram" class="ram-label"><?php echo $bi_ram_sto; ?></label>
                                   </div>
                                   <?php } ?>
                              </div>

                              
                              <div class="select">
                                   <p class="b_col">Color: <span id="col_ph"></span></p>
                              <?php 
                                   $sel_query = "select * from select_phones where phone_id=$ph_id";
                                   $sel_res = mysqli_query($conn, $sel_query);
                                   $col = 0;
                                   while( $sel_row = mysqli_fetch_assoc($sel_res)){
                                        $sel_color = $sel_row['color'];
                                        $sel_img = $sel_row['img'];
                                        $sel_col_code = $sel_row['color_code'];
                              ?>
                                   <div class="bord">
                                       <input id="<?php echo $sel_color; ?>" type="radio" name="color" value="<?php echo $sel_color; ?>">
                                        <label for="<?php echo $sel_color; ?>" class="radio-label" style="background-color: <?php echo $sel_col_code; ?>;" onclick="changePhoneImage('./img/<?php echo $sel_img ?>')">
                                        </label>
                                   </div>
                                   <?php } ?>
                              </div>
                              <div class="stock">
                                   <div><p id="items_ww"></p></div>
                              </div>
                              <div class="btn_flex">
                                   <div class="add">
                                        <div><button class="minu_btn">-</button></div>
                                        <div><span>1</span></div>
                                        <div><button class="add_btn">+</button></div>
                                   </div>
                                   <div class="add_cart">
                                        <button id="addToCartBtn"><a id="pri_id" href="">Add to Cart</a></button>
                                   </div>
                              </div>
                         </form>
                    </div>
               </div>
          </div>
          <div class="speci">
               <table>
                    <tr>
                         <td>Model</td>
                         <td>-</td>
                         <td><?php echo $model; ?></td>
                    </tr>
                    <tr>
                         <td>Display</td>
                         <td>-</td>
                         <td><?php echo $display; ?></td>
                    </tr>
                    <tr>
                         <td>Resolution</td>
                         <td>-</td>
                         <td><?php echo $resolution; ?></td>
                    </tr>
                    <tr>
                         <td>Os</td>
                         <td>-</td>
                         <td><?php echo $os; ?></td>
                    </tr>
                    <tr>
                         <td>Chipset</td>
                         <td>-</td>
                         <td><?php echo $chip; ?></td>
                    </tr>
                    <tr>
                         <td>Main-camera</td>
                         <td>-</td>
                         <td><?php echo $m_cam; ?></td>
                    </tr>
                    <tr>
                         <td>Selfie-camera</td>
                         <td>-</td>
                         <td><?php echo $s_cam; ?></td>
                    </tr>
                    <tr>
                         <td>Feature</td>
                         <td>-</td>
                         <td><?php echo $feature; ?></td>
                    </tr>
                    <tr>
                         <td>Battery</td>
                         <td>-</td>
                         <td><?php echo $battery; ?></td>
                    </tr>
                    <tr>
                         <td>Carging</td>
                         <td>-</td>
                         <td><?php echo $charg; ?></td>
                    </tr>
                    <tr>
                         <td>Weight</td>
                         <td>-</td>
                         <td><?php echo $weight; ?></td>
                    </tr>
                    <tr>
                         <td>Dimension</td>
                         <td>-</td>
                         <td><?php echo $dimension; ?></td>
                    </tr>
               </table>
          </div>
     </section>
     <?php  ?> 

     <?php require "footer.php"; ?>

     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     <!-- <script src="./nav.js"></script> -->
     <script></script>
     <script>
          let search = document.querySelector('.searchBtn')
          let closeBtn = document.querySelector('.closeBtn')
          let searchBox = document.querySelector('.searchBox')
          let nav = document.querySelector('.navigation')
          let menu = document.querySelector('.menuToggle')
          let header = document.querySelector('header')


          search.addEventListener('click', () => {
               searchBox.classList.add('active')
               closeBtn.classList.add('active')
               search.classList.add('active')
               menu.classList.add('hide')
               header.classList.remove('open')
          })

          closeBtn.addEventListener('click', () => {
               searchBox.classList.remove('active')
               closeBtn.classList.remove('active')
               search.classList.remove('active')
               menu.classList.remove('hide')
          })
          menu.addEventListener('click', () =>{
               header.classList.toggle('open')
               searchBox.classList.remove('active')
               closeBtn.classList.remove('active')
               search.classList.remove('active')
          })
          function reloadPage() {
               window.location.reload(); // Reload the page
          }
          // document.addEventListener('DOMContentLoaded', reloadOnce);

          function changePhoneImage(imagePath) {
               var phoneImage = event.currentTarget.closest('.main_product').querySelector('.phone_img');
              phoneImage.src = imagePath;
              var phoneImg = event.currentTarget.closest('.main_product').querySelector('.phone_image');
              phoneImg.src = imagePath;
 
              // Remove 'active' class from all elements with class 'choe'
               var allChoeElements = document.querySelectorAll('.bord');
               allChoeElements.forEach(function(element) {
                    element.classList.remove('active');
               });
     
               // Add 'active' class to the clicked parent div with class 'choe'
               event.currentTarget.closest('.bord').classList.add('active');
               
          }

          document.addEventListener("DOMContentLoaded", function() {
               var ramLabels = document.querySelectorAll('.ram-label');

              ramLabels.forEach(function(label) {
                  label.addEventListener("click", function() {
                      // Remove 'act' class from all elements with class 'ram-label'
                      ramLabels.forEach(function(element) {
                          element.classList.remove('act');
                      });

                      // Add 'act' class to the clicked label
                      label.classList.add('act');
                  });
              });
          });

          const main_img = document.querySelector(".phone_img");
          const sm_img = document.querySelectorAll(".content img");
          sm_img.forEach((img) => {
               img.addEventListener('click', function() {
                   main_img.src = this.src;
               });
          });
          
          var currentIndex = 0;
          var phoneImage = document.querySelector('.pro_slide .slide .phone_img');

          function moveSlide(direction) {
          if (direction === 'prev') {
               currentIndex = (currentIndex === 0) ? sm_img.length - 1 : currentIndex - 1;
          } else {
               currentIndex = (currentIndex === sm_img.length - 1) ? 0 : currentIndex + 1;
          }
               phoneImage.src = sm_img[currentIndex].src;
          }


          const initSlider = () => {
               const slideButtons = document.querySelectorAll(".move_btn");
               const imglist = document.querySelector(".content");
     
               slideButtons.forEach(button => {
                    button.addEventListener('click', () => {
                         const direction = button.id === "left" ? -1 : 1;
                         const scrollAMount = imglist.clientWidth * direction;
                         imglist.scrollBy({left: scrollAMount, behavior: "smooth"});
                    })
               })
     
               const handleScroll = () => {
                    slideButtons[0].style.display = imglist.scrollLeft <= 0 ? "none" : "block";
                    slideButtons[1].style.display = imglist.scrollLeft >= maxSccrollLeft ? "none" : "block";
               }
     
               imglist.addEventListener('scroll', () => {
                    handleScroll();
               })
  
          }
          window.addEventListener("load", initSlider); 
          
          
          document.addEventListener("DOMContentLoaded", function() {
               var radioInputs = document.querySelectorAll('input[type=radio][name="ram"], input[type=radio][name="color"]');
               const spanElement = document.querySelector(".add span");
               const addButton = document.querySelector(".add_btn");
               const minusButton = document.querySelector(".minu_btn");
               const addToCartBtn = document.getElementById("addToCartBtn");
               const stock_qty = document.getElementById("items_ww");

               // Add event listener for increment button
               addButton.addEventListener("click", function(event) {
                   event.preventDefault();
                   let currentValue = parseInt(spanElement.textContent);
                   spanElement.textContent = currentValue + 1;
                   
                   checkQuantity(stock); // Check quantity after incrementing
               });

               // Add event listener for decrement button
               minusButton.addEventListener("click", function(event) {
                   event.preventDefault();
                   let currentValue = parseInt(spanElement.textContent);
                   if (currentValue > 1) {
                       spanElement.textContent = currentValue - 1;
                   }
                   checkQuantity(stock);
               });

               // Add event listener for radio input changes
               radioInputs.forEach(function(input) {
                   input.addEventListener("change", function() {
                       var ram = document.querySelector('input[name="ram"]:checked').value;
                       var color = document.querySelector('input[name="color"]:checked').value;

                       document.getElementById('r_sta_ph').innerText = ram;
                       document.getElementById('col_ph').innerText = color;

                       var xhr = new XMLHttpRequest();
                       xhr.open("POST", 'http://localhost/KBTC-Class/PHP_Testing/yairlinthu/test/calculate_price.php', true);
                       xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                       xhr.onreadystatechange = function() {
                           if (xhr.readyState === 4 && xhr.status === 200) {
                               var response = JSON.parse(xhr.responseText);
                               var priceOutput = document.getElementById("price-output");

                               var promo = response.discount;
                               var sale = response.saleprice;

                               if (promo != null || promo > 0) {
                                   priceOutput.innerHTML = '<span style="text-decoration: line-through;">' + response.price + ' Ks</span>';
                                   document.getElementById("price-out").textContent = promo + " Ks";
                               } else if (sale != null || sale > 0) {
                                   priceOutput.innerHTML = '<span style="text-decoration: line-through;">' + response.price + ' Ks</span>';
                                   document.getElementById("price-out").textContent = sale + " Ks";
                               } else {
                                   document.getElementById("price-out").style.display = "none";
                                   document.getElementById("price-output").textContent = response.price + " Ks";
                               }

                               document.getElementById("items_ww").textContent = response.item + " stock";
                              let stock = parseInt(stock_qty.textContent);

                              checkQuantity(stock);


                              // if(spanContent >= stock){
                              //      spanElement.textContent = stock;
                              //      addButton.style.display = "none";
                              // }else if(spanContent <= stock){
                              //      spanElement.textContent = 1;
                              //      addButton.style.display = "inline-block";
                              // }

                           }
                       };
                       xhr.send("ram=" + ram + "&color=" + color);
                   });
               });

               // Function to check if spanElement content is greater than SQL table quantity
               async function checkQuantity(stock) {
                   try {
                       let spanContent = parseInt(spanElement.textContent);

                         if(spanContent >= stock){
                              spanElement.textContent = stock;
                              addButton.style.display = "none";
                         }else if(spanContent <= stock){
                              spanElement.textContent = 1;
                              addButton.style.display = "inline-block";
                         }

                    //    if (spanContent >= sqlQuantity) { // Corrected condition here
                    //        spanElement.textContent = sqlQuantity;
                    //        addButton.style.display = "none";
                    //    } else {
                    //        addButton.style.display = "inline-block";
                    //    }
                   } catch (error) {
                       console.error('There was a problem with the fetch operation:', error);
                   }
               }


               

               addToCartBtn.addEventListener("click", function(event) {
                   event.preventDefault();
                   const valueToAddToCart = parseInt(spanElement.textContent);
                   const ramSelected = document.querySelector('input[name="ram"]:checked');
                   const colorSelected = document.querySelector('input[name="color"]:checked');

                   if (!ramSelected || !colorSelected) {
                        alert("Please select both RAM and color options.");
                   } else {
                        const ram = ramSelected.value;
                        const color = colorSelected.value;
                        const quantity = parseInt(valueToAddToCart); // Convert string to integer

                        // Make AJAX request to fetch max available quantity
                        var xhr = new XMLHttpRequest();
                        xhr.open("POST", 'http://localhost/KBTC-Class/PHP_Testing/yairlinthu/test/get_available_quantity_copy.php', true);
                        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                        xhr.onreadystatechange = function() {
                             if (xhr.readyState === 4 && xhr.status === 200) {
                                  var response = JSON.parse(xhr.responseText);
                                  var maxAvailableQuantity = response.maxAvailableQuantity;
                                  var priceId = response.bibi_id; // Assuming price_id is returned in the response
                                  var discount = response.discounted_price;
                                  var sale_price = response.sale_price;
                                  var ori_price = response.price;

                                  if (quantity > maxAvailableQuantity) {
                                       alert("Your selected items exceed the available stock.");
                                  } else {
                                       // Update the href attribute of the anchor tag with the new URL including the price_id

                                       var addToCartLink = document.getElementById("pri_id");
                                       <?php 
                                            if(isset($_SESSION['user_id'])){ ?>
                                                 if(discount > 0){
                                                      addToCartLink.href = "add_cart.php?bibi_id=" + priceId + "&quantity=" + quantity + "&user_quantity=" + maxAvailableQuantity + "&price=" + discount;
                                                 }
                                                 else if(sale_price > 0){
                                                      addToCartLink.href = "add_cart.php?bibi_id=" + priceId + "&quantity=" + quantity + "&user_quantity=" + maxAvailableQuantity + "&price=" + sale_price;
                                                 }else{
                                                      addToCartLink.href = "add_cart.php?bibi_id=" + priceId + "&quantity=" + quantity + "&user_quantity=" + maxAvailableQuantity + "&price=" + ori_price;
                                                 }
                                            <?php } else{ ?>
                                                 addToCartLink.href = "login.php";
                                       <?php } ?>
             
                                       // Redirect to the next page with updated URL
                                       window.location.href = addToCartLink.href;

                                  }
                             }
                        };
                        xhr.send("ram=" + ram + "&color=" + color);
                   }
               });



             

             

          });
      </script>

</body>
</html>