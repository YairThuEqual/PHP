<?php session_start(); ?>
<?php require "connection.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Policy</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <!-- <link rel="stylesheet" href="./home.css">
     <link rel="stylesheet" href="./register.css"> -->
     <link rel="icon" href="./img/MicrosoftTeams-image (1).png">
     <style> 
          <?php require "home.css"; ?>
          <?php require "free_shipping.css"; ?>
     </style>
     
</head>
<body>

     <?php include "header.php"; ?>


     <section id="head_text">
          <div class="heaa">
               <h1>(3) Days Return Policy</h1>
               <ul>
                    <li>If the purchased product has a factory error, or</li>
                    <li>Whether you want to get a refund because you no longer need the purchased item</li>
                    <li>It is necessary to return the product to the shop within (3) days after purchase, without scratches, stains, and complete packaging.</li>
                    <li>Note. Once the item arrives, check if it is the item you ordered before delivery and accept it.</li>
               </ul>
          </div>
     </section>

    
     
     <?php include "footer.php"; ?>
     

     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     
     <script>
          let search = document.querySelector('.searchBtn')
          let closeBtn = document.querySelector('.closeBtn')
          let searchBox = document.querySelector('.searchBox')
          let nav = document.querySelector('.navigation')
          let menu = document.querySelector('.menuToggle')
          let header = document.querySelector('header')

          search.addEventListener('click', () => {
               searchBox.classList.add('active')
               closeBtn.classList.add('active')
               search.classList.add('active')
               menu.classList.add('hide')
               header.classList.remove('open')
          })

          closeBtn.addEventListener('click', () => {
               searchBox.classList.remove('active')
               closeBtn.classList.remove('active')
               search.classList.remove('active')
               menu.classList.remove('hide')
          })

          menu.addEventListener('click', () =>{
               header.classList.toggle('open')
               searchBox.classList.remove('active')
               closeBtn.classList.remove('active')
               search.classList.remove('active')
          })
     </script>
</body>
</html>