<?php
// Database connection parameters
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "your_database_name";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get quantity of the product from the product table
$priceId = $_POST['price_id'];
$quantity = $_POST['quantity'];

$productQuantityResult = $conn->query("SELECT quantity FROM product_table_name WHERE price_id = $priceId");
if ($productQuantityResult->num_rows > 0) {
    $productQuantityRow = $productQuantityResult->fetch_assoc();
    $productQuantity = $productQuantityRow['quantity'];

    // Check if the product with the given price_id already exists in the cart table
    $cartResult = $conn->query("SELECT * FROM cart_table_name WHERE price_id = $priceId");
    if ($cartResult->num_rows > 0) {
        // Product already exists in cart
        $cartRow = $cartResult->fetch_assoc();
        $cartQuantity = $cartRow['quantity'];

        // Check if product quantity is less than cart quantity
        if ($productQuantity < $cartQuantity) {
            // Reduce cart quantity to match available product quantity
            $updateStmt = $conn->prepare("UPDATE cart_table_name SET quantity = ? WHERE price_id = ?");
            $updateStmt->bind_param("ii", $productQuantity, $priceId);
            if ($updateStmt->execute()) {
                echo "Updated quantity in cart to match available product quantity.";
            } else {
                echo "Error updating quantity in cart: " . $updateStmt->error;
            }
        }
    } else {
        // Product does not exist in cart, insert new row
        if ($quantity <= $productQuantity) {
            // Insert into cart only if requested quantity does not exceed available product quantity
            $insertStmt = $conn->prepare("INSERT INTO cart_table_name (price_id, quantity) VALUES (?, ?)");
            $insertStmt->bind_param("ii", $priceId, $quantity);
            if ($insertStmt->execute()) {
                echo "Inserted into cart successfully.";
            } else {
                echo "Error inserting into cart: " . $insertStmt->error;
            }
        } else {
            echo "Error: Requested quantity exceeds available product quantity.";
        }
    }
} else {
    echo "Error: Product not found.";
}

// Close connections
$productQuantityResult->close();
$conn->close();
?>
