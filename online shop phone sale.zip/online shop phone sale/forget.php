<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Gallery</title>
    <style>
        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }

        .image-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 300px; /* Adjust the height as needed */
        }

        img {
            max-width: 100%;
            max-height: 100%;
        }

        .page-indicator {
            display: flex;
            margin-top: 20px;
        }

        .page-indicator span {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background-color: #bbb;
            margin: 0 5px;
            cursor: pointer;
        }

        .active {
            background-color: #555;
        }
    </style>
</head>
<body>
    <?php
        $numberOfImages = 10;

        for ($i = 1; $i <= $numberOfImages; $i++) {
            echo '<div class="image-container" id="page' . $i . '" style="display: ' . ($i === 1 ? 'flex' : 'none') . ';">';
            echo '<img src="image' . $i . '.jpg" alt="Image ' . $i . '">';
            echo '</div>';
        }
    ?>

    <div class="page-indicator">
        <?php
            for ($i = 1; $i <= ceil($numberOfImages / 5); $i++) {
                echo '<span class="' . ($i === 1 ? 'active' : '') . '" onclick="changePage(' . $i . ')"></span>';
            }
        ?>
    </div>

    <script>
        let currentPage = 1;

        function changePage(pageNumber) {
            document.getElementById(`page${currentPage}`).style.display = 'none';
            document.getElementById(`page${pageNumber}`).style.display = 'flex';
            document.querySelector(`.page-indicator .active`).classList.remove('active');
            document.querySelector(`.page-indicator span:nth-child(${pageNumber})`).classList.add('active');
            currentPage = pageNumber;
        }
    </script>
</body>
</html>
