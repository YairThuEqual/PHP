<?php 

     require "connection.php";

     if ($_SERVER["REQUEST_METHOD"] == "POST") {
          // Get the values from the POST request
          $phoneId = $_POST['phoneId'];
          $textInput = $_POST['textInput'];
          
          $query = "UPDATE bibi SET promotion = $textInput WHERE phone_id = $phoneId;";
          mysqli_query($conn, $query);

          echo "Phone ID: " . $phoneId . "<br>";
          echo "Text Input: " . $textInput;

     } else {
          // If the request method is not POST, return an error
          http_response_code(405); // Method Not Allowed
          echo "Error: Only POST requests are allowed.";
     }

?>