<?php 

     require "connection.php";

     if ($_SERVER["REQUEST_METHOD"] == "POST") {

          $phoneId = $_POST['phoneId'];
          $textInput = $_POST['textInput'];
          
          $query = "UPDATE bibi SET sale_price = $textInput WHERE price_id = $phoneId;";
          mysqli_query($conn, $query);

     } else {
          // If the request method is not POST, return an error
          http_response_code(405); // Method Not Allowed
          echo "Error: Only POST requests are allowed.";
     }

?>