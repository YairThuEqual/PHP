<?php
// Establish a database connection
require "connection.php";

// Assuming you have received the select_id and new_image_path from a form or somewhere else
$select_id = $_POST['upd_select_id']; // Change this accordingly

// File handling
$new_image_path = $_FILES['upd_file']['name']; // Get the file name
$target_directory = "./img/"; // Change this to your desired upload directory
$target_file = $target_directory . basename($_FILES["upd_file"]["name"]);

// Check if image file is a actual image or fake image
$check = getimagesize($_FILES["upd_file"]["tmp_name"]);
if($check !== false) {
    echo "File is an image - " . $check["mime"] . ".";
} else {
    echo "File is not an image.";
    exit(); // Terminate script execution if the file is not an image
}

// Move uploaded file to target directory
if (move_uploaded_file($_FILES["upd_file"]["tmp_name"], $target_file)) {
    echo "The file ". basename( $_FILES["upd_file"]["name"]). " has been uploaded.";
} else {
    echo "Sorry, there was an error uploading your file.";
    exit(); // Terminate script execution if file upload fails
}

// Update query
$sql = "UPDATE select_phones
        SET img = '$new_image_path'
        WHERE select_id = $select_id";

if ($conn->query($sql) === TRUE) {
    echo "Image path updated successfully";
} else {
    echo "Error updating image path: " . $conn->error;
}

// Close the database connection
$conn->close();
?>
