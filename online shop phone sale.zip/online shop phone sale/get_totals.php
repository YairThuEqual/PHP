<?php
// Assuming you have a database connection established
require "connection.php";
session_start();
$user_id = $_SESSION['user_id'];
// Query to fetch cart data from the database
$sql = "SELECT cart.quantity, cart.price, bibi.promotion FROM cart JOIN bibi ON cart.bibi_id = bibi.price_id WHERE user_id=$user_id";
$result = $conn->query($sql);

// Initialize total price and total quantity
$total_price = 0;
$total_quantity = 0;

// Calculate totals based on the fetched data
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $total_price += $row['quantity'] * $row['price'];
        $total_quantity += $row['quantity'];
    }
}

// Close the database connection
$conn->close();

// Create an array to hold the totals
$totals = array(
    'total_price' => $total_price,
    'total_items' => $total_quantity
);

// Convert the totals array to JSON format and output it
echo json_encode($totals);
?>
