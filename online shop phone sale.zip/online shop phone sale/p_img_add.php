<?php 

if($_SERVER['REQUEST_METHOD'] == "POST"){
     $color = $_POST['color'];
     $color_code = $_POST['color_code'];
     if(isset($_POST['upload'])){
          if($_FILES['img']['error'] === 4){
               echo "<script>alert('Image Does Not Exist');</script>";
          }
          else{
               $file_name = $_FILES['img']['name'];
               $file_size = $_FILES['img']['size']; 
               $tmpName = $_FILES['img']['tmp_name']; 
               
               $validExten = ['jpg', 'jpeg', 'png'];
               $imgExt = explode('.', $file_name);
               $imgExt = strtolower(end($imgExt));
          
               if(!in_array($imgExt, $validExten)){
                   echo "<script>alert('Invalid image extension.');</script>";
               }
               else if($file_size > 1200000){
                    echo "<script>alert('image is too large.');f</script>";
               }
               else{
                    $newImg = uniqid();
                    $newImg .= '.' . $imgExt;
               
                    move_uploaded_file($tmpName, './img/' . $newImg);

                    $add_query = "INSERT INTO select_phones (phone_id, color, color_code, img)
                                   VALUES ($phone_id, '$color','$color_code', '$newImg');";
                    mysqli_query($conn, $add_query);

                    echo "<script>
                         alert('successful added');
                         </script>";    
                    
               }
          
          }
     } 

}

?>