<?php session_start(); ?>
<?php require "connection.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Free Shipping</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <!-- <link rel="stylesheet" href="./home.css">
     <link rel="stylesheet" href="./register.css"> -->

     <link rel="icon" href="./img/MicrosoftTeams-image (1).png">

     <style> 
          <?php require "home.css"; ?>
          <?php require "free_shipping.css"; ?>
     </style>
     
</head>
<body>

     <?php include "header.php"; ?>


     <section id="head_text">
          <div class="heaa">
               <h1>Delivery (for all cities)</h1>
               <ul>
                    <li>If in Yangon and Mandalay, it will reach the house within the designated area. For customers in other cities/areas, we deliver free of charge to the bus station or relevant delivery service.</li>
                    <li>Home delivery in Yangon and Mandalay for 1,500 kyats</li>
                    <li>For customers in other cities/districts, we deliver to the bus station or relevant delivery service for 1,500 kyats.</li>
                    <li>For orders to be delivered by carport or delivery service, the carport fee or relevant delivery service charges must be paid by the customer only when the product arrives.</li>
                    <li>The color of the item ordered is incorrect, Make sure that there is no damage (mobile phones should be activated only after checking for damage)</li>
                    <li>If you find out that there is a factory error after activation, please send it back to the store within (3) days after purchase, free of scratches and blemishes and complete with packaging. To return the item, please read the Return Policy for full details.</li>
               </ul>
          </div>
     </section>

    
     
     <?php include "footer.php"; ?>
     

     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     
     <script>
          let search = document.querySelector('.searchBtn')
          let closeBtn = document.querySelector('.closeBtn')
          let searchBox = document.querySelector('.searchBox')
          let nav = document.querySelector('.navigation')
          let menu = document.querySelector('.menuToggle')
          let header = document.querySelector('header')

          search.addEventListener('click', () => {
               searchBox.classList.add('active')
               closeBtn.classList.add('active')
               search.classList.add('active')
               menu.classList.add('hide')
               header.classList.remove('open')
          })

          closeBtn.addEventListener('click', () => {
               searchBox.classList.remove('active')
               closeBtn.classList.remove('active')
               search.classList.remove('active')
               menu.classList.remove('hide')
          })

          menu.addEventListener('click', () =>{
               header.classList.toggle('open')
               searchBox.classList.remove('active')
               closeBtn.classList.remove('active')
               search.classList.remove('active')
          })
     </script>
</body>
</html>