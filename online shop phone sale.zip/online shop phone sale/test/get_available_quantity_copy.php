<?php
// Include the connection file
require_once "../connection.php";

// Check if RAM and color values are provided via POST
if(isset($_POST['ram']) && isset($_POST['color'])) {
    // Retrieve the selected RAM and color values
    $ram = $_POST['ram'];
    $color = $_POST['color'];

    // Query to fetch the maximum available quantity based on RAM and color
    $sql = "SELECT b.promotion, b.price, b.items, b.price_id
            FROM bibi AS b 
            INNER JOIN select_phones AS s ON b.select_id = s.select_id 
            WHERE b.ram_storage = ? AND s.color = ?";
    
    // Prepare the SQL statement
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die('Error in preparing the statement.');
    }
    
    // Bind parameters and execute the statement
    $stmt->bind_param("ss", $ram, $color);
    if (!$stmt->execute()) {
        die('Error in executing the statement.');
    }
    
    // Get the result set
    $result = $stmt->get_result();
    
    // Fetch data
    if ($row = $result->fetch_assoc()) {
        // Initialize the response array
        $response = array();
        
        // Check if promotion is available
        if ($row['promotion'] != null) {
            $price = $row['price'];
            $promo = $row['promotion'];
            $discount = $price * ($promo / 100);
            $response['discounted_price'] = $price - $discount;
            
        } 
        // elseif ($row['sale_price'] != null) {
        //     $response['sale_price'] = $row['sale_price'];
        // }
        else{
            $response['price'] = $row['price'];
        }
        
        // Add other details to the response
        $response['max_available_quantity'] = $row['items'];
        $response['bibi_id'] = $row['price_id'];
        
        // Encode the response as JSON and send it to the client
        echo json_encode($response);
    } else {
        // If no results found, you can handle it accordingly
        echo json_encode(['error' => 'No results found']);
    }

    // Close the result set
    $result->close();
} else {
    // Handle the case where RAM or color values are not provided
    echo json_encode(['error' => 'RAM and color values are required.']);
}

// Close the statement and database connection 
$stmt->close();
$conn->close();
?>
