<?php
require "../connection.php";

// Check if it's a POST or DELETE request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Read the JSON input from the request body
    $data = json_decode(file_get_contents('php://input'), true);

    // Check if priceId is provided
    if (isset($data['priceId'])) {
        // Implement your delete logic here
        $priceId = $data['priceId'];

        // Prepare a DELETE statement to delete entries associated with the provided priceId
        $stmt = $conn->prepare("DELETE FROM bibi WHERE price_id = ?");
        $stmt->bind_param("i", $priceId);

        // Execute the statement
        if ($stmt->execute()) {
            // Return success response
            http_response_code(200);
            echo json_encode(array("message" => "Item deleted successfully."));
        } else {
            // Return error response if deletion fails
            http_response_code(500);
            echo json_encode(array("error" => "Error deleting item: " . $conn->error));
        }

        // Close statement
        $stmt->close();
    } else {
        // Return error response if priceId is not provided
        http_response_code(400);
        echo json_encode(array("error" => "Price ID is missing."));
    }
} else {
    // Return error response for unsupported request method
    http_response_code(405);
    echo json_encode(array("error" => "Method not allowed."));
}

// Close connection
$conn->close();
?>
