<?php
// Connect to your database
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = "root"; // Replace with your MySQL password
$dbname = "yairlinthu"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$ram = $_GET['ram'];
$color = $_GET['color'];

// Query to get available quantity from your SQL table
$sql = "SELECT b.items FROM bibi AS b INNER JOIN select_phones AS s ON b.select_id = s.select_id WHERE b.ram_storage = $ram AND s.color = $color"; // Replace with your actual table and condition

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    $row = $result->fetch_assoc();
    $availableQuantity = $row["items"];
    
    // Return available quantity as JSON response
    echo json_encode(array("items" => $availableQuantity));
} else {
    // If no results found, return 0 as available quantity
    echo json_encode(array("items" => 0));
}

$conn->close();
?>
