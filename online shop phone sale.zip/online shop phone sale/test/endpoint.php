<?php
require "../connection.php";

// Check if it's a POST or DELETE request
if ($_SERVER['REQUEST_METHOD'] === 'POST' || $_SERVER['REQUEST_METHOD'] === 'DELETE') {
    // Read the JSON input from the request body
    $data = json_decode(file_get_contents('php://input'), true);

    // Check if selectId is provided
    if (isset($data['selectId'])) {
        // Implement your delete logic here
        $selectId = $data['selectId'];

        // Prepare a DELETE statement to delete select_phones associated with the provided select_id
        $stmt = $conn->prepare("DELETE FROM select_phones WHERE select_id = ?");
        $stmt->bind_param("i", $selectId);

        // Execute the statement
        if ($stmt->execute()) {
            // Return success response
            http_response_code(200);
            echo json_encode(array("message" => "Select phones deleted successfully."));
        } else {
            // Return error response if deletion fails
            http_response_code(500);
            echo json_encode(array("error" => "Error deleting select phones: " . $conn->error));
        }

        // Close statement
        $stmt->close();
    } else {
        // Return error response if selectId is not provided
        http_response_code(400);
        echo json_encode(array("error" => "Select ID is missing."));
    }
} else {
    // Return error response for unsupported request method
    http_response_code(405);
    echo json_encode(array("error" => "Method not allowed."));
}

// Close connection
$conn->close();
?>
