<?php
require "../connection.php";

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection assumed to be established and stored in $conn variable

    // Retrieve POST data
    $ram = $_POST['ram'] ?? '';
    $color = $_POST['color'] ?? '';
    $requestedQuantity = $_POST['quantity'] ?? 1;

    // Prepare SQL statement
    $stmt = $conn->prepare("SELECT b.promotion, b.price, b.items FROM bibi AS b INNER JOIN select_phones AS s ON b.select_id = s.select_id WHERE b.ram_storage = ? AND s.color = ?");
    
    // Bind parameters
    $stmt->bind_param("ss", $ram, $color);

    // Execute statement
    $stmt->execute();

    // Get result
    $result = $stmt->get_result();

    // Check if result exists
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Check if promotion is available
        if ($row['promotion'] != 0) {
            $discountedPrice = $row['price'] - ($row['price'] * ($row['promotion'] / 100));
            $response = [
                'promo' => $row['promotion'],
                'price' => $row['price'],
                'discounted_price' => $discountedPrice, 
                'item' => ($row['items'] > 0) ? $row['items'] : 'out of stock'
            ];
        } 
        // else if ($row['sale_price'] != 0) {
        //     $response = [
        //         'saleprice' => $row['sale_price'],
        //         'price' => $row['price'],
        //         'item' => ($row['items'] > 0) ? $row['items'] : 'out of stock'
        //     ];
        // } 
        else {
            $response = [
                'price' => $row['price'],
                'item' => ($row['items'] > 0) ? $row['items'] : 'out of stock'
            ];
        }
    } else {
        $response = ['error' => 'Product not found'];
    }

    // Encode response as JSON and send to client
    echo json_encode($response);

    // Close statement
    $stmt->close();
}

// Close connection
$conn->close();
?>
