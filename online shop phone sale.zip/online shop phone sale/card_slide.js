const initSlider = () => {
     const slideButtons = document.querySelectorAll(".solid");
     const imglist = document.querySelector(".slide_wrapper .img_list");
     // const slidebar = document.querySelector(".container .scrollbar")
     // const slideThumb = slidebar.querySelector('.scroll_thumb')
     // const maxSccrollLeft = imglist.scrollWidth - imglist.clientWidth;

     // slideThumb.addEventListener('mousedown', (e) => {
     //      const starX = e.clientX;
     //      const thumbPosition = slideThumb.offsetLeft;
 
     //      const handleMouseMove = (e) => {
     //           const deltaX = e.clientX - starX;
     //           const newThumb = thumbPosition + deltaX;
     //           const maxThumb = slidebar.getBoundingClientRect().width - slideThumb.offsetWidth;

     //           const boundPosition = Math.max(0, Math.min(maxThumb, newThumb));
     //           const scrollPosition = (boundPosition / maxThumb) * maxSccrollLeft;

     //           slideThumb.style.left = `${boundPosition}px`;
     //           imglist.scrollLeft = scrollPosition;
     //      }

     //      const handleMouseUp = () => {
     //           document.removeEventListener('mousemove', handleMouseMove);
     //           document.removeEventListener('mouseup', handleMouseUp);
     //      }

     //      document.addEventListener('mousemove', handleMouseMove);
     //      document.addEventListener('mouseup', handleMouseUp);
     // })
     
     slideButtons.forEach(button => {
          button.addEventListener('click', () => {
               const direction = button.id === "left" ? -1 : 1;
               const scrollAMount = imglist.clientWidth * direction;
               imglist.scrollBy({left: scrollAMount, behavior: "smooth"});
          })
     })

     const handleScroll = () => {
          slideButtons[0].style.display = imglist.scrollLeft <= 0 ? "none" : "block";
          slideButtons[1].style.display = imglist.scrollLeft >= maxSccrollLeft ? "none" : "block";
     }

     // const updateScroll = () => {
     //      const scrllPosition = imglist.scrollLeft;
     //      const thumb = (scrllPosition / maxSccrollLeft) * (slidebar.clientWidth - slideThumb.offsetWidth);
     //      slideThumb.style.left = `${thumb}px`;
     // }

     imglist.addEventListener('scroll', () => {
          handleScroll();
          // updateScroll();
     })
}


window.addEventListener("load", initSlider);