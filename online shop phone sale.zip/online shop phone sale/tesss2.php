<?php require "connection.php"; ?> 
<?php 
     session_start();
?>

<?php 
     if($_SERVER['REQUEST_METHOD'] == "POST"){
          $brand = $_POST['brand'];
          $model = $_POST['model'];
          $chip = $_POST['chip'];
          $m_cam = $_POST['m_cam'];
          $s_cam = $_POST['s_cam'];
          $display = $_POST['display'];
          $resolution = $_POST['resolution'];
          $os = $_POST['os'];
          $feature = $_POST['feature'];
          $battery = $_POST['battery'];
          $charg = $_POST['charg'];
          $weight = $_POST['weight'];
          $dimen = $_POST['dimen']; 
          $des = $_POST['desc'];

          if(isset($_POST['upload'])){
               if($_FILES['img']['error'] === 4){
                    echo "<script>alert('Image Does Not Exist');</script>";
               }
               else{
                    $file_name = $_FILES['img']['name'];
                    $file_size = $_FILES['img']['size'];
                    $tmpName = $_FILES['img']['tmp_name']; 
               
                    $validExten = ['jpg', 'jpeg', 'png'];
                    $imgExt = explode('.', $file_name);
                    $imgExt = strtolower(end($imgExt));
          
                    if(!in_array($imgExt, $validExten)){
                        echo "<script>alert('Invalid image extension.');</script>";
                    }
                    else if($file_size > 1200000){
                         echo "<script>alert('image is too large.');f</script>";
                    }
                    else{
                         $newImg = uniqid();
                         $newImg .= '.' . $imgExt;
               
                         move_uploaded_file($tmpName, './img/' . $newImg);
                         $query = "INSERT INTO phones (brand, model, description, display, resolution, os, chipset, main_camera, selfie_camera, feature, battery, charging, weight, dimension, img)
                         VALUES 
                         ('$brand', '$model', '$des', '$display', '$resolution', '$os', '$chip', '$m_cam', '$s_cam', '$feature', '$battery', '$charg', '$weight', '$dimen', '$newImg')";
                         
                         mysqli_query($conn, $query);

                         echo "<script>
                              alert('successful added');
                              </script>";    
                    }
          
               }
          } 
     }

?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Navigation search</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

     <style>
          <?php require "admin_home.css"; ?>
          <?php require "bubu_insert.css"; ?>
     </style>
</head>
<body>

     <?php include "admin_header.php" ?>
     
     <div class="insert">
          <div class="form">
               <form action="" method="post" enctype="multipart/form-data">
                    <div class="phone_flex">
                         <div class="phone">
                              <div class="phone1">
                                   <p>brand</p>
                                   <input type="text" name="brand" require>
                                   <p>model</p>
                                   <input type="text" name="model" require>
                                   <p>chipset</p>
                                   <input type="text" name="chip" require> 
                                   <p>main_camera</p>
                                   <input type="text" name="m_cam" require>
                                   <p>selfile_camera</p>
                                   <input type="text" name="s_cam" require>
                                   <p>display</p>
                                   <input type="text" name="display" require>
                              </div>
                              <div class="phone1">
                                   <p>resolution</p>
                                   <input type="text" name="resolution" require>
                                   <p>os</p>
                                   <input type="text" name="os" require>
                                   <p>feature</p>
                                   <input type="text" name="feature" require>
                                   <p>battery</p>
                                   <input type="text" name="battery" require>
                                   <p>cahrging</p>
                                   <input type="text" name="charg" require>
                                   <p>weight</p>
                                   <input type="text" name="weight" require>
                              </div>
                         </div>
                         <div class="des">
                              <p>default image</p>
                              <input type="file" name="img" accept=".jpg, .jpeg, .png">
                              <p>dimension</p>
                              <input type="text" name="dimen" require>
                              <p>description</p>
                              <textarea name="desc"></textarea>

                              <input class="add_product" type="submit" value="Add specification" name="upload">
                         </div>
                    </div>
               </form>
          </div>

          <div class="click_bot">
               <div class="click_stick">
                    <form action="">
                         <input type="search" name="" id="" placeholder="find model name......">
                         <input type="submit" value="find">
                    </form>

                    <?php 
                         $d_query = "select * from phones";
                         $ret = mysqli_query($conn, $d_query);
                         while($row = mysqli_fetch_assoc($ret)){
                              $id = $row['phone_id'];
                              $model = $row['model'];
                              echo "<button><a href='admin_p_img.php?id=$id'>$model</a></button>";
                         }
                    ?>
                    

               </div>
          </div>
     </div>

     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     <script>
          let menu =document.getElementById('menu');
          let nav = document.querySelector('.navigation');

          menu.addEventListener('click', () => {
               nav.classList.toggle('active');
          })


     </script>

</body>
</html>