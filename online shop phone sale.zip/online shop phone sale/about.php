<?php session_start(); ?>
<?php require "connection.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>About Us</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <!-- <link rel="stylesheet" href="./home.css">
     <link rel="stylesheet" href="./register.css"> -->

     <link rel="icon" href="./img/MicrosoftTeams-image (1).png">

     <style> 
          <?php require "home.css"; ?>
          <?php require "free_shipping.css"; ?>
     </style>
     
</head>
<body>

     <?php include "header.php"; ?>


     <section id="head_text">
          <div class="heaa">
               <h1>About Us</h1>
               <ul>
                    <li>Welcome to our phone selling hub! We're your go-to destination for top-quality smartphones. Explore our collection of cutting-edge devices, handpicked to meet your needs. Whether you're a tech enthusiast or simply seeking reliable communication, we've got you covered. Upgrade your mobile experience with us today!</li>
                    <li>Discover the latest models from leading brands, each packed with innovative features to streamline your life. From stunning displays to powerful cameras, find the perfect phone to suit your style and budget. Plus, our expert team is here to assist you every step of the way. Don't settle for anything less – shop with confidence at our phone selling hub!</li>
               </ul>
          </div>
     </section>

    
     
     <?php include "footer.php"; ?>
     

     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     
     <script>
          let search = document.querySelector('.searchBtn')
          let closeBtn = document.querySelector('.closeBtn')
          let searchBox = document.querySelector('.searchBox')
          let nav = document.querySelector('.navigation')
          let menu = document.querySelector('.menuToggle')
          let header = document.querySelector('header')

          search.addEventListener('click', () => {
               searchBox.classList.add('active')
               closeBtn.classList.add('active')
               search.classList.add('active')
               menu.classList.add('hide')
               header.classList.remove('open')
          })

          closeBtn.addEventListener('click', () => {
               searchBox.classList.remove('active')
               closeBtn.classList.remove('active')
               search.classList.remove('active')
               menu.classList.remove('hide')
          })

          menu.addEventListener('click', () =>{
               header.classList.toggle('open')
               searchBox.classList.remove('active')
               closeBtn.classList.remove('active')
               search.classList.remove('active')
          })
     </script>
</body>
</html>