<?php session_start(); ?>
<?php require "connection.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Payment</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <!-- <link rel="stylesheet" href="./home.css">
     <link rel="stylesheet" href="./register.css"> -->
     <link rel="icon" href="./img/MicrosoftTeams-image (1).png">

     <style> 
          <?php require "home.css"; ?>
          <?php require "free_shipping.css"; ?>
     </style>
     
</head>
<body>

     <?php include "header.php"; ?>


     <section>
          <div class="container">
               <div class="payment">
                    <img src="./img/unnamed.png" alt="">
                    <h3>KBTC School of IT</h3>
                    <p>09784637483</p>
               </div>
               <div class="payment">
                    <img src="./img/aya_pay.jpg" alt="">
                    <h3>KBTC School of IT</h3>
                    <p>09784637483</p>
               </div>
               <div class="payment">
                    <img src="./img/wave.png" alt="">
                    <h3>KBTC School of IT</h3>
                    <p>09784637483</p>
               </div>
               <div class="payment">
                    <img src="./img/download.jpg" alt="">
                    <h3>KBTC School of IT</h3>
                    <p>09784637483</p>
               </div>
          </div>
     </section>

    
     
     <?php include "footer.php"; ?>
     

     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     
     <script>
          let search = document.querySelector('.searchBtn')
          let closeBtn = document.querySelector('.closeBtn')
          let searchBox = document.querySelector('.searchBox')
          let nav = document.querySelector('.navigation')
          let menu = document.querySelector('.menuToggle')
          let header = document.querySelector('header')

          search.addEventListener('click', () => {
               searchBox.classList.add('active')
               closeBtn.classList.add('active')
               search.classList.add('active')
               menu.classList.add('hide')
               header.classList.remove('open')
          })

          closeBtn.addEventListener('click', () => {
               searchBox.classList.remove('active')
               closeBtn.classList.remove('active')
               search.classList.remove('active')
               menu.classList.remove('hide')
          })

          menu.addEventListener('click', () =>{
               header.classList.toggle('open')
               searchBox.classList.remove('active')
               closeBtn.classList.remove('active')
               search.classList.remove('active')
          })
     </script>
</body>
</html>