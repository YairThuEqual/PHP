<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "yairlinthu";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get RAM and color parameters from the AJAX request
// $ram = $_GET['ram'];
// $color = $_GET['color'];
$ram = "8/128";
$color = "purple";

// Debugging: Print out the values of RAM and color
echo "RAM: " . $ram . "<br>";
echo "Color: " . $color . "<br>";

// Prepare and execute the SQL query
$query = "SELECT b.price FROM bibi AS b INNER JOIN select_phones AS s ON b.select_id = s.select_id WHERE b.ram_storage = ? AND s.color = ?";
$stmt = $conn->prepare($query);

if (!$stmt) {
    die("Error in query preparation: " . $conn->error);
}

$stmt->bind_param("ss", $ram, $color);
$stmt->execute();

$result = $stmt->get_result();

// Debugging: Print out the executed SQL query
echo "SQL Query: " . $stmt->execute() . "<br>";

// Check if the query was successful
if ($result) {
     print_r($result);
    // Check if any rows were returned
    if ($result->num_rows > 0) {
        // Fetch the price from the result
        $row = $result->fetch_assoc();
        $price = $row['price'];
        
        // Return the price as JSON
        echo json_encode(array('price' => $price));
    } else {
        // No rows returned
        echo json_encode(array('error' => 'No price found for the specified parameters'));
    }
} else {
    // Error in query execution
    echo json_encode(array('error' => 'Failed to execute query: ' . $conn->error));
}

// Close the database connection
$stmt->close();
$conn->close();
?>
