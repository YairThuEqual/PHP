<?php require "connection.php"; ?>
<?php 

     $s_bi_id = $_GET['bi_id'];
     $id = $_GET['id'];

     if($_SERVER['REQUEST_METHOD'] == 'POST'){
          $ram_sta = $_POST['ram_sta'];
          $price = $_POST['price'];
          $item = $_POST['item'];

          $up_query = "UPDATE bibi SET ram_storage = '$ram_sta', price = $price, items = $item WHERE price_id = $s_bi_id;";
          if(mysqli_query($conn, $up_query)){
               // echo "<script>alert('update success.')</script>";
               header("location: admin_p_price.php?id=$id");
          }
          else{
               echo "<script>alert('something is wrong.')</script>";
          }
 
     }

?>
<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8"> 
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Edit Price</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <link rel="stylesheet" href="home.css">
     <!-- <link rel="stylesheet" href="./admin_p_price.css"> -->
     <link rel="icon" href="./img/MicrosoftTeams-image (1).png">
     <style>
          <?php require "sale_p.css"; ?>
          <?php require "admin_home.css"; ?>
     </style>
</head>
<body>

   <?php require "admin_header.php" ?>
     <div class="choice">
          <div class="c_form">
               <form action="" method="post">
                    <?php 
                         $vi_query = "SELECT b.price, b.ram_storage, b.items, b.sale_price, sp.img, b.price FROM bibi AS b JOIN select_phones AS sp ON b.select_id = sp.select_id WHERE price_id=$s_bi_id";
                         $vi_res = mysqli_query($conn, $vi_query);
                         $vi_row = mysqli_fetch_assoc($vi_res);
     
                         $vi_img = $vi_row['img'];
                         $vi_sta = $vi_row['ram_storage'];
                         $vi_pri = $vi_row['price'];
                         $vi_ite = $vi_row['items'];
                         $vi_sale = $vi_row['sale_price'];
                    ?>         

                    
                    <p class='cici'><img src='./img/<?php echo $vi_img; ?>'></p>
                    <p>ram/Storage <span class="span">(only write ep. 6/128)</span></p>
                    <input type="text" name="ram_sta" value="<?php echo $vi_sta; ?>" require>
                    <p>itmes <span class="span">(only number)</span></p>
                    <input type="number" name="item" value="<?php echo $vi_ite; ?>" require>
                    <p>price <span class="span">(only number)</span></p>
                    <input type="number" name="price" value="<?php echo $vi_pri; ?>" require>
                    <br><br>

                         <!-- <div class="div">
                              <label for="toggleInputCheckbox">Sale Price</label>
                              <input type="checkbox" id="toggleInputCheckbox">

                              <div id="inputBox">
                              <input type="number" id="textInput" value="<?php echo $vi_sale; ?>" placeholder="only number">
                              <input type="hidden" id="phoneIdInput" value="<?php echo $s_bi_id; ?>">
                              <button id="submitButton">sale price</button>
                              </div>

                              <div id="output"></div>
                         </div> -->
                    
                    <input type="submit" value="Update">
               </form>
          </div>
     </div>
     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     <script>
          let menu =document.getElementById('menu');
          let nav = document.querySelector('.navigation');

          menu.addEventListener('click', () => {
               nav.classList.toggle('active');
          })

          // document.getElementById('toggleInputCheckbox').addEventListener('change', function() {
          //         var inputBox = document.getElementById('inputBox');
          //         inputBox.style.display = this.checked ? 'block' : 'none';
          //     });

          document.getElementById('submitButton').addEventListener('click', function() {
                  var textInput = document.getElementById('textInput').value;
                  console.log("Entered text:", textInput);
          });

          // document.getElementById('toggleInputCheckbox').addEventListener('change', function() {
          //         var inputBox = document.getElementById('inputBox');  
          //         inputBox.style.display = this.checked ? 'block' : 'none';
          //     });


              document.getElementById('submitButton').addEventListener('click', function() {
              var textInput = document.getElementById('textInput').value;
              var phoneId = document.getElementById('phoneIdInput').value; // Get phone_id value

              // Check if textInput is empty
              if (textInput.trim() === '') {
                  alert('Please enter some text before submitting.');
                  return; // Exit the function if textInput is empty
              }

              var xhr = new XMLHttpRequest();
              xhr.onreadystatechange = function() {
                  if (xhr.readyState == XMLHttpRequest.DONE) {
                      if (xhr.status == 200) {
                          alert('Successfully update.');
                          // window.location.reload(); // Reload the page
                          window.location.href = 'admin_p_price.php?id=<?php echo $id ?>';
                      } else {
                          alert('Error:', xhr.status);
                      }
                  }
              };
              xhr.open('POST', 'http://localhost/KBTC-Class/PHP_Testing/yairlinthu/sale_p_sale.php', true);
              xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
              xhr.send('phoneId=' + encodeURIComponent(phoneId) + '&textInput=' + encodeURIComponent(textInput)); // Send both input values to PHP script
          });


     </script>
     

</body>
</html>