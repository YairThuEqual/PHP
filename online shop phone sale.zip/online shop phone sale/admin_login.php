<?php session_start(); ?>
<?php require "connection.php"; ?>
<?php include "admin_login_validation.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Admin Login</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <!-- <link rel="stylesheet" href="./home.css">
     <link rel="stylesheet" href="./register.css"> -->
     <link rel="icon" href="./img/MicrosoftTeams-image (1).png">

     <style>
          <?php require "admin_home.css"; ?>
          <?php require "admin_register.css"; ?>
     </style>
     
</head>
<body>



     <section id="sect">
          <form class="regi" method="post" action="#">
               <h1>login</h1>
               <h3 class="error"><?php if(isset($error['auth_error'])) echo $error['auth_error']; ?></h3>

               <p>Email<span class="error">*</span></p>
               <span class="error"><?php if(isset($error['email'])) echo $error['email'] ?></span>
               <input type="email" placeholder="Email" name="email" value="<?php if(isset($email)) echo $email; ?>" required>

               <p>Password <span>(at least 8 character.(letter, number, character))</span><span class="error">*</span></p>
               <span class="error"><?php if(isset($error['password'])) echo $error['password']; ?></span>
               <input type="password" id="password" placeholder="Password" name="password" value="<?php if(isset($password)) echo $password; ?>" required>

               <div class="flex">
                   <div class="see">
                       <input type="checkbox" id="showPasswordCheckbox">
                       <label for="showPasswordCheckbox">See Password</label>
                   </div>
                   <!-- <div class="link">
                       <span><a href="register.html">Create Account!</a></span>
                   </div> -->
               </div>
               <input type="submit" value="Login">
           </form>
     </section>
     
     



     

          <script>
               document.addEventListener('DOMContentLoaded', function() {

                    
                    const passwordInput = document.getElementById('password');
                    const showPasswordCheckbox = document.getElementById('showPasswordCheckbox');
          
                    if (!passwordInput || !showPasswordCheckbox) {
                         console.error('One or more elements not found.');
                         return;
                    }
          
                    showPasswordCheckbox.addEventListener('change', function() {
                         if (showPasswordCheckbox.checked) {
                              passwordInput.type = 'text';
                         } else {
                              passwordInput.type = 'password';
                         }
                    });


                    const loginForm = document.querySelector('.regi');
                    let loginAttempts = 0;

                    loginForm.addEventListener('submit', function(event) {
                         loginAttempts++;
                         console.log(loginAttempts);

                         // Check if login attempts exceed 5
                         if (loginAttempts >= 5) {
                              // Disable submit button
                              document.querySelector('.regi input[type="submit"]').disabled = true;

                              // After 5 seconds, enable submit button again
                              setTimeout(function() {
                                   document.querySelector('.regi input[type="submit"]').disabled = false;
                                   loginAttempts = 0; // Reset login attempts
                              }, 5000);
                         }
                    });
               });
          </script>
</body>
</html>