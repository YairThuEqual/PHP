<?php 
     require "connection.php";
     $fav_id = $_GET['fav_id'];

     $query = "DELETE FROM favorite WHERE fav_id=$fav_id";
     $res = mysqli_query($conn, $query);

     header("location: favorite.php")

?>