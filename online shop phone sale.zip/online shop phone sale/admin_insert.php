<?php include "connection.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Navigation search</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <!-- <link rel="stylesheet" href="./home.css"> -->
     <!-- <link rel="stylesheet" href="admin_insert.css"> -->
     <style>
          <?php require "admin_insert.css"; ?>
          <?php require "home.css"; ?>
     </style>
</head>
<body>

     <header>
          <div class="header">
               <a href="" class="logo">logo</a>
               <div class="group">
                    <ul class="navigation">
                         <li><a href="">Home</a></li>
                         <li><a href="">features</a></li>
                         <li><a href="">Services</a></li> 
                         <li><a href="./admin_insert.php">add product</a></li>
                         <li><a href="./admin_select_phone.php">select product</a></li>
                         <!-- <li>
                              <a href="">
                                   <i class="fa-solid fa-bag-shopping"></i>
                                   <span>0</span>
                              </a>
                         </li> -->
                    </ul>
                    <!-- <div class="search">
                         <span class="icon">
                              <ion-icon name="search-outline" class="searchBtn"></ion-icon>
                              <ion-icon name="close-outline" class="closeBtn"></ion-icon>
                         </span>
                    </div> -->
                    <ion-icon name="menu-outline" class="menuToggle"></ion-icon>
               </div>
               <!-- <div class="searchBox">
                    <form action="">
                         <input type="text" placeholder="Search here....">
                    </form>
               </div> -->

          </div>
     </header>

    <div class="insert">

          <h1>Add to phone devices</h1>

         <form action="add_select.php" method="post">
               <div class="phone_flex">
                    <div class="phone">
                         <div class="phone1">
                              <p>brand</p>
                              <input type="text" name="brand" require>
                              <p>model</p>
                              <input type="text" name="model" require>
                              <p>chipset</p>
                              <input type="text" name="chip" require> 
                              <p>main_camera</p>
                              <input type="text" name="m_cam" require>
                              <p>selfile_camera</p>
                              <input type="text" name="s_cam" require>
                              <p>display</p>
                              <input type="text" name="display" require>
                         </div>
                         <div class="phone1">
                              <p>resolution</p>
                              <input type="text" name="resolution" require>
                              <p>os</p>
                              <input type="text" name="os" require>
                              <p>feature</p>
                              <input type="text" name="feature" require>
                              <p>battery</p>
                              <input type="text" name="battery" require>
                              <p>cahrging</p>
                              <input type="text" name="charg" require>
                              <p>weight</p>
                              <input type="text" name="weight" require>
                         </div>
                    </div>
                    <div class="des">
                         <p>dimension</p>
                         <input type="text" name="dimen" require>
                         <p>description</p>
                         <textarea name="desc"></textarea>

                         <input class="add_product" type="submit" value="Add product">
                    </div>
               </div>
         </form>
    </div>

     <footer>
          <div class="footer">
               <div class="link"></div>
               <div class="aboutus"></div>
               <div class="contact"></div>
          </div>
     </footer>
     

     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     <script src="nav.js"></script>

</body>
</html>