<section>
     <div class="sets">
          <div class="delivery">
               <a href="free_shipping.php">
                    <div class="del">
                         <div class="img"><i class="fa-solid fa-truck"></i></div>
                         <div class="img_test">
                              <h3>Free Shipping</h3>
                              <p>for every state</p>
                         </div>
                    </div>
               </a>
          </div>
          <div class="delivery">
               <a href="policy.php">
                    <div class="del">
                         <div class="img"><i class="fa-solid fa-robot"></i></div>
                         <div class="img_test">
                              <h3>3 Days Return Policy</h3> 
                              <p>Return within 3 Days</p>
                         </div>
                    </div>
               </a>
          </div>
          <div class="delivery">
               <a href="payment.php">
                    <div class="del">
                         <div class="img"><i class="fa-regular fa-credit-card"></i></div>
                         <div class="img_test">
                              <h3>Easy Payment</h3>
                              <p>Pay with various payment method</p>
                         </div>
                    </div>
               </a>
          </div>
          <div class="delivery">
               <a href="fast_delivery.php">
                    <div class="del">
                         <div class="img"><i class="fa-solid fa-truck-ramp-box"></i></div>
                         <div class="img_test">
                              <h3>Fast Delivery</h3>
                              <p>2 Days Delivery in YGN & MDY</p>
                         </div>
                    </div>
               </a>
          </div> 
     </div>
</section>

<footer>
     <div class="footer">
          <div class="contact">
               <ul>
                    <li><a href="index.php">home</a></li>
                    <li><a href="about.php">about us</a></li>
                    <li><a href="contact.php">contact</a></li>
               </ul>
          </div>

          <div class="logo_fot">
               <a href="index.php"><img src="./img/MicrosoftTeams-image (1).png" alt=""></a>
          </div>
          <div class="fot_copy">
              <p> &copy; Copywrite SHIKI MOBILE.com. All Rights Reserved.</p>
          </div>
               
     </div>
     <!-- <div class="aboutus">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3819.1113884198376!2d96.15280407330182!3d16.82082931888294!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30c193e941f2e067%3A0x5e54c9aa66f073eb!2sKBTC%20University-%20School%20of%20IT!5e0!3m2!1sen!2smm!4v1709045314403!5m2!1sen!2smm" width="400" height="270" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
     </div> -->
</footer>