<?php 

$conn = mysqli_connect("localhost", "root", "root", "yairlinthu") or die ("can't connect" . mysqli_error($conn));

?>