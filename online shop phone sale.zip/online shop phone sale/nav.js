let search = document.querySelector('.searchBtn')
let closeBtn = document.querySelector('.closeBtn')
let searchBox = document.querySelector('.searchBox')
let nav = document.querySelector('.navigation')
let menu = document.querySelector('.menuToggle')
let header = document.querySelector('header')

search.addEventListener('click', () => {
     searchBox.classList.add('active')
     closeBtn.classList.add('active')
     search.classList.add('active')
     menu.classList.add('hide')
     header.classList.remove('open')
})

closeBtn.addEventListener('click', () => {
     searchBox.classList.remove('active')
     closeBtn.classList.remove('active')
     search.classList.remove('active')
     menu.classList.remove('hide')
})

menu.addEventListener = ('click', () =>{
     header.classList.toggle('open')
     searchBox.classList.remove('active')
     closeBtn.classList.remove('active')
     search.classList.remove('active')
})