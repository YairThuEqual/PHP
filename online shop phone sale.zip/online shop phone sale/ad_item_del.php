<?php
// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the itemId is set in the POST data
    if (isset($_POST["itemId"])) {
        // Sanitize the itemId to prevent SQL injection or other attacks
        $itemId = filter_var($_POST["itemId"], FILTER_SANITIZE_STRING);

        // Perform the deletion operation
        $deleted = deleteItemFromDatabase($itemId);

        if ($deleted) {
            // If deletion is successful, respond with HTTP status code 200
            http_response_code(200);
            echo "Item deleted successfully";
        } else {
            // If deletion fails, respond with an appropriate error message and HTTP status code
            http_response_code(500);
            echo "Error deleting item";
        }
    } else {
        // If itemId is not set in the POST data, respond with an error message and HTTP status code
        http_response_code(400);
        echo "Item ID is missing";
    }
} else {
    // If the request method is not POST, respond with an error message and HTTP status code
    http_response_code(405);
    echo "Method Not Allowed";
}

// Function to delete an item from the database
function deleteItemFromDatabase($itemId) {
   require "connection.php";

    // Prepare the deletion query
    $sql = "DELETE FROM phones WHERE phone_id = ?";

    // Prepare and bind the statement
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $itemId);

    // Execute the statement
    $result = $stmt->execute();

    // Close the statement and connection
    $stmt->close();
    $conn->close();

    // Return true if deletion is successful, false otherwise
    return $result;
}
?>
