<?php require "connection.php"; ?>
<?php session_start(); ?>

<?php
if(isset($_SESSION['admin_id'])){
     $admin_id = $_SESSION['admin_id']; 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Admin Home</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <!-- <link rel="stylesheet" href="./home.css">
     <link rel="stylesheet" href="./card.css"> -->
     <link rel="icon" href="./img/MicrosoftTeams-image (1).png">

     <style>
          <?php require "admin_home.css"; ?>
          <?php require "admin_card.css"; ?>
     </style>
     
</head>
<body>

    <?php include "admin_header.php"; ?>
    <?php 
           $pro_query = "SELECT bibi.* FROM bibi INNER JOIN ( SELECT phone_id, MAX(price_id) AS max_price_id FROM bibi WHERE promotion > 0 GROUP BY phone_id ) AS max_price ON bibi.phone_id = max_price.phone_id AND bibi.price_id = max_price.max_price_id";
           $pro_res = mysqli_query($conn, $pro_query);
           if(mysqli_num_rows($pro_res) > 0){
          ?>

          <section id="cards">
               <h1>promotion products</h1>
               <div class="container">
                    <div class="cards">
                         <?php 
                              while($pro_row = mysqli_fetch_assoc($pro_res)){
                                   $pro_id = $pro_row['phone_id'];
                              $query = "SELECT * FROM phones WHERE phone_id = $pro_id ORDER BY phone_id DESC;";

                              // $query = "SELECT * FROM phones ORDER BY phone_id DESC;";
                              $res = mysqli_query($conn, $query);
                              while($row = mysqli_fetch_assoc($res)){
                                   $id = $row['phone_id'];
                                   $model = $row['model'];
                                   $img = $row['img'];
                              ?>
                              <div class="card">
                                   <a>
                                        <img class="phone-image" src="./img/<?php echo $img; ?>" alt="">
                                   </a>
                              <div class="content">
                                   <p class="full-width-text"><?php echo $model; ?></p>
                                   <div class="choice">
                              <?php 
                                   $se_query = "select color, img, color_code from select_phones where phone_id=$id";
                                   $se_res = mysqli_query($conn, $se_query);
                                   while($se_row = mysqli_fetch_assoc($se_res)){
                                        $se_img = $se_row['img'];
                                        $se_color = $se_row['color'];
                                        $se_color_code = $se_row['color_code'];

                                        ?>
                                        <div class="choe">

                                             <div class="cho" style="background-color: <?php echo $se_color_code ?>;" onclick="changePhoneImage('img/<?php echo $se_img ?>')"></div>
                                        </div>

                              <?php } ?>
                              </div>
                                        <!-- <p>select</p> -->
                                   </div>
                                   <?php 
                                   $qty_query = "SELECT SUM(items) AS total_quantity, promotion FROM bibi WHERE phone_id = $id GROUP BY promotion";
                                   $qty_res = mysqli_query($conn, $qty_query);
                                   $qty_row = mysqli_fetch_assoc($qty_res);
                                   $qty_qty = $qty_row['total_quantity'];
                                   $qty_pro = $qty_row['promotion'];

                                   if($qty_qty == 0){
                                   ?>
                                   <div class="sold">
                                        <p>sold out</p> 
                                   </div>
                                   <?php } ?>

                                   <?php
                                   if($qty_pro > 0){
                                   ?>
                                   <div class="promo">
                                        <p><?php echo $qty_pro; ?>% off</p>
                                   </div>
                                   <?php } ?>
                              

                                   <!-- <div class="dell">
                                       <a href=""><ion-icon name="trash-outline"></ion-icon></a>
                                   </div> -->
                                   <div class="upda">
                                        <a href="insert_img.php?id=<?php echo $id; ?>"><ion-icon name="create-outline"></ion-icon></a>
                                   </div>

                              </div>
                              <?php 
                              }}
                         ?>                          
                    </div>
               </div>
          </section>
     <?php } ?>


     <section id="cards">
     <h1>all products</h1>
     <div class="container">
          <div class="cards">
               <?php 
                     $pro_query = "SELECT DISTINCT phone_id FROM bibi WHERE promotion IS NULL OR promotion = 0 ORDER BY phone_id DESC;";
                     $pro_res = mysqli_query($conn, $pro_query);
                     if(mysqli_num_rows($pro_res) > 0){
                     while($pro_row = mysqli_fetch_assoc($pro_res)){
                          $pro_id = $pro_row['phone_id'];
                          
                     $query = "SELECT * FROM phones WHERE phone_id = $pro_id";

                    // $query = "SELECT * FROM phones ORDER BY phone_id DESC;";
                    $res = mysqli_query($conn, $query);
                    while($row = mysqli_fetch_assoc($res)){
                         $id = $row['phone_id'];
                         $model = $row['model'];
                         $img = $row['img'];
                    ?>
                     <div class="card">
                    <a>
                         <div class="ididi">
                         <img class="phone-image" src="./img/<?php echo $img; ?>" alt="">
                         </div>
                    </a>
                    <div class="content">
                         <p class="full-width-text"><?php echo $model; ?></p>
                         <div class="choice">
                    <?php 
                         $se_query = "select color, img, color_code from select_phones where phone_id=$id";
                         $se_res = mysqli_query($conn, $se_query);
                         while($se_row = mysqli_fetch_assoc($se_res)){
                              $se_img = $se_row['img'];
                              $se_color = $se_row['color'];
                              $se_color_code = $se_row['color_code'];

                              ?>
                              <div class="choe">

                                   <div class="cho" style="background-color: <?php echo $se_color_code ?>;" onclick="changePhoneImage('img/<?php echo $se_img ?>')"></div>
                              </div>

                    <?php } ?>
                    </div>
                              <!-- <p>select</p> -->
                         </div>
                         <?php 
                         $qty_query = "SELECT SUM(items) AS total_quantity, promotion FROM bibi WHERE phone_id = $id GROUP BY promotion";
                         $qty_res = mysqli_query($conn, $qty_query);
                         $qty_row = mysqli_fetch_assoc($qty_res);
                         $qty_qty = $qty_row['total_quantity'];
                         $qty_pro = $qty_row['promotion'];

                         if($qty_qty == 0){
                         ?>
                         <div class="sold">
                              <p>sold out</p>
                         </div>
                         <?php } ?>

                         <?php
                         if($qty_pro > 0){
                         ?>
                         <div class="promo">
                              <p><?php echo $qty_pro; ?>% off</p>
                         </div>
                         <?php } ?>
                              
                         <!-- <div class="dell">
                             <a href=""><ion-icon name="trash-outline"></ion-icon></a>
                         </div> -->
                         <div class="upda">
                              <a href="insert_img.php?id=<?php echo $id; ?>"><ion-icon name="create-outline"></ion-icon></a>
                         </div>
                    </div>
                    <?php 
                    }}}
               ?>                          
          </div>
     </div>
</section>
     

     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     <script>
          let menu =document.getElementById('menu');
          let nav = document.querySelector('.navigation');

          menu.addEventListener('click', () => {
               nav.classList.toggle('active');
          })

          function changePhoneImage(imagePath) {
              var phoneImage = event.currentTarget.closest('.card').querySelector('.phone-image');
              phoneImage.src = imagePath;
 
              // Remove 'active' class from all elements with class 'choe'
              var allChoeElements = document.querySelectorAll('.choe');
              allChoeElements.forEach(function(element) {
                  element.classList.remove('active');
              });
 
              // Add 'active' class to the clicked parent div with class 'choe'
              event.currentTarget.closest('.choe').classList.add('active');
          }
     </script>
 
 

</body>
</html>