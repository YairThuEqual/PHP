<?php


     $name = $email = $password = $cpassword = $phone = $address = $city = "";
     $error = array();
     
     if($_SERVER['REQUEST_METHOD'] == 'POST'){
     
          // username
          if(!empty($_POST['name'])){
               $name = $_POST['name'];
               if(!preg_match("/^[a-zA-Z ]*$/", $name)){
                    $error['name'] = " *only letter and space.";
               }
          }

           // email
          if(!empty($_POST['email'])){
               $email = $_POST['email'];
               if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
                    $error['email'] = "*invalid email";
               }
          }

          // password
          if(!empty($_POST['password'])){
               $password = $_POST['password'];
               if(!preg_match("/^[a-zA-Z]+[0-9]+[!@#$%^&*()A-Z]+$/", $password)){
                    $error['password'] = "*need characters";
               }
          }

          // comfirm password
          if(!empty($_POST['cpassword'])){
               $cpassword = $_POST['cpassword'];
               if($cpassword != $password){
                    $error['cpassword'] = "*not same password";
               }
          }

          // city
          if(!empty($_POST['city'])){
               $city = $_POST['city'];
               if($city == ''){
                    $error['city'] = "fill in";
               }  
          }
          
          // address
          if(!empty($_POST['address'])){
               $address = $_POST['address'];
               if($address == ''){
                    $error['address'] = "fill in";
               }
          }

          // phone
          if (!empty($_POST['phone'])) {
               $phone = $_POST['phone'];
               // Remove all characters except digits from the phone number
               $phone = preg_replace('/\D/', '', $phone);
               // Check if the phone number matches the specified format
               if (!preg_match("/^(01|09|959)\d{7,9}$/", $phone)) {
                   $error['phone'] = " *Invalid phone number.";
               }
           }
 

          if(empty($error)){

               // $dulicate_query = "select * from users where email='$email'";
               // $result = mysqli_query($conn, $dulicate_query);
               
               $dulicate_query = sprintf("select * from admin where email='%s'", mysqli_real_escape_string($conn, $email));
               // $dulicate_query_name = sprintf("select * from users where u ser_name='%s'", mysqli_real_escape_string($conn, $name));
               $result = mysqli_query($conn, $dulicate_query);
               // $result = mysqli_query($conn, $dulicate_query_name);
               $row = mysqli_num_rows($result);
               
               if($row > 0){
                    $error['dup_mail'] = "email already exist"; 
               }
               else{
                    $insert_query = "insert into admin(name,password,email, phone_number, city, address) values(?,?,?,?,?,?);";
                    if($stmt = mysqli_prepare($conn, $insert_query)){
                                                  // datatype
                         mysqli_stmt_bind_param($stmt, "ssssss", $name, $password, $email, $phone, $city, $address);
                         $name = $_POST['name'];
                         $password = $_POST['password'];
                         $email = $_POST['email'];
                         mysqli_stmt_execute($stmt);

                         header("location: admin_view.php");
                    }
                        
               }
          }
     }
?>
