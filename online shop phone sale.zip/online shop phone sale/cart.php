<?php require "connection.php"; ?>
<?php session_start(); ?>
<?php 

?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Cart</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <!-- <link rel="stylesheet" href="./home.css">
     <link rel="stylesheet" href="./cart.css"> -->
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
     <link rel="icon" href="./img/MicrosoftTeams-image (1).png">
     <style>
          <?php require "home.css"; ?>
          <?php require "cart.css"; ?>
     </style>
</head>
<body>
     
     <?php include "header.php"; ?>
 
     <section>

          <div class="shopping">
          <h1 class="nn_order">your choose items</h1>

               <table>
                    <tr class="titt">
                         <td></td>
                         <td>Model</td>
                         <td>Storage and Color</td>
                         <!-- <td>color</td> -->
                         <td>Quantity</td>
                         <td>Price(Ks)</td>
                         <td></td>
                    </tr>
                    <?php 
                    if(isset($_SESSION['user_id'])){
                         $user_id = $_SESSION['user_id']; 
                    $main_query = "select * from cart where user_id = $user_id";
                    $main_res = mysqli_query($conn, $main_query);
                    $com_qty = 0;
                    $com_price = 0;
                    $com_total = 0;

                    while($main_row = mysqli_fetch_assoc($main_res)){
                         $bi_id = $main_row['bibi_id'];
                         $quanti = $main_row['quantity'];
                         $cart_id = $main_row['cart_id'];
                         $price = $main_row['price'];

                         $com_qty += $quanti;

                         $query = "select * from bibi where price_id = $bi_id";
                         $res = mysqli_query($conn, $query);

                         while($row = mysqli_fetch_assoc($res)){
                              $bi_qty = $row['items'];
                              $ram_sta = $row['ram_storage'];
                              $sel_id = $row['select_id'];
                              $ph_id = $row['phone_id'];
                              $b_item = $row['items'];
                              $b_promo = $row['promotion'];
                              // $price = $row['price'];
                              
                              $com_price = $quanti * $price;
                              $com_total += $com_price;

                              $s_query = "select color, img from select_phones where select_id = $sel_id";
                              $s_res = mysqli_query($conn, $s_query);
                              $s_row = mysqli_fetch_assoc($s_res);

                              $color = $s_row['color'];
                              $img = $s_row['img'];

                              $p_query = "select model from phones where phone_id = $ph_id";
                              $p_res = mysqli_query($conn, $p_query);
                              $p_row = mysqli_fetch_assoc($p_res);

                              $model = $p_row['model'];
                              ?>
                    <tr>
                         <td colspan="7"><hr></td>
                    </tr>
                    <tr>
                         <td><img src="./img/<?php echo $img; ?>" alt=""></td>
                         <td><?php echo $model; ?></td>

                         <td class="r_col">
                              <p><?php echo $ram_sta; ?></p>
                              <p><?php echo $color; ?></p>
                         </td>
                         <td>
                              <div class="quantity">
                                   <p><button class="btn" onclick="updateQuantity(this, 'decrement', <?php echo $cart_id; ?>)"><i class="fa-solid fa-minus"></i></button></p>
                                   <p class="qty"><?php echo $quanti ?></p>
                                   <?php if($quanti < $bi_qty){ ?>

                                        <p><button class="btn"  onclick="updateQuantity(this, 'increment', <?php echo $cart_id; ?>)"><i class="fa-solid fa-plus"></i></button></p>
                                        
                                   <?php } ?>
                              </div>
                         </td>
                         <td><span><?php echo $quanti; ?> x </span><?php echo addCommas($com_price); ?> Ks</td>
                         <td><button class="deleteBtn" data-cart-id="<?php echo $cart_id; ?>" data-bi-id="<?php echo $bi_id ?>" data-quantity="<?php echo $quanti ?>"><i class="fa-solid fa-trash-can"></i></button></td>
                    </tr>
                    <?php }}} ?>
               </table>
               <hr>

               <div class="summory" id="summarySection">
                    <h3>SUBTOTAL</h3>
                    <div class="price">
                           <p>Items</p>
                           <p id="totalItems"></p>
                    </div>
                    <!-- <div class="price">
                           <p>Delivery</p>
                           <p>3000</p>
                    </div> -->
                    <div class="price">
                           <p>Total</p>
                           <p id="totalPrice"></p>
                    </div>
                    <a href="already_cart.php"><button id="confirmOrderBtn">Checkout Products</button></a>
               </div>
          </div>
     </section>


     <?php include "footer.php"; ?>

     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     <?php
     function addCommas($number) {
         return number_format($number);
     }
     ?>

     <script>
          let search = document.querySelector('.searchBtn')
          let closeBtn = document.querySelector('.closeBtn')
          let searchBox = document.querySelector('.searchBox')
          let nav = document.querySelector('.navigation')
          let menu = document.querySelector('.menuToggle')
          let header = document.querySelector('header')

          search.addEventListener('click', () => {
               searchBox.classList.add('active')
               closeBtn.classList.add('active')
               search.classList.add('active')
               menu.classList.add('hide')
               header.classList.remove('open')
          })

          closeBtn.addEventListener('click', () => {
               searchBox.classList.remove('active')
               closeBtn.classList.remove('active')
               search.classList.remove('active')
               menu.classList.remove('hide')
          })

          menu.addEventListener('click', () =>{
               header.classList.toggle('open')
               searchBox.classList.remove('active')
               closeBtn.classList.remove('active')
               search.classList.remove('active')
          })
     </script>
     <!-- Include jQuery library -->
     <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

     <!-- JavaScript to handle deletion -->
     <script> 

          $(document).ready(function() {

              // Function to update total price and total items
              function updateTotals() {
                   // Check if $_SESSION['user_id'] is not available
                   if (!("<?php echo isset($_SESSION['user_id']); ?>" === '1')) {
                       // Hide the summarySection
                       $("#summarySection").hide();
                       return; // If user_id is not available, exit the function
                   }

                    // Function to add commas to numbers
                    function addCommas(number) {
                        return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                    }

                    // AJAX request to fetch totals
                    $.ajax({
                        url: "http://localhost/KBTC-Class/PHP_Testing/yairlinthu/get_totals.php",
                        method: "GET",
                        success: function(response) {
                            var totals = JSON.parse(response);
                            $("#totalItems").text(totals.total_items);
        
                            // Format the total price and set it to the element with id 'totalPrice'
                            $("#totalPrice").text(addCommas(totals.total_price)); // Assuming delivery is fixed at 3000

                            // Show or hide the summary section based on total items
                            if (totals.total_items == 0) {
                                $("#summarySection").hide();
                            } else {
                                $("#summarySection").show();
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error(xhr.responseText);
                            alert("Error occurred while updating totals!");
                        }
                    });

               }


               // Call updateTotals function on page load
               updateTotals();

               $(".deleteBtn").click(function() {
                   // Store the reference to the current button element
                   var currentButton = $(this);

                   // Show a confirmation dialog
                   var confirmDelete = confirm("Are you sure you want to delete this item?");
                   if (!confirmDelete) {
                       return; // If user cancels, do nothing
                   }

                   // Prevent the default action of the button
                   event.preventDefault();

                   // Get the cart_id, bi_id, and quantity from the data attributes
                   var cartId = currentButton.data("cart-id");
                   var biId = currentButton.data("bi-id"); // Retrieve bi_id
                   var quantity = currentButton.data("quantity");

                   // Send AJAX request to delete_cart.php with cart_id and bi_id as parameters
                   $.ajax({
                       url: "http://localhost/KBTC-Class/PHP_Testing/yairlinthu/delete_cart.php",
                       method: "GET",
                       data: { cart_id: cartId, bi_id: biId, quantity: quantity }, // Include bi_id in the data sent
                       success: function(response) {
                           // If deletion is successful, remove the corresponding row from the table
                           currentButton.closest("tr").remove();
                           alert("Item deleted successfully!");

                           // Update total price and total items after successful deletion
                           updateTotals();

                           // Reload the page after deletion
                           location.reload();
                       },
                       error: function(xhr, status, error) {
                           console.error(xhr.responseText);
                           alert("Error occurred while deleting item!");
                       }
                   });
               });



          });


          function updateQuantity(button, action, cart_id) {
              var row = button.parentNode.parentNode; // Get the row of the clicked button
              var quantityCell = row.querySelector('.qty'); // Get the cell containing the quantity
              var currentQuantity = parseInt(quantityCell.innerText); // Get the current quantity

              // Perform the action (increment or decrement)
              if (action === 'increment') {
                  currentQuantity += 1;
              } else if (action === 'decrement' && currentQuantity > 1) {
                  currentQuantity -= 1;
              } else {
                  // If action is decrement and current quantity is already 1, do nothing
                  return;
              }

              // Update the quantity in the UI
              quantityCell.innerText = currentQuantity;

              // Send an AJAX request to update the quantity in the database
              var xhr = new XMLHttpRequest();
              xhr.open('POST', 'http://localhost/KBTC-Class/PHP_Testing/yairlinthu/cart_update.php', true);
              xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
              xhr.onreadystatechange = function () {
                  if (xhr.readyState === 4 && xhr.status === 200) {
                      // Reload the page after the AJAX request completes
                      window.location.reload();
                  }
              };
              xhr.send('action=' + action + '&cart_id=' + cart_id + '&quantity=' + currentQuantity);
          }


     </script>

</body>
</html>