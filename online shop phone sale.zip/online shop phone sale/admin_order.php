<?php require "connection.php"; ?>
<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">

<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Order View</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
          integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
          crossorigin="anonymous" referrerpolicy="no-referrer" />
     <!-- <link rel="stylesheet" href="./home.css">
     <link rel="stylesheet" href="./card.css"> -->

     <link rel="icon" href="./img/MicrosoftTeams-image (1).png">

     <style>
          <?php require "admin_home.css"; ?>
          <?php require "admin_order.css"; ?>
     </style>





</head>

<body>

     <!-- SELECT order_id FROM orders WHERE order_date BETWEEN '2024-03-08' AND '2024-03-10'; -->
     <?php include "admin_header.php"; ?>

     <section>
          <div class="filter">
               <form action="" method="post">
                    <div class="move">
                         <div class="date">
                              <label for="">Start Date: </label>
                              <input type="date" name="start" id="start" onchange="setMinEndDate()">
                         </div>
                         <div class="date">
                              <label for="">End Date: </label>
                              <input type="date" name="end" id="end">
                         </div>
                         <input type="submit" value="search">
                    </div>
     </form>
          </div>
     </section>


     <section>
          <div class="main_card">
               <?php
               if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset ($_POST['start']) && isset ($_POST['end'])) {
                    $start_date = date("Y-m_d", strtotime($_POST['start']));
                    $end_date = date("Y-m_d", strtotime($_POST['end'])); ?>

                    <script>
                         document.getElementById('start').value = '<?php echo $_POST['start']; ?>';
                         document.getElementById('end').value = '<?php echo $_POST['end']; ?>';
                    </script>

                    <?php
                    if (!empty ($_POST['start']) && !empty ($_POST['end'])) {

                         $srh_query = "SELECT order_id FROM orders WHERE order_date BETWEEN '$start_date' AND '$end_date';";
                         $srh_res = mysqli_query($conn, $srh_query);

                         while ($srh_row = mysqli_fetch_assoc($srh_res)) {
                              $od_id = $srh_row['order_id'];


                              $query = "SELECT * FROM orders WHERE status = 'delivery' AND order_id = $od_id ORDER BY order_date DESC";
                              $res = mysqli_query($conn, $query);
                              while ($row = mysqli_fetch_assoc($res)) {
                                   $order_id = $row['order_id'];
                                   $status = $row['status'];
                                   $date = $row['order_date'];
                                   $user = $row['user_id'];

                                   $emm_qry = "select email from register where user_id = $user";
                                   $emm_res = mysqli_query($conn, $emm_qry);
                                   $emm_row = mysqli_fetch_assoc($emm_res);
                                   $email = $emm_row['email'];
                                   $total = 0;
                                   ?>

                                   <div class="card">
                                        <div class="card_head">
                                             <h4>
                                                  <?php echo $email; ?>
                                             </h4>
                                             <p><a href="admin_view_order.php?order_id=<?php echo $order_id; ?>">view</a></p>
                                        </div>
                                        <div class="info">

                                             <?php
                                             $coll_qry = "select * from collect where order_id = $order_id";
                                             $coll_res = mysqli_query($conn, $coll_qry);
                                             while ($coll_row = mysqli_fetch_assoc($coll_res)) {
                                                  $price_id = $coll_row['price_id'];
                                                  $qty = $coll_row['quantity'];
                                                  $price = $coll_row['price'];

                                                  $total += $qty * $price;

                                                  $select_qry = "SELECT p.model, b.ram_storage, s.color FROM phones p JOIN bibi b ON p.phone_id = b.phone_id JOIN select_phones s ON s.select_id = b.select_id WHERE b.price_id = $price_id;";
                                                  $select_res = mysqli_query($conn, $select_qry);
                                                  $select_row = mysqli_fetch_assoc($select_res);
                                                  $model = $select_row['model'];
                                                  $r_sta = $select_row['ram_storage'];
                                                  $color = $select_row['color'];

                                                  echo "<p>$model - $r_sta, $color</p>";
                                             }
                                             ?>

                                             <!-- <p>product name - ram, color</p> -->

                                             <div class="total">
                                                  <h3>Total price -
                                                       <?php echo $total; ?>
                                                  </h3>
                                                  <h3>Date -
                                                       <?php echo $date; ?>
                                                  </h3>
                                             </div>
                                             <?php
                                             if ($status == "delivery") {

                                                  ?>
                                                  <div class="btn">
                                                       <span class="check"><i class="fa-solid fa-truck"></i>
                                                            <?php echo $status; ?>
                                                       </span>
                                                  </div>
                                             <?php } else { ?>
                                                  <div class="btn">
                                                       <span class="check"><i class="fa-solid fa-check-to-slot"></i>
                                                            <?php echo $status; ?>
                                                       </span>
                                                  </div>
                                             <?php } ?>
                                        </div>
                                   </div>
                              <?php }
                         }
                    } else { ?>

                         <?php
                         $query = "SELECT * FROM orders WHERE status = 'delivery' ORDER BY order_date";
                         $res = mysqli_query($conn, $query);
                         while ($row = mysqli_fetch_assoc($res)) {
                              $order_id = $row['order_id'];
                              $status = $row['status'];
                              $date = $row['order_date'];
                              $user = $row['user_id'];

                              $emm_qry = "select email from register where user_id = $user";
                              $emm_res = mysqli_query($conn, $emm_qry);
                              $emm_row = mysqli_fetch_assoc($emm_res);
                              $email = $emm_row['email'];
                              $total = 0;
                              ?>
                              <div class="card">
                                   <div class="card_head">
                                        <h4>
                                             <?php echo $email; ?>
                                        </h4>
                                        <p><a href="admin_view_order.php?order_id=<?php echo $order_id; ?>">view</a></p>
                                   </div>
                                   <div class="info">

                                        <?php
                                        $coll_qry = "select * from collect where order_id = $order_id";
                                        $coll_res = mysqli_query($conn, $coll_qry);
                                        while ($coll_row = mysqli_fetch_assoc($coll_res)) {
                                             $price_id = $coll_row['price_id'];
                                             $qty = $coll_row['quantity'];
                                             $price = $coll_row['price'];

                                             $total += $qty * $price;

                                             $select_qry = "SELECT p.model, b.ram_storage, s.color FROM phones p JOIN bibi b ON p.phone_id = b.phone_id JOIN select_phones s ON s.select_id = b.select_id WHERE b.price_id = $price_id;";
                                             $select_res = mysqli_query($conn, $select_qry);
                                             $select_row = mysqli_fetch_assoc($select_res);
                                             $model = $select_row['model'];
                                             $r_sta = $select_row['ram_storage'];
                                             $color = $select_row['color'];

                                             echo "<p>$model - $r_sta, $color</p>";
                                        }
                                        ?>

                                        <!-- <p>product name - ram, color</p> -->

                                        <div class="total">
                                             <h3>Total price -
                                                  <?php echo $total; ?>
                                             </h3>
                                             <h3>Date -
                                                  <?php echo $date; ?>
                                             </h3>
                                        </div>
                                        <?php
                                        if ($status == "delivery") {

                                             ?>
                                             <div class="btn">
                                                  <span class="check"><i class="fa-solid fa-truck"></i>
                                                       <?php echo $status; ?>
                                                  </span>
                                             </div>
                                        <?php } else { ?>
                                             <div class="btn">
                                                  <span class="check"><i class="fa-solid fa-check-to-slot"></i>
                                                       <?php echo $status; ?>
                                                  </span>
                                             </div>
                                        <?php } ?>
                                   </div>
                              </div>

                         <?php }
                    }
               } else { ?>
                    <?php
                    $query = "SELECT * FROM orders WHERE status = 'delivery' ORDER BY order_date";
                    $res = mysqli_query($conn, $query);
                    while ($row = mysqli_fetch_assoc($res)) {
                         $order_id = $row['order_id'];
                         $status = $row['status'];
                         $date = $row['order_date'];
                         $user = $row['user_id'];

                         $emm_qry = "select email from register where user_id = $user";
                         $emm_res = mysqli_query($conn, $emm_qry);
                         $emm_row = mysqli_fetch_assoc($emm_res);
                         $email = $emm_row['email'];
                         $total = 0;
                         ?>
                         <div class="card">
                              <div class="card_head">
                                   <h4>
                                        <?php echo $email; ?>
                                   </h4>
                                   <p><a href="admin_view_order.php?order_id=<?php echo $order_id; ?>">view</a></p>
                              </div>
                              <div class="info">

                                   <?php
                                   $coll_qry = "select * from collect where order_id = $order_id";
                                   $coll_res = mysqli_query($conn, $coll_qry);
                                   while ($coll_row = mysqli_fetch_assoc($coll_res)) {
                                        $price_id = $coll_row['price_id'];
                                        $qty = $coll_row['quantity'];
                                        $price = $coll_row['price'];

                                        $total += $qty * $price;

                                        $select_qry = "SELECT p.model, b.ram_storage, s.color FROM phones p JOIN bibi b ON p.phone_id = b.phone_id JOIN select_phones s ON s.select_id = b.select_id WHERE b.price_id = $price_id;";
                                        $select_res = mysqli_query($conn, $select_qry);
                                        $select_row = mysqli_fetch_assoc($select_res);
                                        $model = $select_row['model'];
                                        $r_sta = $select_row['ram_storage'];
                                        $color = $select_row['color'];

                                        echo "<p>$model - $r_sta, $color</p>";
                                   }
                                   ?>

                                   <!-- <p>product name - ram, color</p> -->

                                   <div class="total">
                                        <h3>Total price -
                                             <?php echo $total; ?>
                                        </h3>
                                        <h3>Date -
                                             <?php echo $date; ?>
                                        </h3>
                                   </div>
                                   <?php
                                   if ($status == "delivery") {

                                        ?>
                                        <div class="btn">
                                             <span class="check"><i class="fa-solid fa-truck"></i>
                                                  <?php echo $status; ?>
                                             </span>
                                        </div>
                                   <?php } else { ?>
                                        <div class="btn">
                                             <span class="check"><i class="fa-solid fa-check-to-slot"></i>
                                                  <?php echo $status; ?>
                                             </span>
                                        </div>
                                   <?php } ?>
                              </div>
                         </div>
                    <?php }
               } ?>
          </div>
     </section>


     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     <script>
          let menu = document.getElementById('menu');
          let nav = document.querySelector('.navigation');

          menu.addEventListener('click', () => {
               nav.classList.toggle('active');
          })

     </script>

     <script>
          function setMinEndDate() {
               // Get the value of the start date input
               var startDateValue = document.getElementById("start").value;

               // Set the minimum date for the end date input
               document.getElementById("end").min = startDateValue;


          }
     </script>




</body>

</html>