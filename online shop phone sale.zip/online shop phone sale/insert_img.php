<?php require "connection.php"; ?>
<?php 



if($_SERVER['REQUEST_METHOD'] == "POST"){
     $color = $_POST['color'];
     $color_code = $_POST['color_code'];
     if(isset($_GET['id'])){
          $phone_id = $_GET['id'];
     }else{
          $in_query = "SELECT * FROM phones ORDER BY phone_id DESC LIMIT 1;";
          $in_ret = mysqli_query($conn, $in_query);
          $in_row = mysqli_fetch_assoc($in_ret);
          $phone_id = $in_row['phone_id'];
     }



     if(isset($_POST['upload'])){
          if($_FILES['img']['error'] === 4){
               echo "<script>alert('Image Does Not Exist');</script>";
          }
          else{
               $file_name = $_FILES['img']['name'];
               $file_size = $_FILES['img']['size']; 
               $tmpName = $_FILES['img']['tmp_name']; 
               
               $validExten = ['jpg', 'jpeg', 'png'];
               $imgExt = explode('.', $file_name);
               $imgExt = strtolower(end($imgExt));
          
               if(!in_array($imgExt, $validExten)){
                   echo "<script>alert('Invalid image extension.');</script>";
               }
               else if($file_size > 1200000){
                    echo "<script>alert('image is too large.');f</script>";
               }
               else{
                    $newImg = uniqid();
                    $newImg .= '.' . $imgExt;
               
                    move_uploaded_file($tmpName, './img/' . $newImg);

                    $add_query = "INSERT INTO select_phones (phone_id, color, color_code, img)
                                   VALUES ($phone_id, '$color','$color_code', '$newImg');";
                    mysqli_query($conn, $add_query);

                    // header("location: insert_img.php");
               }
          
          }
     } 

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Edit Phone</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <!-- <link rel="stylesheet" href="./admin_p_img.css"> -->

     <link rel="icon" href="./img/MicrosoftTeams-image (1).png">
     <style>
          <?php require "admin_p_img.css"; ?>
          <?php require "admin_home.css"; ?>
     </style>

     <script>
               function validateForm() {
                      var img = document.getElementsByName("img")[0].value.trim();
                      var color = document.getElementsByName("color")[0].value.trim();
                      var colorCode = document.getElementsByName("color_code")[0].value.trim();

                      if (!img || !color || !colorCode) {
                          alert("Please fill in.");
                          return false; // Prevent form submission
                      }
                      return true; // Allow form submission
                  }
     </script>

</head>
<body>

     <?php require "admin_header.php"; ?>

     <section id="img_ss">
          <?php 
          if(isset($_GET['id'])){
               $phone_id = $_GET['id'];
          }else{
               $in_query = "SELECT * FROM phones ORDER BY phone_id DESC LIMIT 1;";
               $in_ret = mysqli_query($conn, $in_query);
               $in_row = mysqli_fetch_assoc($in_ret);
               $phone_id = $in_row['phone_id'];
          }

          $ph_qry = "select * from phones where phone_id = $phone_id";
          $ph_rres = mysqli_query($conn, $ph_qry);
          $phh_row = mysqli_fetch_assoc($ph_rres);
          $phh_img = $phh_row['img'];


          ?>
          <div class="img">
               <h3 class="defImg">Default Image</h3>
               <img src="./img/<?php echo $phh_img; ?>" alt="">
               <div class="edit_img">
                   <label for="fileInput" class="custom-button">
                       <ion-icon name="create-outline"></ion-icon>
                   </label>
                   <input type="file" id="fileInput" class="file-input" accept=".jpg, .jpeg, .png">
                   <input type="hidden" id="phoneIdInput" name="phone_id" value="<?php echo $phone_id; ?>">
               </div>

               <div class="edit_text">
                   <a href="bubu_update.php?phone_id=<?php echo $phone_id ?>">
                       <button>
                           <ion-icon name="clipboard-outline"></ion-icon>
                       </button>
                   </a>
               </div>
               <div class="edit_del">
                   <a href="" onclick="deleteItem(this.getAttribute('data-dell-id'))" data-dell-id="<?php echo $phone_id; ?>">
                        <button>
                            <ion-icon name="trash-outline"></ion-icon>
                        </button>
                   </a>
               </div>
          </div>  
          <div class="img_sli">
               <div class="btnb">
                    <form action="">
                         <h3 class="sliImg">Slide For Images</h3>
                        <!-- Custom button to trigger file input -->
                        <label for="imgInput" class="custom-button">Add Image</label>
    
                        <!-- File input hidden by default -->
                        <input type="file" id="imgInput" name="image" accept=".jpg, .jpeg, .png">
                        <input type="hidden" id="phoneid" name="phone_id" value="<?php echo $phone_id; ?>">
                    </form>
               </div>
               <div class="img_ssi">
                   <?php 
                   $sli_query = "SELECT * FROM slides WHERE phone_id = $phone_id";
                   $sli_res = mysqli_query($conn, $sli_query);
                   while ($sli_row = mysqli_fetch_assoc($sli_res)){
                       $sli_img = $sli_row['slide_img'];
                       $sli_id = $sli_row['slide_id'];
                   ?>
                   <div class="sli_sli">
                       <img src="./slide_img/<?php echo $sli_img; ?>" alt="">
                       <div class="del_sli">
                           <!-- Pass the slide id as data-slideid attribute -->
                           <button class="delete-slide" data-slideid="<?php echo $sli_id; ?>">
                               <ion-icon name="close-outline"></ion-icon>
                           </button>
                       </div>
                   </div>
                   <?php } ?>
               </div>

          </div>
     </section>

     <h1 class="add_img_color">Add color</h1>
     <div class="choice">
          <div class="c_form">
               <form action="" method="post" enctype="multipart/form-data" onsubmit="return validateForm()">
                    <?php 
                    if(isset($_GET['id'])){
                         $phone_id = $_GET['id'];
                         $p_query = "SELECT * FROM phones WHERE phone_id=$phone_id";;
                         $p_ret = mysqli_query($conn, $p_query);
                         $p_row = mysqli_fetch_assoc($p_ret);
                         $p_id = $phone_id;
                         $p_name = $p_row['model'];
                    }else{
                         $p_query = "SELECT * FROM phones ORDER BY phone_id DESC LIMIT 1;";
                         $p_ret = mysqli_query($conn, $p_query);
                         $p_row = mysqli_fetch_assoc($p_ret);
                              $p_id = $p_row['phone_id'];
                              $p_name = $p_row['model'];
                         }

                    echo "<p>product ID - <span>$p_id</span></p>";
                    echo "<p>product Name - <span>$p_name</span></p>";
                    
                    ?>                    
                    <p>product image</p>
                    <input id="addColor" type="file" name="img"  accept=".jpg, .jpeg, .png" require>
                    <p>color</p>
                    <input type="text" name="color" require> <br><br>
                    <p>color code <span>(eg. #000000)</span></p>
                    <input type="text" name="color_code" require> <br><br>

                    <div class="div">
                         <label for="toggleInputCheckbox">Promotion <span>only number</span></label>
                         <input type="checkbox" id="toggleInputCheckbox">

                         <div id="inputBox">
                             <input type="number" id="textInput">
                             <input type="hidden" id="phoneIdInput" value="<?php echo $p_id; ?>"> <!-- Hidden input for phone_id -->
                             <button id="submitButton">Submit</button>
                         </div>

                         <div id="output"></div>
                    </div>

                    <input type="submit" value="Add Color" name="upload">
               </form>
          </div>

          <div class="c_img">
          <?php
               if(isset($_GET['id'])){
                    $phone_id = $_GET['id'];
                    $query = "select * from select_phones where phone_id = $phone_id";
               }else{
                    $query = "select * from select_phones where phone_id = $p_id";
               }
               $ret = mysqli_query($conn, $query);
               while($row = mysqli_fetch_assoc($ret)){
                    $select_id = $row['select_id'];
                    $color = $row['color'];
                    $img = $row['img'];

               ?>
                    <div class="c_img_card">
                    <a href="admin_p_price.php?id=<?php echo $select_id; ?>">
                         <img src="./img/<?php echo $img ?>" alt="">
                    </a>
                    <div class="content">
                         <p><?php echo $color; ?></p>
                    </div>

                    <div id="container">
                         <div class="edii" data-select-id="<?php echo $select_id; ?>">
                            <input type="hidden" value="<?php echo $select_id; ?>">
                            <p><ion-icon name="trash-outline" class="delete-btn"></ion-icon></p>
                         </div>
                         <div class="eff" id="effElement" data-custom-id="<?php echo $select_id; ?>">
                            <input type="hidden" class="selectId" value="<?php echo $select_id; ?>">
                            <input type="file" class="file-input newFileInputId" accept=".jpg, .jpeg, .png">
                            <button class="chooseFileBtn">
                                <ion-icon name="create-outline" class="edit-btn"></ion-icon>
                            </button>
                        </div>


                    </div>
                    

                    <?php 
                         if(isset($_GET['id'])){
                              $phone_id = $_GET['id'];
                              $qry = "select promotion from bibi where phone_id = $phone_id";
                         } else{
                              $qry = "select promotion from bibi where phone_id = $p_id";
                         }
                         $q_res = mysqli_query($conn, $qry);
                         $q_row = mysqli_fetch_assoc($q_res);
                         $q_promo = $q_row['promotion'];

                         if($q_promo > 0) {
                              echo " <div class='pro'>
                              <p>$q_promo%</p>
                         </div>";
                         }
                    ?>
               </div>
               <?php } ?>
     
          </div>
     </div>
          <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     <script>
        function deleteItem(itemId) {
        if (confirm("Are you sure you want to delete this item?")) {
            // Create a new AJAX request
            var xhr = new XMLHttpRequest();

            // Specify the request type, URL, and asynchronous flag
            xhr.open('POST', 'http://localhost/KBTC-Class/PHP_Testing/yairlinthu/ad_item_del.php', true);

            // Set the request header if needed
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

            // Define the callback function to handle the AJAX response
            xhr.onreadystatechange = function() {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        alert('Item deleted successfully');
                        window.location.href = 'inser_img.php'; 
                        
                    } else {
                        alert('something is wrong.');
                    }
                }
            };

            // Send the request with the item ID as data
            xhr.send('itemId=' + encodeURIComponent(itemId));
        }
    }
    </script>

     <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
     <script>
         $(document).ready(function() {
             $('.delete-slide').click(function() {
                 var slideId = $(this).data('slideid');
                 // Perform AJAX request to delete the slide
                 $.ajax({
                     url: 'http://localhost/KBTC-Class/PHP_Testing/yairlinthu/del_slide_img.php',
                     method: 'POST',
                     data: { slide_id: slideId },
                     success: function(response) {
                         // Refresh the page or update the slide list if needed
                         window.location.reload();
                     },
                     error: function(xhr, status, error) {
                         console.error('Error deleting slide:', error);
                     }
                 });
             });
         });
     </script>

     <script>
        document.addEventListener("DOMContentLoaded", function() {
            var chooseFileButtons = document.querySelectorAll('.chooseFileBtn'); // Select all buttons
            var inputFileElements = document.querySelectorAll('.newFileInputId'); // Select all file inputs

            // Loop through each button and add event listener
            chooseFileButtons.forEach(function(button, index) {
                button.addEventListener('click', function() {
                    inputFileElements[index].click(); // Trigger the click event on the corresponding file input
                });
            });

            // Add event listener to each file input
            inputFileElements.forEach(function(inputFileElement) {
                inputFileElement.addEventListener('change', function(event) {
                    var selectedId = event.target.parentElement.querySelector('.selectId').value; // Get the value of the hidden input (selected ID)
                    var selectedFile = event.target.files[0]; // Get the selected file
                    updateImage(selectedFile, selectedId);
                });
            });

            // Function to update the image via AJAX
            function updateImage(imageFile, selectedId) {
                var formData = new FormData();
                formData.append('upd_file', imageFile);
                formData.append('upd_select_id', selectedId);

                var xhr = new XMLHttpRequest();
                xhr.open('POST', 'http://localhost/KBTC-Class/PHP_Testing/yairlinthu/in_upd_img.php', true);
                xhr.onload = function() {
                    if (xhr.status === 200) {
                        // Image updated successfully
                        console.log(xhr.responseText);
                        window.location.reload(); // Reload the page
                        // You can handle success behavior here, such as updating UI or displaying a message
                    } else {
                        // Error occurred
                        console.error('Error updating image.');
                    }
                };
                xhr.onerror = function() {
                    // Error occurred during the request
                    console.error('Error updating image. Network error.');
                };
                xhr.send(formData);
            }
        });






     </script>



     <script>
          let menu =document.getElementById('menu');
          let nav = document.querySelector('.navigation'); 

          menu.addEventListener('click', () => {
               nav.classList.toggle('active');
          })

          document.getElementById('toggleInputCheckbox').addEventListener('change', function() {
                  var inputBox = document.getElementById('inputBox');
                  inputBox.style.display = this.checked ? 'block' : 'none';
              });

          document.getElementById('submitButton').addEventListener('click', function() {
                  var textInput = document.getElementById('textInput').value;
                  console.log("Entered text:", textInput);
          });

          document.getElementById('toggleInputCheckbox').addEventListener('change', function() {
                  var inputBox = document.getElementById('inputBox');  
                  inputBox.style.display = this.checked ? 'block' : 'none';
              });

              document.getElementById('submitButton').addEventListener('click', function() {
                  var textInput = document.getElementById('textInput').value;
                  var phoneId = document.getElementById('phoneIdInput').value; // Get phone_id value
                  var xhr = new XMLHttpRequest(); 
                  xhr.onreadystatechange = function() {
                      if (xhr.readyState == XMLHttpRequest.DONE) {
                          if (xhr.status == 200) {
                              // Update output div with response from PHP script
                              // document.getElementById('output').innerText = xhr.responseText;
                              // Show alert after updating output
                              alert('successfully promotion added.');
                              window.location.reload(); // Reload the page
                              // alert(xhr.responseText);
                          } else {
                              alert('Error:', xhr.status);
                          }
                      }
                  };
                  xhr.open('POST', 'http://localhost/KBTC-Class/PHP_Testing/yairlinthu/promo_update.php', true);
                  xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                  xhr.send('phoneId=' + encodeURIComponent(phoneId) + '&textInput=' + encodeURIComponent(textInput)); // Send both input values to PHP script
              });


               /* img edit */
          // Handle regular image upload
          document.getElementById('fileInput').addEventListener('change', function() {
              var fileInput = this;
              var file = fileInput.files[0];
              var phoneId = document.getElementById('phoneIdInput').value;
              uploadFile(file, phoneId);
          });

          // Handle slide image upload
          document.getElementById('imgInput').addEventListener('change', function() { 
              var imgInput = this;
              var imgfile = imgInput.files[0];
              var phoneId = document.getElementById('phoneid').value; // corrected variable name
              uploadSlideImage(imgfile, phoneId); // corrected function name
          });

          function uploadFile(file, phoneId) {
              var formData = new FormData();
              formData.append('file', file);
              formData.append('phone_id', phoneId);
              var xhr = new XMLHttpRequest();
              xhr.open('POST', 'http://localhost/KBTC-Class/PHP_Testing/yairlinthu/def_img_upload.php', true);
              xhr.onload = function() {
                  if (xhr.status === 200) {
                    //   alert('File uploaded successfully.');
                      // Reload the page after the file is uploaded
                      window.location.reload();
                  } else {
                      console.error('An error occurred while uploading the file.');
                  }
              };
              xhr.onerror = function() {
                  console.error('An error occurred during the upload process.');
              };
              xhr.send(formData);
          }

          function uploadSlideImage(imgfile, phoneId) {
              var imgformData = new FormData();
              imgformData.append('file', imgfile);
              imgformData.append('phone_id', phoneId);
              var xhr = new XMLHttpRequest();
              xhr.open('POST', 'http://localhost/KBTC-Class/PHP_Testing/yairlinthu/slide_img_add.php', true);
              xhr.onload = function() {
                  if (xhr.status === 200) {
                    //   alert('Slide image uploaded successfully.');
                      // Reload the page after the image is uploaded
                      window.location.reload();
                  } else {
                      console.error('An error occurred while uploading the slide image.');
                  }
              };
              xhr.onerror = function() {
                  console.error('An error occurred during the slide image upload process.');
              };
              xhr.send(imgformData);
          }



              document.addEventListener('DOMContentLoaded', function() {
              // Get all containers with class 'edii'
              var containers = document.querySelectorAll('.edii');
    
              // Iterate through each container
              containers.forEach(function(container) {
                  // Attach click event listener to the container
                  container.addEventListener('click', function(e) {
                      if (e.target && e.target.matches('.delete-btn')) {
                          // Send AJAX request to delete
                          var parentDiv = e.target.closest('.edii');
                          var selectId = parentDiv.dataset.selectId;
                          if (confirm("Are you sure you want to delete this item?")) {
                              // Perform AJAX request here
                              var xhr = new XMLHttpRequest();
                              xhr.open('POST', 'http://localhost/KBTC-Class/PHP_Testing/yairlinthu/test/endpoint.php', true); // Change the URL to your PHP file
                              xhr.setRequestHeader('Content-Type', 'application/json');
                              xhr.onload = function() {
                                  if (xhr.status === 200) {
                                      // Item deleted successfully, remove from DOM
                                   //    parentDiv.remove();
                                      alert('Success: Item deleted.');
                                      window.location.reload(); // Reload the page
                                  } else {
                                      // Handle error
                                      alert('Item could not be deleted.');
                                  }
                              };
                              xhr.onerror = function() {
                                  console.error('Error deleting item. Network error.');
                              };
                              xhr.send(JSON.stringify({ selectId: selectId }));
                          }
                      }
                  });
              });
          });


     </script>
     
     

</body>
</html>