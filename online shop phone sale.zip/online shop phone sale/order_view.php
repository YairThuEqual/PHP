<?php 
require "connection.php";
session_start();
if(isset($_SESSION['user_id'])){
     $user_id = $_SESSION['user_id']; 

     $query = "select * from cart where user_id= $user_id";
     $res = mysqli_query($conn, $query);

     while($row = mysqli_fetch_assoc($res)){
          $bibi_id = $row['bibi_id'];
          $qty = $row['quantity'];
          $price = $row['price'];

          $sel_query = "SELECT order_id FROM orders WHERE user_id = $user_id AND order_date = ( SELECT MAX(order_date) FROM orders WHERE user_id = $user_id );";

          $sel_res = mysqli_query($conn, $sel_query);
          $sel_row = mysqli_fetch_assoc($sel_res);
          $order = $sel_row['order_id'];


          $coll_query = "INSERT INTO collect (order_id, price_id, price, quantity)
          VALUES ($order, $bibi_id, $price, $qty);";
          mysqli_query($conn, $coll_query);
          
          $up_query = "UPDATE bibi SET items = items - $qty WHERE price_id = $bibi_id;";
          mysqli_query($conn, $up_query);
          
          $del_query = "DELETE FROM cart WHERE user_id = $user_id";
          mysqli_query($conn, $del_query);
     }

     header("location: see_order.php");
}


?>
