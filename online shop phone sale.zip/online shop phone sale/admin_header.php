<header>
    <div class="header">
        <div class="logo">
            <a href="admin_index.php" class="logo"><img src="./img/MicrosoftTeams-image (1).png" alt=""></a>
        </div>
        <div class="sear">
            <form action="admin_search.php" method="get">
                <input type="search" name="search" value="<?php if(isset($_GET['search'])) echo $_GET['search'] ?>" placeholder="search"><ion-icon name="search-outline"></ion-icon>
            </form>
        </div>
        <div class="group">
               <ul class="navigation">
                    <li><a href="admin_index.php">products</a></li>
                    <li><a href="bubu_insert.php">add product</a></li>
                    <li><a href="admin_order.php">orders</a></li>
                    <li><a href="admin_order_finish.php">delivered</a></li>
                    <li><a href="admin_view.php">admins</a></li>
                    <li class="icc"><a href="admin_logout.php"><ion-icon name="log-out-outline" class="log-out-outline"></ion-icon></a></li>
                    <li class="lcc"><a href="admin_logout.php">logout</a></li>
               </ul>
        </div>
        <div class="menu">
            <ion-icon id="menu" name="menu-outline"></ion-icon>
        </div>
    </div>

</header>
