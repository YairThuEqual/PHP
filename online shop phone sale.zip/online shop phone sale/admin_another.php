<?php session_start() ?>
<?php require "connection.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Navigation search</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />


     <style>
          <?php 
               include "admin_home.css";
               include "admin_register.css";
          ?>
     </style>
     
</head>
<body>

     <?php include "admin_header.php";?>

     <?php 
     $admin_id = $_GET['id'];
     $admin_qry = "SELECT * FROM admin WHERE admin_id = $admin_id";
     $admin_res = mysqli_query($conn, $admin_qry);
     $admin_row = mysqli_fetch_assoc($admin_res);

     $ad_name = $admin_row['name'];
     $ad_email = $admin_row['email'];
     $ad_ph_no = $admin_row['phone_number'];
     $ad_pass = $admin_row['password'];
     $ad_city = $admin_row['city'];
     $ad_address = $admin_row['address'];

     ?>

     <section id="sect">
          <form class="regi" action="admin_ed_update.php" method="post">
               <h1>Update Admin</h1>

               <h4>Admin ID - <?php echo $admin_id ?></h4><br>
               <input type="hidden" name="adminid" value="<?php echo $admin_id; ?>">

               <p>Name<span class="error">*</span></p>
               <span class="error"><?php if(isset($error['name'])) echo $error['name'] ?></span>
               <input type="text" placeholder="Username" name="name" value="<?php echo $ad_name; ?>" required>

               <p>Email<span class="error">*</span></p>
               <span class="error"><?php if(isset($error['email'])) echo $error['email']; if(isset($error['dup_mail'])) echo $error['dup_mail'];?></span>
               <input type="email" placeholder="Email" name="email" value="<?php echo $ad_email; ?>" required>

               <p>Password <span>(at least 8 character.(letter, number, character))</span><span class="error">*</span></p>
               <span class="error"><?php if(isset($error['password'])) echo $error['password']; ?></span>
               <input type="password" id="password" placeholder="Password" name="password" value="<?php echo $ad_pass; ?>" required>

               <p>Phone Number<span class="error">*</span></p>
               <span class="error"><?php if(isset($error['phone'])) echo $error['phone'];?></span>
               <input type="number" placeholder="phone number" name="phone" value="<?php echo $ad_ph_no; ?>" required>


               <p>City<span class="error">*</span></p>
               <span class="error"><?php if(isset($error['city'])) echo $error['city'];?></span>
               <input type="text" placeholder="City" name="city" value="<?php echo $ad_city; ?>" required>

               <p>Address<span class="error">*</span></p>
               <span class="error"><?php if(isset($error['address'])) echo $error['address']?></span>
               <input type="text" placeholder="address" name="address" value="<?php echo $ad_address; ?>" required>

               <div class="flex">
                   <div class="see">
                       <input type="checkbox" id="showPasswordCheckbox">
                       <label for="showPasswordCheckbox">See Password</label>
                   </div>
                   <!-- <div class="link">
                       <span><a href="">already account?</a></span>
                   </div> -->
               </div>
               <input type="submit" value="Update"> 
           </form>
     </section>
     
     

     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     <script>
          let menu =document.getElementById('menu');
          let nav = document.querySelector('.navigation');

          menu.addEventListener('click', () => {
               nav.classList.toggle('active');
          })

          function changePhoneImage(imagePath) {
              var phoneImage = event.currentTarget.closest('.card').querySelector('.phone-image');
              phoneImage.src = imagePath;
 
              // Remove 'active' class from all elements with class 'choe'
              var allChoeElements = document.querySelectorAll('.choe');
              allChoeElements.forEach(function(element) {
                  element.classList.remove('active');
              });
 
              // Add 'active' class to the clicked parent div with class 'choe'
              event.currentTarget.closest('.choe').classList.add('active');
          }
     </script>

<script>
          document.addEventListener('DOMContentLoaded', function() {

                    
               const passwordInput = document.getElementById('password');
               const showPasswordCheckbox = document.getElementById('showPasswordCheckbox');
          
               if (!passwordInput || !showPasswordCheckbox) {
                    console.error('One or more elements not found.');
                    return;
               }
          
               showPasswordCheckbox.addEventListener('change', function() {
                    if (showPasswordCheckbox.checked) {
                         passwordInput.type = 'text';
                    } else {
                         passwordInput.type = 'password';
                    }
               });


               const loginForm = document.querySelector('.regi');
               let loginAttempts = 0;

               loginForm.addEventListener('submit', function(event) {
                    loginAttempts++;
                    console.log(loginAttempts);

                    // Check if login attempts exceed 5
                    if (loginAttempts >= 5) {
                         // Disable submit button
                         document.querySelector('.regi input[type="submit"]').disabled = true;

                         // After 5 seconds, enable submit button again
                         setTimeout(function() {
                              document.querySelector('.regi input[type="submit"]').disabled = false;
                              loginAttempts = 0; // Reset login attempts
                         }, 5000);
                    }
               });
          });
     </script>
 
 

</body>
</html>