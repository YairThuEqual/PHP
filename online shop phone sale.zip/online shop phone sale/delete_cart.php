<?php
     require "connection.php";

// Check if cart_id is set in the URL
if(isset($_GET['cart_id']) && isset($_GET['bi_id']) && isset($_GET['quantity'])) {
    // Get the cart_id from the URL
    $cart_id = $_GET['cart_id'];
    $bibi_id = $_GET['bi_id'];
    $qty = $_GET['quantity'];

    // $sel_query = "select items from bibi where price_id=$bibi_id";
    // $res = mysqli_query($conn, $sel_query);
    // $row = mysqli_fetch_assoc($res);
    // $o_qty = $row['items'];

    // $query = sprintf("update bibi set items =%d  where price_id=%d",$o_qty + $qty, $bibi_id);
    // mysqli_query($conn, $query);

    // Prepare and execute SQL statement to delete the record
    $sql = "DELETE FROM cart WHERE cart_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $cart_id); // Assuming cart_id is an integer, use "i" for integer
    $stmt->execute();

    // Check if deletion was successful
    if ($stmt->affected_rows > 0) {
        echo "Item deleted successfully";
    } else {
        echo "No records deleted";
    }

   
    // Close statement and database connection
    $stmt->close();
} else {
    // If cart_id is not set in the URL, send error response
    header("HTTP/1.1 400 Bad Request");
    echo "Cart ID is required";
}

// Close database connection
$conn->close();
?>
