<?php
// Check if the quantity and cart_id parameters are set and not empty
if(isset($_GET['quantity']) && !empty($_GET['quantity']) && isset($_GET['cart_id']) && !empty($_GET['cart_id'])) {
    // Retrieve the quantity and cart_id from the GET parameters
    $quantity = $_GET['quantity'];
    $cart_id = $_GET['cart_id'];

    // Connect to the database (assuming you have already established the connection)
    require "connection.php";

    // Step 1: Add the 'items' column to the 'bibi' table
    $sqlAlter = "ALTER TABLE bibi ADD items INT";
    $pdo->exec($sqlAlter);

    // Step 2: Update the 'quantity' column with data from the join between 'bibi' and 'cart'
    $sqlUpdate = "UPDATE bibi b
                  JOIN cart c ON b.price_id = c.bibi_id
                  SET b.quantity = :quantity
                  WHERE c.cart_id = :cart_id";
    $stmt = $pdo->prepare($sqlUpdate);
    $stmt->bindParam(':quantity', $quantity, PDO::PARAM_INT);
    $stmt->bindParam(':cart_id', $cart_id, PDO::PARAM_INT);
    $stmt->execute();

    // Send a success response back if the update is successful
    echo json_encode(array("status" => "success", "message" => "Quantity updated successfully"));
} else {
    // Send an error response if the quantity or cart_id parameter is missing or empty
    echo json_encode(array("status" => "error", "message" => "Quantity or cart_id parameter is missing or empty"));
}
?>
