<?php session_start() ?>
<?php require "connection.php"; ?>
<?php include "register_validation.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Navigation search</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />


     <style>
          <?php 
               include "home.css";
               include "register.css"
          ?>
     </style>
     
</head>
<body>

     

     <?php 
     include "header.php";
     ?>

     <section id="sect">
          <form class="regi" action="#" method="post"> 
               <h1>Register</h1>

               <p>Username<span class="error">*</span></p>
               <span class="error"><?php if(isset($error['name'])) echo $error['name']; if(isset($error['dup_name'])) echo $error['dup_name']; ?></span>
               <input type="text" placeholder="Username" name="name" value="<?php echo $name; ?>" required>

               <p>Email<span class="error">*</span></p>
               <span class="error"><?php if(isset($error['email'])) echo $error['email']; if(isset($error['dup_mail'])) echo $error['dup_mail'];?></span>
               <input type="email" placeholder="Email" name="email" value="<?php echo $email; ?>" required>

               <p>Password <span>(at least 8 character.(letter, number, character))</span><span class="error">*</span></p>
               <span class="error"><?php if(isset($error['password'])) echo $error['password']; ?></span>
               <input type="password" id="password" placeholder="Password" name="password" value="<?php echo $password; ?>" required>

               <p>Confirm Password<span class="error">*</span></p>
               <span class="error"><?php if(isset($error['cpassword'])) echo $error['cpassword']; ?></span>
               <input type="password" id="cpassword" placeholder="Confirm Password" name="cpassword" value="<?php echo $cpassword; ?>" required>

               <div class="flex">
                   <div class="see">
                       <input type="checkbox" id="showPasswordCheckbox">
                       <label for="showPasswordCheckbox">See Password</label>
                   </div>
                   <!-- <div class="link">
                       <span><a href="">already account?</a></span>
                   </div> -->
               </div>
               <input type="submit" value="Register">
           </form>

          <div class="rest">
               <h3>If you have already account.</h3>
               <a href="login.php"><button>login</button></a>
          </div>
     </section>
     
     <?php require "footer.php"; ?>
     

     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     <script src="./nav.js"></script>

          <script>
               document.addEventListener('DOMContentLoaded', function() {
               const passwordInput = document.getElementById('password');
               const cpasswordInput = document.getElementById('cpassword');
               const showPasswordCheckbox = document.getElementById('showPasswordCheckbox');
     
               if (!passwordInput || !showPasswordCheckbox) {
                    console.error('One or more elements not found.');
                    return;
               }
     
               showPasswordCheckbox.addEventListener('change', function() {
                    if (showPasswordCheckbox.checked) {
                         passwordInput.type = 'text';
                         cpasswordInput.type = 'text';
                    } else {
                         passwordInput.type = 'password';
                         cpasswordInput.type = 'password';
                    }
               });
               });
          </script>
 
 

</body>
</html>