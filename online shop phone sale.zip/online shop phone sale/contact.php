<?php session_start(); ?>
<?php require "connection.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Contact Us</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <!-- <link rel="stylesheet" href="./home.css">
     <link rel="stylesheet" href="./register.css"> -->

     <link rel="icon" href="./img/MicrosoftTeams-image (1).png">

     <style> 
          <?php require "home.css"; ?>
          <?php require "free_shipping.css"; ?>
     </style>
     
</head>
<body>

     <?php include "header.php"; ?>


     <section>
         <div class="con_add">
               <div class="conttt">
                    <ul>
                         <li><i class="fa-regular fa-envelope"></i> <span>shiki@gmail.com</span></li>
                         <li><i class="fa-solid fa-phone-volume"></i> <span>09847363747</span></li>
                         <li><i class="fa-solid fa-map-location-dot"></i> <span>14. GaBarAye Road</span></li>
                         <li><i class="fa-regular fa-clock"></i> <span>09:00 AM to 05:00 PM</span></li>
                    </ul>
               </div>
               <div class="map">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3819.1113884198376!2d96.15280407330182!3d16.82082931888294!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30c193e941f2e067%3A0x5e54c9aa66f073eb!2sKBTC%20University-%20School%20of%20IT!5e0!3m2!1sen!2smm!4v1709045314403!5m2!1sen!2smm" width="400" height="270" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
               </div>
         </div>
     </section>

    
     
     <?php include "footer.php"; ?>
     

     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     
     <script>
          let search = document.querySelector('.searchBtn')
          let closeBtn = document.querySelector('.closeBtn')
          let searchBox = document.querySelector('.searchBox')
          let nav = document.querySelector('.navigation')
          let menu = document.querySelector('.menuToggle')
          let header = document.querySelector('header')

          search.addEventListener('click', () => {
               searchBox.classList.add('active')
               closeBtn.classList.add('active')
               search.classList.add('active')
               menu.classList.add('hide')
               header.classList.remove('open')
          })

          closeBtn.addEventListener('click', () => {
               searchBox.classList.remove('active')
               closeBtn.classList.remove('active')
               search.classList.remove('active')
               menu.classList.remove('hide')
          })

          menu.addEventListener('click', () =>{
               header.classList.toggle('open')
               searchBox.classList.remove('active')
               closeBtn.classList.remove('active')
               search.classList.remove('active')
          })
     </script>
</body>
</html>