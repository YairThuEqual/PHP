<?php
// Check if admin_id is provided and is numeric
if (isset($_POST['admin_id']) && is_numeric($_POST['admin_id'])) {
    require "connection.php";

    // Prepare a SQL statement to delete the admin record
    $admin_id = $_POST['admin_id'];
    $sql = "DELETE FROM admin WHERE admin_id = $admin_id";

    // Execute the SQL statement
    if ($conn->query($sql) === TRUE) {
        echo "Admin deleted successfully";
    } else {
        echo "Error deleting admin: " . $conn->error;
    }

    // Close connection
    $conn->close();
} else {
    echo "Invalid admin ID";
}
?>
