<?php require "connection.php"; ?>
<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Admin View</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
     <!-- <link rel="stylesheet" href="./home.css">
     <link rel="stylesheet" href="./card.css"> -->

     <link rel="icon" href="./img/MicrosoftTeams-image (1).png">

     <style>
          <?php require "admin_home.css"; ?>
          <?php require "admin_view.css"; ?>
     </style>

</head>
<body>

     <?php include "admin_header.php"; ?>

     <?php if($_SESSION['admin_email'] == "strongadmin@gmail.com"){ ?>

     <section>
          <div class="create">
               <a href="admin_register.php">create admin</a>
          </div>
     </section>

     <?php } ?>
    
     <section>
          <div class="container">
               <div class="main">
                    <?php 
                    if($_SESSION['admin_email'] == "strongadmin@gmail.com"){
                    $query = "SELECT * FROM admin;";
                    $res = mysqli_query($conn, $query);
                    while($row = mysqli_fetch_assoc($res)){
                         $admin_id = $row['admin_id'];
                         $name = $row['name'];
                         $email = $row['email'];
                         $ph_number = $row['phone_number'];
                         $city = $row['city'];
                         $address = $row['address'];
                         $strong_admin = $row['strong_admin'];
           
                         if($strong_admin != "strong"){
                    ?>
                    <div class="card">
                         <table>
                              <tr>
                                   <td>Admin_ID</td>
                                   <td>-</td>
                                   <td><?php echo $admin_id; ?></td>
                              </tr>
                              <tr>
                                   <td>Name</td>
                                   <td>-</td>
                                   <td><?php echo $name; ?></td>
                              </tr>
                              <tr>
                                   <td>Email</td>
                                   <td>-</td>
                                   <td><?php echo $email; ?></td>
                              </tr>
                              <tr>
                                   <td>Ph Numer</td>
                                   <td>-</td>
                                   <td><?php echo $ph_number; ?></td>
                              </tr>
                              <tr>
                                   <td>City</td>
                                   <td>-</td>
                                   <td><?php echo $city ?></td>
                              </tr>
                              <tr>
                                   <td>Address</td>
                                   <td>-</td>
                                   <td><?php echo $address ?></td>
                              </tr>
                         </table>
                         <div class="btn">
                              <a href="admin_another.php?id=<?php echo $admin_id; ?>" class="update">update</a>
                              <a href="#" data-adminid="<?php echo $admin_id; ?>" class="delete">delete</a>
                         </div>
                    </div>
                    <?php }}} else {?>
                    <?php
                         $query = "SELECT * FROM admin;";
                    $res = mysqli_query($conn, $query);
                    while($row = mysqli_fetch_assoc($res)){
                         $admin_id = $row['admin_id'];
                         $name = $row['name'];
                         $email = $row['email'];
                         $ph_number = $row['phone_number'];
                         $city = $row['city'];
                         $address = $row['address'];
                         $strong_admin = $row['strong_admin'];
           
                         if($strong_admin != "strong"){
                    ?>
                    <div class="card">
                         <table>
                              <tr>
                                   <td>Admin_ID</td>
                                   <td>-</td>
                                   <td><?php echo $admin_id; ?></td>
                              </tr>
                              <tr>
                                   <td>Name</td>
                                   <td>-</td>
                                   <td><?php echo $name; ?></td>
                              </tr>
                              <tr>
                                   <td>Email</td>
                                   <td>-</td>
                                   <td><?php echo $email; ?>m</td>
                              </tr>
                              <tr>
                                   <td>Ph Numer</td>
                                   <td>-</td>
                                   <td><?php echo $ph_number; ?></td>
                              </tr>
                              <tr>
                                   <td>City</td>
                                   <td>-</td>
                                   <td><?php echo $city ?></td>
                              </tr>
                              <tr>
                                   <td>Address</td>
                                   <td>-</td>
                                   <td><?php echo $address ?></td>
                              </tr>
                         </table>
                    </div>
                    <?php }}} ?> 
               </div>
          </div>
     </section>


     <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
     <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

     <script>
          let menu =document.getElementById('menu');
          let nav = document.querySelector('.navigation');

          menu.addEventListener('click', () => {
               nav.classList.toggle('active');
          })

     </script> 

<script>
          $(document).ready(function() {
              $(document).on('click', '.delete', function(e) {
                  e.preventDefault();
                  var adminId = $(this).data('adminid');
                  if (confirm("Are you sure you want to delete this admin?")) {
                      $.ajax({
                          type: 'POST',
                          url: 'http://localhost/KBTC-Class/PHP_Testing/yairlinthu/admin_e_delete.php', // Your PHP script to handle deletion
                          data: { admin_id: adminId },
                          success: function(response) {
                              // Handle success
                              console.log(response);
                              window.location.reload();
                          },
                          error: function(xhr, status, error) {
                              // Handle error
                              console.error(xhr.responseText);
                          }
                      });
                  }
              });
          });


     </script>

</body>
</html>